package au.com.westpac.mac.rule.entity;

public class RuleConfigEntity {
	
	private long id;
	
	private String ruleId;
	
	private int configId;
	
	private String value;
	
	private String description;
	
	private boolean isConfigurableFromScreen;
	
	public boolean isConfigurableFromScreen() {
		return isConfigurableFromScreen;
	}

	public void setConfigurableFromScreen(boolean isConfigurableFromScreen) {
		this.isConfigurableFromScreen = isConfigurableFromScreen;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
