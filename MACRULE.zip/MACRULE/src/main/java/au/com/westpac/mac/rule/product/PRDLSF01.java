package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDLSF01")
@Scope("prototype")
public class PRDLSF01 extends ProductRule {

	private static final int LOAN_SERVICE_FEE = 1;

	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		
		if(null!=productFeeList && !productFeeList.isEmpty()){
			for (ProductFee productFee : productFeeList) {
				if ((productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID ||  productFee.getFeeTypeId() == RuleConstant.OVERDRAFT_FACILITY_FEE_TYPE_ID)
						&& null == productFee.getFeeAmount()) {
					productFee.setFeeAmount(Double.valueOf(ruleConfigMap
							.get(LOAN_SERVICE_FEE)));
					ruleResultIndicator = ruleExecutionUtil.isGreaterThanOrEqual(
							ruleConfigMap, LOAN_SERVICE_FEE,
							productFee.getFeeAmount());
	
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
