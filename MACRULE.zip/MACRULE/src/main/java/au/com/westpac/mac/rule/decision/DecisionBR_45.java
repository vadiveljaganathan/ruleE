package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductRepayment;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_45")
public class DecisionBR_45 extends Rule {
	private static final int CURRENT_REPAYMENT_TYPE = 1;
	private static final int NEW_REPAYMENT_TYPE = 2;
	
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(ruleResults,dealDetails);
		
		if(isRuleApplicable) {
			for(Product product : dealDetails.getProducts()) {
				ruleResultIndicator = false;
			if(product.getProductRepayment()!=null) {
				ruleResultIndicator=ruleExecutionUtil.isContains(ruleConfigMap, CURRENT_REPAYMENT_TYPE, product.getProductRepayment().getRepaymentTypeId());					
			}
			if(ruleResultIndicator) {
				List<ProductRepayment> newRepayList = product.getRepaymentList();
					for (ProductRepayment repay : newRepayList) {
						ruleResultIndicator = !ruleExecutionUtil.isContains(ruleConfigMap, NEW_REPAYMENT_TYPE,
								repay.getRepaymentTypeId());
						if (!ruleResultIndicator) {
							break;
						}
					}
					if (!ruleResultIndicator) {
						break;
					}
				}
			}			
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean checkifRuleApplicable(List<RuleResult> ruleResults,DealDetails dealDetails){
		boolean isRuleApplicable = false;
		for(Product product : dealDetails.getProducts()){
			if(product.getProductRepayment()!=null){
				isRuleApplicable = ruleExecutionUtil.isContains(ruleConfigMap, CURRENT_REPAYMENT_TYPE, product.getProductRepayment().getRepaymentTypeId());
				if(isRuleApplicable){
					break;
				}
			}
		}
		if(isRuleApplicable){
			for (RuleResult ruleResult : ruleResults) {
				if(RuleConstant.DECISIONBR_43.equals(ruleResult.getRuleId())){
					if((!ruleResult.isRuleApplicable()) || (ruleResult.isRuleApplicable() && ruleResult.isRulePassed())){
						return true;
					}
				}
			}
		}
		return false;
	}

}
