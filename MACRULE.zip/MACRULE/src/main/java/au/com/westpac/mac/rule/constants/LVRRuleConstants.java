package au.com.westpac.mac.rule.constants;

public class LVRRuleConstants {
	public static final int COLLATERAL_FAMILY = 1;
	public static final int COLLATERAL_TYPE = 2;
	public static final int COLLATERAL_TYPE_1 = 3;
	public static final int COLLATERAL_TYPE_2 = 4;
	public static final int COLLATERAL_TYPE_3 = 5;
	public static final int COLLATERAL_VALUE_1 = 6;
	public static final int COLLATERAL_VALUE_2 = 7;
	public static final int COLLATERAL_VALUE_3 = 8;
	public static final int COLLATERAL_VALUE_4 = 9;
	public static final int INTERNAL_AREA_SQUARE_METRE_L62 = 10;
	public static final int LVR_RESTRICTIONS_TLSAS106 = 11;
	public static final int OWNER_BUILDER_TLAS117 = 12;
	public static final int POSTCODE = 13;
	public static final int POSTCODE_VALUE_1 = 14;
	public static final int POSTCODE_VALUE_2 = 15;
	public static final int POSTCODE_VALUE_3 = 16;
	public static final int POSTCODE_VALUE_4 = 17;
	public static final int POSTCODE_VALUE_5 = 18;
	public static final int POSTCODE_VALUE_6 = 19;
	public static final int POSTCODE_VALUE_7 = 20;
	public static final int POSTCODE_VALUE_8 = 21;
	public static final int POSTCODE_VALUE_9 = 22;
	public static final int POSTCODE_VALUE_10 = 23;
	public static final int PRODUCT_TYPE_VALUE = 24;
	public static final int OWNERSHIP_TYPE_L63 = 25;
	public static final int TOTAL_LAND_SIZE_HECTARE_TLAS110 = 26;
	public static final int UNIT_LOT_TLAS022_VALUE_1 = 27;
	public static final int UNIT_LOT_TLAS022_VALUE_2 = 28;
	public static final int UNIT_LOT_TLAS022_VALUE_3 = 29;
	public static final int SYSTEM_LVR = 49;
	public static final int STANDARD_LVR_FLAG = 50;
}
