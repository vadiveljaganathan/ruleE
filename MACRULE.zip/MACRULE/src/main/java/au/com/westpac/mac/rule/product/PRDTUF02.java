package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

/**
 * Total Finance Amount (ID 159) < 100,000 = $820 Total Finance Amount (ID 159)
 * > 100,000 = $820 + 0.6% of any amount above $100,000
 * 
 * @author L048037
 * 
 */

@Component("PRDTUF02")
@Scope("prototype")
public class PRDTUF02 extends ProductRule {

	private static final int TOPUPFEE_MINIMUM = 1;// 410
	private static final int PERCENTAGE_OF_LIMITAMOUNT = 2;// 0.3

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
					double topUpFeeMinimum = ruleExecutionUtil
							.getDoubleValue(ruleConfigMap,
									TOPUPFEE_MINIMUM);
					double topUpFeeLimitChangeAmount = ruleExecutionUtil
							.calcAmountOnPercent(
									product.getProductValidation().getResultantAmount().doubleValue(),
									ruleExecutionUtil
									.getDoubleValue(ruleConfigMap,
											PERCENTAGE_OF_LIMITAMOUNT));
					double topUpFee = ruleExecutionUtil.getMaxOfTwoNumbers(topUpFeeMinimum,topUpFeeLimitChangeAmount);
					productFee.setFeeAmount(topUpFee);
					ruleResultIndicator = true;				
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
