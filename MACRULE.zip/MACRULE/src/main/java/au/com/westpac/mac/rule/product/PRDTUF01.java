package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDTUF01")
@Scope("prototype")
public class PRDTUF01 extends ProductRule {

	private static final int TOPUP_FEE = 1;

	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		
		if(null!=productFeeList && !productFeeList.isEmpty()){
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
					productFee.setFeeAmount(ruleExecutionUtil.getDoubleValue(
							ruleConfigMap, TOPUP_FEE));
					ruleResultIndicator = true;
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
