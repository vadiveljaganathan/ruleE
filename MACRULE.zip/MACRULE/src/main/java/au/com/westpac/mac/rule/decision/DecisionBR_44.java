package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductRepayment;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_44")
public class DecisionBR_44 extends Rule{
		
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicableCondition1(ruleResults,dealDetails);
		List<Product> applicableProductList = new ArrayList<Product>();
		if(isRuleApplicable){
			applicableProductList = getApplicableProductList(dealDetails.getProducts(), applicableProductList);
			isRuleApplicable = applicableProductList.size()>0;
		}
		if(isRuleApplicable){
			for(Product product : applicableProductList){
				if(null!=product.getProductRepayment()){
				BigDecimal currentRepayment=  product.getProductRepayment().getRepaymentAmount();
				List<ProductRepayment> newRepayList = product.getRepaymentList();
				if(null!=currentRepayment && null!=newRepayList){
					for(ProductRepayment repay : newRepayList){
						BigDecimal newRepaymentAmount = repay.getRepaymentAmount();
						ruleResultIndicator=ruleExecutionUtil.isLessThanOrEqual(newRepaymentAmount, currentRepayment.doubleValue());
						if(!ruleResultIndicator)
							break;
					}
				}
				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);

	}

	private List<Product> getApplicableProductList(List<Product> products, List<Product> applicableProductList) {
		for(Product product : products){
			BigDecimal currentRepayment=  product.getProductRepayment().getRepaymentAmount();
			List<ProductRepayment> newRepayList = product.getRepaymentList();
			if(null!=currentRepayment && null!=newRepayList){
				applicableProductList.add(product);
			}
		}
		return applicableProductList;
	}

	private boolean checkifRuleApplicableCondition1(List<RuleResult> ruleResults,DealDetails dealDetails){
		for (RuleResult ruleResult : ruleResults) {
			if(RuleConstant.DECISIONBR_45.equals(ruleResult.getRuleId())){
				if((!ruleResult.isRuleApplicable()) || (ruleResult.isRuleApplicable() && ruleResult.isRulePassed())){
					return true;
				}
			}
		}		
		return false;
	}

}
