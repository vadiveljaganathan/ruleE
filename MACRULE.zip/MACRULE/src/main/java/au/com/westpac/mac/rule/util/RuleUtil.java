package au.com.westpac.mac.rule.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.westpac.mac.rule.checklist.CheckList;
import au.com.westpac.mac.rule.checklist.CheckListFactory;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleExecutionActionParams;
import au.com.westpac.mac.rule.domain.RuleFactory;
import au.com.westpac.mac.rule.entity.CheckListRuleGroupMapEntity;
import au.com.westpac.mac.rule.entity.RuleEngineDataEntity;
import au.com.westpac.mac.rule.entity.RuleGroupRuleMapEntity;
import au.com.westpac.mac.rule.rulegroup.ProductRuleGroup;
import au.com.westpac.mac.rule.rulegroup.RuleGroup;
import au.com.westpac.mac.rule.rulegroup.RuleGroupFactory;
import au.com.westpac.mac.rule.service.RuleService;
@Service
public class RuleUtil {

	@Autowired
	public RuleService ruleService;

	@Autowired
	private RuleGroupFactory macRuleGroupFactory;

	@Autowired
	private RuleFactory macRuleFactory;
	
	@Autowired
	private CheckListFactory checkListFactory;

	public RuleComponent getFirstStepForCheckList(Object macCheckList) {

		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		List<String> ruleGroupList = ruleEngineDataEntity
				.getCheckListRuleGroupMap().get(macCheckList.getClass().getSimpleName());

		String ruleGroupId = ruleGroupList.get(0);
		return getRuleGroup(ruleGroupId);
	}

	public RuleComponent getStepAfterSalesQuestionsForCheckList(Object macCheckList) {

		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		List<String> ruleGroupList = ruleEngineDataEntity
				.getCheckListRuleGroupMap().get(macCheckList.getClass().getSimpleName());

		String ruleGroupId = ruleGroupList.get(1);
		return getRuleGroup(ruleGroupId);
	}

	public RuleComponent getFirstStepForRuleGroup(RuleGroup ruleGroup) {

		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		List<String> ruleList = ruleEngineDataEntity.getRuleGroupRuleMap().get(
				ruleGroup.getRuleGroupId());

		String ruleId = ruleList.get(0);
		return getRule(ruleId);
	}

	public boolean getAfterDisplay(String ruleGroupId, String checklistId) {

		boolean isAfterDisplay = false;
		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		List<CheckListRuleGroupMapEntity> checkListRuleGroupMapList = ruleEngineDataEntity.getMacCheckListRuleGroupMap();
		for(CheckListRuleGroupMapEntity macCheckListRuleGroupMapEntity : checkListRuleGroupMapList){
			if(macCheckListRuleGroupMapEntity.getCheckListId().equalsIgnoreCase(checklistId) 
					&& macCheckListRuleGroupMapEntity.getRuleGroupId().equalsIgnoreCase(ruleGroupId)){
				isAfterDisplay =  macCheckListRuleGroupMapEntity.isAfterDisplay();
			}
		}
		return isAfterDisplay;
	}

	public Rule getRule(String ruleId) { 
		
		return macRuleFactory.lookup(ruleId);
	}


	public RuleGroup getRuleGroup(String ruleGroupId) {

		return macRuleGroupFactory.lookup(ruleGroupId);
	}

	public Map<Integer, String> getRuleConfigMap(String ruleId){

		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		Map<Integer, String> ruleConfig = null;

		if(ruleEngineDataEntity.getRuleConfigMap().get(ruleId)!= null){
			ruleConfig = (Map<Integer, String>) ruleEngineDataEntity.getRuleConfigMap().get(ruleId);
		}
		return ruleConfig;
	}



	public RuleExecutionActionParams getExecutionActionParamsForRule(String ruleGroupId, String ruleId){
		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();


		for(RuleGroupRuleMapEntity macRuleGroupRuleMapEntity : ruleEngineDataEntity.getMacRuleGroupRuleMapDetails()){
			if (macRuleGroupRuleMapEntity.getRuleGroupId().equals(ruleGroupId)
					&& macRuleGroupRuleMapEntity.getRuleId().equals(ruleId)) {
				RuleExecutionActionParams ruleExecutionActionParams = new RuleExecutionActionParams();
				ruleExecutionActionParams
						.setFailureActionId(macRuleGroupRuleMapEntity
								.getFailureActionId());
				ruleExecutionActionParams
						.setFailureNextId(macRuleGroupRuleMapEntity
								.getFailureNextId());
				ruleExecutionActionParams
						.setSuccessActionId(macRuleGroupRuleMapEntity
								.getSuccessActionId());
				ruleExecutionActionParams
						.setSuccessNextId(macRuleGroupRuleMapEntity
								.getSuccessNextId());
				
				ruleExecutionActionParams.setNotApplicableActionId(macRuleGroupRuleMapEntity.getNotApplicableActionId());
				ruleExecutionActionParams.setNotApplicableNextId(macRuleGroupRuleMapEntity.getNotApplicableNextId());
				return ruleExecutionActionParams;
			}
		}
		return null;
	}
	public CheckList getCheckList(String checkListId) {

		return checkListFactory.lookup(checkListId);
	}
	
	public List<RuleComponent> getRulesForRuleGroup(ProductRuleGroup ruleGroup) {
		List<RuleComponent> rulesForProductRulegroup = new ArrayList<RuleComponent>();
		
		RuleEngineDataEntity ruleEngineDataEntity = ruleService
				.loadCheckListGroupsAndRuleData();
		List<String> ruleList = ruleEngineDataEntity.getRuleGroupRuleMap().get(
				ruleGroup.getId());
		if(null != ruleList){
			for(String ruleId :ruleList){
				rulesForProductRulegroup.add(getRule(ruleId));
			}
		}
		return rulesForProductRulegroup;
	}
}
