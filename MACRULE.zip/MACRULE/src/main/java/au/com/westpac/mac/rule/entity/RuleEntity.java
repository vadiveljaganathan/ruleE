package au.com.westpac.mac.rule.entity;

import java.util.List;

public class RuleEntity {

	private String ruleId;
	private String ruleName;
	private int ruleTypeId;
	private String ruleDescription;
	private boolean shownToBanker;
	private List<RuleConfigEntity> ruleConfigList;
	
	public String getRuleDescription() {
		return ruleDescription;
	}
	public void setRuleDescription(String ruleDescription) {
		this.ruleDescription = ruleDescription;
	}
	public boolean isShownToBanker() {
		return shownToBanker;
	}
	public void setShownToBanker(boolean shownToBanker) {
		this.shownToBanker = shownToBanker;
	}
	public List<RuleConfigEntity> getRuleConfigList() {
		return ruleConfigList;
	}
	public void setRuleConfigList(List<RuleConfigEntity> ruleConfigList) {
		this.ruleConfigList = ruleConfigList;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	public int getRuleTypeId() {
		return ruleTypeId;
	}
	public void setRuleTypeId(int ruleTypeId) {
		this.ruleTypeId = ruleTypeId;
	}
	
}
