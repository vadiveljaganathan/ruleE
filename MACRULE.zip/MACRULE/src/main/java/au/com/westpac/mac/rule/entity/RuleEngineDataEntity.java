package au.com.westpac.mac.rule.entity;

import java.util.List;
import java.util.Map;

public class RuleEngineDataEntity {

	private List<CheckListEntity> checkListDetails;
	
	private List<RuleGroupEntity> ruleGroupDetails;
	
	private List<RuleEntity> ruleDetails;

	private Map<String, List<String>> checkListRuleGroupMap;
	
	private Map<String, List<String>> ruleGroupRuleMap;
	
	private Map<String, Map<Integer, String>> ruleConfigMap;
	
	private List<RuleGroupRuleMapEntity> macRuleGroupRuleMapDetails;
	
	private List<CheckListRuleGroupMapEntity> macCheckListRuleGroupMap;
	
	public List<CheckListRuleGroupMapEntity> getMacCheckListRuleGroupMap() {
		return macCheckListRuleGroupMap;
	}

	public void setMacCheckListRuleGroupMap(
			List<CheckListRuleGroupMapEntity> macCheckListRuleGroupMap) {
		this.macCheckListRuleGroupMap = macCheckListRuleGroupMap;
	}

	public List<CheckListEntity> getCheckListDetails() {
		return checkListDetails;
	}

	public void setCheckListDetails(List<CheckListEntity> checkListDetails) {
		this.checkListDetails = checkListDetails;
	}

	public List<RuleGroupEntity> getRuleGroupDetails() {
		return ruleGroupDetails;
	}

	public void setRuleGroupDetails(List<RuleGroupEntity> ruleGroupDetails) {
		this.ruleGroupDetails = ruleGroupDetails;
	}

	public List<RuleEntity> getRuleDetails() {
		return ruleDetails;
	}

	public void setRuleDetails(List<RuleEntity> ruleDetails) {
		this.ruleDetails = ruleDetails;
	}

	public Map<String, List<String>> getCheckListRuleGroupMap() {
		return checkListRuleGroupMap;
	}

	public void setCheckListRuleGroupMap(
			Map<String, List<String>> checkListRuleGroupMap) {
		this.checkListRuleGroupMap = checkListRuleGroupMap;
	}

	public Map<String, List<String>> getRuleGroupRuleMap() {
		return ruleGroupRuleMap;
	}

	public void setRuleGroupRuleMap(Map<String, List<String>> ruleGroupRuleMap) {
		this.ruleGroupRuleMap = ruleGroupRuleMap;
	}

	public Map<String, Map<Integer, String>> getRuleConfigMap() {
		return ruleConfigMap;
	}

	public void setRuleConfigMap(Map<String, Map<Integer, String>> ruleConfigMap) {
		this.ruleConfigMap = ruleConfigMap;
	}

	public List<RuleGroupRuleMapEntity> getMacRuleGroupRuleMapDetails() {
		return macRuleGroupRuleMapDetails;
	}

	public void setMacRuleGroupRuleMapDetails(
			List<RuleGroupRuleMapEntity> macRuleGroupRuleMapDetails) {
		this.macRuleGroupRuleMapDetails = macRuleGroupRuleMapDetails;
	}
	
}
