package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_19")
public class DecisionBR_19 extends Rule {

	private static final int CAL_LEVEL = 1;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;
	
		boolean isRuleApplicable = isRuleApplicable(dealDetails, ruleResults);

		if (isRuleApplicable) {
			// LLVR policy has not been met but approval is consistent with and
			// within the threshold of previous Credit Officer approval=TRUE
			ruleResultIndicator = dealDetails.getDeal()
					.isPrevCOApprovalIncaseLLVRNotMet();
		}else{
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check Entry Criteria for Rule DecisionBR_19
	 * 
	 * @param dealDetails
	 * @param ruleResults
	 * @return
	 */
	private boolean isRuleApplicable(DealDetails dealDetails,
			List<RuleResult> ruleResults) {
		// The logged in user have a CAL Level that is 1 or 2 and DecisionBR_9 =No
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel())
				&& (!checkExecutedRuleResults(ruleResults));

	}

	/**
	 * Method to check executed rule results
	 * 
	 * @param ruleResults
	 * @return
	 */
	private boolean checkExecutedRuleResults(List<RuleResult> ruleResults) {
		boolean result = false;
		for (RuleResult ruleResult : ruleResults) {
			// Check DecisionBR_9 passed
			if (ruleResult.getRuleId().equals(RuleConstant.DECISIONBR_9)) {
				result = ruleResult.isRulePassed();
			}

		}
		return result;
	}

}
