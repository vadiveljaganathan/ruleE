package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDCRM02")
@Scope("prototype")
public class PRDCRM02 extends ProductRule {

	private static final int BASE_RATE_TYPE_1 = 1;
	private static final int BASE_RATE_TYPE_2 = 2;
	private static final int CUSTOMER_RISK_MARGIN_1 = 3;
	private static final int CUSTOMER_RISK_MARGIN_2 = 4;

	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if (null != product.getProductInterestRate()) {
			ruleResultIndicator = true;
			String baseRateTypeId = null;
			if (null != product.getProductInterestRate().getBaseRateTypeId() && null == product.getProductInterestRate().getCustomerRiskMargin()) {
				baseRateTypeId = product.getProductInterestRate()
						.getBaseRateTypeId().toString();
				if (baseRateTypeId.equals(ruleConfigMap.get(BASE_RATE_TYPE_1))) {
					product.getProductInterestRate().setCustomerRiskMargin(
							Double.valueOf(ruleConfigMap
									.get(CUSTOMER_RISK_MARGIN_1)));
				} else if (baseRateTypeId.equals(ruleConfigMap
						.get(BASE_RATE_TYPE_2))) {
					product.getProductInterestRate().setCustomerRiskMargin(
							Double.valueOf(ruleConfigMap
									.get(CUSTOMER_RISK_MARGIN_2)));
				}
			}

		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
