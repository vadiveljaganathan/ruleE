package au.com.westpac.mac.rule.securitylvrrule;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("GRP_LVR")
public class GRP_LVR extends Rule{

	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		LVRDetails lvrDetails = (LVRDetails) arg;
		boolean isRuleApplicable = true;
		boolean isLVR001Applicable = false;
		int systemLVR = 100;
		boolean standardLVRFlag = false;			
		for (RuleResult result : ruleResults) {
			/*US 1412 start*/
			if(lvrDetails.getAssetType()!=0){				
			/*Check if asset is Residential - Stratum Title	70,Residential - Strata Title 72,Residential - Converted Commercial	75
			Rural - Residential	76, Residential - Serviced Apartment 78,Residential - Units & Multiple Dwellings 81
			Residential - Vacant Land 83,Residential - Company Title 85, Residential - Building Unit 86,Residential - Converted Industrial 103,
			Residential - House	104, Residential - Houses & Single Dwellings 107, Residential - Community Title 108*/
			String applicableAssetTypes = ",70,72,75,76,78,81,83,85,86,103,104,107,108,";
			String assetType = ","+lvrDetails.getAssetType()+",";
			if(applicableAssetTypes.contains(assetType)){
				//Check if Rule Applicable is between LVR011 to LVR021 AND 
				//POST CODE RANGE IN (1000-2599, 2620-2899, 2921-2999, 3000-3999, 8000-8999)
				/*Check for LVR001 is applicable and set a flag so when highest LVR% is to be applied then LVR of LVR001 should be considered*/
				if(("LVR001".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed()))){
					isLVR001Applicable = true;
				}
				if(("LVR011".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR012".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) ||
						("LVR013".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR014".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) ||
						("LVR015".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR016".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) ||
						("LVR017".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR018".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) ||
						("LVR019".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR020".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || 
						("LVR021".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed()))){
				
					
						/*Check if LVR022 to LVR026 is applicable */
						if(("LVR022".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR023".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || 
								("LVR024".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || ("LVR025".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) || 
								("LVR026".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) ){
							//Apply Lowest LVR%
							if (systemLVR >= result.getSystemLVR()) {
							systemLVR = result.getSystemLVR();
							standardLVRFlag = result.isStandardLVRFlag();						
						}
						
					}//end of if loop for rules LVR022 to LVR026
						/*Check if none of 22-26 is applicable*/
					else if(!("LVR022".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) && !("LVR023".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) && 
							!("LVR024".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) && !("LVR025".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed())) && 
							!("LVR026".equalsIgnoreCase(result.getRuleId())&&(result.isRulePassed()))){
						//Check if it lies in post code
						if(null!=lvrDetails.getPostCode() && !"".equals(lvrDetails.getPostCode())){
						if((Integer.parseInt(lvrDetails.getPostCode()) >=1000 && Integer.parseInt(lvrDetails.getPostCode())<=2599) ||
								(Integer.parseInt(lvrDetails.getPostCode()) >=2620 && Integer.parseInt(lvrDetails.getPostCode())<=2899) ||
								(Integer.parseInt(lvrDetails.getPostCode()) >=2921 && Integer.parseInt(lvrDetails.getPostCode())<=2999) ||
								(Integer.parseInt(lvrDetails.getPostCode()) >=3000 && Integer.parseInt(lvrDetails.getPostCode())<=3999) ||
								(Integer.parseInt(lvrDetails.getPostCode()) >=8000 && Integer.parseInt(lvrDetails.getPostCode())<=8999)){
									//Apply Highest LVR%
									if (isLVR001Applicable) {
										systemLVR = 0;
										standardLVRFlag = false;
									} else if (systemLVR == 100) {
										systemLVR = result.getSystemLVR();
										standardLVRFlag = result
												.isStandardLVRFlag();
									} else if (systemLVR <= result
											.getSystemLVR()) {
										systemLVR = result.getSystemLVR();
										standardLVRFlag = result
												.isStandardLVRFlag();
									}
								//end of if loop for rules Postcode
								//if invalid postcode is entered
								} else if (result.isRuleApplicable()
										&& systemLVR >= result.getSystemLVR()) {
									systemLVR = result.getSystemLVR();
									standardLVRFlag = result
											.isStandardLVRFlag();
								}
							//end of if loop for empty or null postcode
							} else if (result.isRuleApplicable()
									&& systemLVR >= result.getSystemLVR()) {
								systemLVR = result.getSystemLVR();
								standardLVRFlag = result.isStandardLVRFlag();
							}					
						//End if loop 22-16 NOT applicable - //Apply Lowest LVR%
						} else if (systemLVR >= result.getSystemLVR()) {
							systemLVR = result.getSystemLVR();
							standardLVRFlag = result.isStandardLVRFlag();
						}//If not lying in postcode ranges-end else
					//end of if loop for rules LVR011 to LVR021
					} else if (result.isRuleApplicable()
							&& systemLVR >= result.getSystemLVR()) {
						systemLVR = result.getSystemLVR();
						standardLVRFlag = result.isStandardLVRFlag();
					}
				//Apply Lowest LVR%
				} else if (result.isRuleApplicable()
						&& systemLVR >= result.getSystemLVR()) {
					systemLVR = result.getSystemLVR();
					standardLVRFlag = result.isStandardLVRFlag();
				}
			//If asset type is not null - Apply Lowest LVR%
			} else if (result.isRuleApplicable()
					&& systemLVR >= result.getSystemLVR()) {
				systemLVR = result.getSystemLVR();
				standardLVRFlag = result.isStandardLVRFlag();
			}
		}
		
		lvrDetails.setStandardLVRFlag(standardLVRFlag);
		lvrDetails.setSystemLVR(systemLVR);
		/* Add Rule Result to list of list of rule result */
		ruleExecutionUtil.addLVRRuleResult(this, ruleResults, isRuleApplicable,lvrDetails);
	}
}
