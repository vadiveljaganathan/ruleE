package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_29")
public class DecisionBR_29 extends Rule {
	private static final int CAL_LEVEL = 1;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);

		if (isRuleApplicable) {
			// Does any of the allocated assets for the modified/new products is
			// a consent required (Old MAC ID 964) = TRUE?
			if (dealDetails.getDeal().isConsentsAuthorityHeld()) {
				ruleResultIndicator = true;
			}
		}else {
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check entry criteria for Rule DecisionBR_29
	 * 
	 * @param dealDetails
	 * @return
	 */
	private boolean isRuleApplicable(DealDetails dealDetails) {
		// The logged in user have a CAL Level that is 1,2,3
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel());
	}

}
