package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;
@Component("DecisionBR_33")
public class DecisionBR_33 extends Rule {
	
	private static final int MODIFIED_PROD_PRODUCT_FAMILY = 6;
	private static final int MODIFIED_PROD_PRODUCT_TYPE = 7;
	private static final int MODIFIED_PROD_PRODUCT_FAMILY_2 = 11;
	private static final int ASSET_TYPE = 8;
	private static final int AMOUNT_2 = 9;
	
	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {

		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);

		if (isRuleApplicable) {
			ruleResultIndicator = checkProducts(dealDetails);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

	private boolean isRuleApplicable(DealDetails dealDetails) {

		boolean isRuleApplicable = false;
		if (!dealDetails.getProducts().isEmpty()) {
			isRuleApplicable = true;
			for (Product product : dealDetails.getProducts()) {
				// each product should satisfy any of the following 3 condition
				if (!(checkModProdFamily(product))) {
					return false;
				}
			}
		}
		return isRuleApplicable;
	}

	private boolean checkProducts(DealDetails dealDetails) {
		List<Product> productList = new ArrayList<Product>();
		boolean hasModifiedFacility = false;
		BigDecimal limitChangeLimit = ruleExecutionUtil.getBigDecimalValue(
				ruleConfigMap, AMOUNT_2);

		for (Product product : dealDetails.getProducts()) {
			productList.add(product);
		}

		for (Product product : productList) {
			if (checkModProdFamily(product)) {
				if (!modifiedFacilityCheck(dealDetails, product)) {
					return false;
				}
				hasModifiedFacility = true;
			}
		}
		if (hasModifiedFacility
				&& getSumOfLimitChangeAmount(productList).compareTo(
						limitChangeLimit) > 0) {
			return false;
		}
		return true;
	}

	private boolean checkModProdFamily(Product product) {
		return product.getFacilityId()!=null
				&& ruleExecutionUtil.isContains(ruleConfigMap,
						MODIFIED_PROD_PRODUCT_FAMILY, product
								.getProductCategroy().getProductFamilyId())
				&& !ruleExecutionUtil.isContains(ruleConfigMap,
						MODIFIED_PROD_PRODUCT_FAMILY_2, product
						.getProductCategroy().getProductFamilyId())							
				&& !ruleExecutionUtil.isContains(ruleConfigMap,
						MODIFIED_PROD_PRODUCT_TYPE, product
								.getProductCategroy().getProductTypeId());
	}


	private boolean modifiedFacilityCheck(DealDetails dealDetails,
			Product product) {
		
		if (product.getProposedLimit().compareTo(getAllocatedAmount(dealDetails, product)) > 0) {
			return false;
		}
		return true;
	}

	private BigDecimal getAllocatedAmount(DealDetails dealDetails,
			Product product) {
		if (null == dealDetails.getAsset()) {
			return BigDecimal.ZERO;
		}

		BigDecimal sumOfAllocatedAmount = BigDecimal.ZERO;
		
		Map<Long, BigDecimal> assetIdAllocationMap = product.getAssetIdAndAllocationMap();
		for(Asset asset : product.getAllocatedAssets()){
			if(ruleExecutionUtil.isContains(ruleConfigMap, ASSET_TYPE, asset.getAssetCategory().getAssetTypeId())){
				for(Long assetId : assetIdAllocationMap.keySet()){
					if(assetId.longValue() == asset.getAssetId().longValue()){
						sumOfAllocatedAmount = sumOfAllocatedAmount.add(asset.getAllocationAmount());
					}
				}
			}
		}
		return sumOfAllocatedAmount;
	}

	private BigDecimal getSumOfLimitChangeAmount(List<Product> productList) {
		BigDecimal sumOfLimitChangeAmount = BigDecimal.ZERO;
		for (Product product : productList) {
			sumOfLimitChangeAmount = sumOfLimitChangeAmount.add(product.getLimitChangeAmount());
		}
		return sumOfLimitChangeAmount;
	}

}
