package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_40")
public class DecisionBR_40 extends Rule{

	/*All conditions verified.*/
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =isRuleApplicable(dealDetails); 
		if (isRuleApplicable) {
			if(dealDetails.getDealDecision().getConditionVerified()
					&& (null == dealDetails.getDealDecision().getIsDateCommencedInIndustryApplicable() 
					|| (dealDetails.getDealDecision().getIsDateCommencedInIndustryApplicable() && dealDetails.getDealDecision().getConditionVerifiedForCommencedDate()))){
				ruleResultIndicator=true;
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

	private boolean isRuleApplicable(DealDetails dealDetails) {
		if((null != dealDetails.getDealDecision() && null != dealDetails.getDealDecision().getConditionVerified() 
				&& (null == dealDetails.getDealDecision().getIsDateCommencedInIndustryApplicable() 
					|| (dealDetails.getDealDecision().getIsDateCommencedInIndustryApplicable() && null != dealDetails.getDealDecision().getConditionVerifiedForCommencedDate())))){
			return true;
		}
		return false;
	}
}
