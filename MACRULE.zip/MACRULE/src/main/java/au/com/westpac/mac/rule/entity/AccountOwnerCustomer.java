package au.com.westpac.mac.rule.entity;

public class AccountOwnerCustomer {

	private long accountOwnerId;
	private long customerId;
	
	
	public long getAccountOwnerId() {
		return accountOwnerId;
	}
	public void setAccountOwnerId(long accountOwnerId) {
		this.accountOwnerId = accountOwnerId;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	
}
