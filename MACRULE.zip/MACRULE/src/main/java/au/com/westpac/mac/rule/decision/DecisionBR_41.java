package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_41")
public class DecisionBR_41 extends Rule{
	private static final int LLVR_BORROWINGENTITY_MIN = 1;
	private static final int LLVR_BORROWINGENTITY_MAX = 2;
	
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(dealDetails);
		if(isRuleApplicable){
			Map<Long,BigDecimal> borrowingEntityConsumption = new HashMap<Long,BigDecimal>();
			Map<Long,BigDecimal> borrowingEntityAllocation = new HashMap<Long,BigDecimal>();
			for(Product prod : dealDetails.getAllProducts()){
				long borrowerId = prod.getBorrower().getId();				
				BigDecimal limit = prod.isModifiedInDeal()?prod.getProposedLimit():prod.getCurrentLimit();
				limit = null==limit?BigDecimal.ZERO:limit;
				if(borrowingEntityConsumption.containsKey(borrowerId)){
					BigDecimal totalLimit = borrowingEntityConsumption.get(borrowerId);
					BigDecimal amount = totalLimit.add(limit);
					borrowingEntityConsumption.put(borrowerId, amount);
				}else{
					borrowingEntityConsumption.put(borrowerId, limit);
				}
				for(AssetAllocations alloc : dealDetails.getAssetAllocations()){
					if(alloc.getProductId()==prod.getId()){
						BigDecimal allocation = alloc.getAllocationAmount();
						allocation = null==allocation?BigDecimal.ZERO:allocation;
						if(borrowingEntityAllocation.containsKey(borrowerId)){				
							BigDecimal totalallocation = borrowingEntityAllocation.get(borrowerId);
							BigDecimal amount = totalallocation.add(allocation);
							borrowingEntityAllocation.put(borrowerId, amount);
						}else{
							borrowingEntityAllocation.put(borrowerId, allocation);
						}
					}
				}
			}
			
			for(Map.Entry<Long, BigDecimal> consumptionMap : borrowingEntityConsumption.entrySet()){
				Long borrowerId = consumptionMap.getKey();
				BigDecimal consumption = consumptionMap.getValue();
				BigDecimal allocation = borrowingEntityAllocation.get(borrowerId);
				if(null!=consumption && null!=allocation && allocation.intValue()!=0){
					BigDecimal llvr = consumption.divide(allocation,2, RoundingMode.HALF_EVEN).multiply(new BigDecimal(100));
					ruleResultIndicator = ruleExecutionUtil.isInRangeBigDecimal(ruleConfigMap,LLVR_BORROWINGENTITY_MIN,LLVR_BORROWINGENTITY_MAX,llvr);
					if(!ruleResultIndicator){
						break;
					}			
				}
			}			
			
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);

	}

	private boolean checkifRuleApplicable(DealDetails dealDetails){		
		return !dealDetails.isRolloverDeal();		
	}

}
