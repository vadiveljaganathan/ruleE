package au.com.westpac.mac.rule.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.util.RuleExecutionUtil;
import au.com.westpac.mac.rule.util.RuleUtil;

public abstract class RuleComponent {

	protected String id;

	@Autowired
	public RuleExecutionUtil ruleExecutionUtil;

	@Autowired
	public RuleUtil ruleUtil;
	
	
	public abstract List<RuleResult> execute(Object arg,
			List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) ;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
