package au.com.westpac.mac.rule.rulegroup;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@Component("DecisionRuleGroup")
@Scope("prototype")
public class DecisionRuleGroup extends RuleGroup{
	protected List<RuleComponent> listOFRules;
	protected String ruleGroupId;
	protected String name;
	protected String ruleGroupTypeId;

	public  List<RuleResult> execute(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec){

		setValuesForRuleGroup();	
		exec.setExecutingRuleGroupId(this.ruleGroupId);

		if(null != this.firstStep && arg instanceof LVRDetails){
			firstStep.execute(arg, ruleEngineResult, exec);
			return ruleEngineResult;
		}

		if(null != this.firstStep){
			firstStep.execute(arg, ruleEngineResult, exec);
		}
		RuleResult ruleResult = ruleEngineResult
				.get(ruleEngineResult.size() - 1);
		

		for(RuleResult ruleResult1 : ruleEngineResult){
			if(null == ruleResult1.getRuleGroupId() || "".equals(ruleResult1.getRuleGroupId())){
				ruleResult1.setRuleGroupId(this.ruleGroupId);
			}
		}
		
		if (ruleResult.isGoToNextRuleGroup()){
			RuleGroup ruleGroup = ruleUtil.getRuleGroup("DecisionRuleGroup");
			ruleGroup.setId(ruleResult.getNextRuleGroupId());
			ruleGroup.execute(arg, ruleEngineResult, exec);
		}
		
		return ruleEngineResult;
	}

	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRuleGroupTypeId() {
		return ruleGroupTypeId;
	}

	public void setRuleGroupTypeId(String ruleGroupTypeId) {
		this.ruleGroupTypeId = ruleGroupTypeId;
	}

	//@PostConstruct
	public void setValuesForRuleGroup(){
		this.ruleGroupId = this.id;
		this.firstStep = ruleUtil.getFirstStepForRuleGroup(this);
	}


}
