package au.com.westpac.mac.rule.rulegroup;

public interface RuleGroupFactory {
	public RuleGroup lookup(String ruleGroupId); 
}
