package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDA03")
@Scope("prototype")
public class PRDA03 extends ProductRule{
	
	private static final int AMOUNT_MIN_LIMIT = 1;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if (null != product.getProductValidation() && null == product.getProductValidation().getTotalFinanceAmountMin()) {
			ruleResultIndicator = ruleExecutionUtil
					.isGreaterThanOrEqualBigDecimal(ruleConfigMap,
							AMOUNT_MIN_LIMIT, product.getProductValidation()
									.getTotalFinanceAmount());
			product.getProductValidation().setTotalFinanceAmountMin(
					Double.valueOf(ruleConfigMap.get(AMOUNT_MIN_LIMIT)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
