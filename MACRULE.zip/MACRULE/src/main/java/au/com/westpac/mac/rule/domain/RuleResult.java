package au.com.westpac.mac.rule.domain;

public class RuleResult {

	protected String ruleId;

	protected String ruleGroupId;
	
	protected boolean rulePassed;

	protected boolean isRuleApplicable;
	
	protected String nextRuleGroupId;

	protected boolean goToNextRuleGroup;

	protected String nextRuleId;
	
	private boolean standardLVRFlag;

	private int systemLVR;
	
	private boolean conditionallyApproved;
	
	private boolean approvedUnderLendingAuthority;
	
	private boolean approvedUnderRolloverPolicy;
	
	private boolean referToCredit;
	
	private boolean financialsRequired;

	private boolean exit;
	
	private boolean reviewRequired;
	
	private boolean securityAllocationRequired;
	
	private String description;
		
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public RuleResult() {
		super();
	}

	public RuleResult(String ruleId, boolean isRuleApplicable,
			boolean rulePassed) {
		super();
		this.ruleId = ruleId;
		this.rulePassed = rulePassed;
		this.isRuleApplicable = isRuleApplicable;
	}

	public String getNextRuleGroupId() {
		return nextRuleGroupId;
	}

	public void setNextRuleGroupId(String nextRuleGroupId) {
		this.nextRuleGroupId = nextRuleGroupId;
	}

	public String getNextRuleId() {
		return nextRuleId;
	}

	public void setNextRuleId(String nextRuleId) {
		this.nextRuleId = nextRuleId;
	}

	public boolean isGoToNextRuleGroup() {
		return goToNextRuleGroup;
	}

	public void setGoToNextRuleGroup(boolean goToNextRuleGroup) {
		this.goToNextRuleGroup = goToNextRuleGroup;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public void setRuleGroupId(String ruleGroupId) {
		this.ruleGroupId = ruleGroupId;
	}


	public boolean isRulePassed() {
		return rulePassed;
	}

	public void setRulePassed(boolean rulePassed) {
		this.rulePassed = rulePassed;
	}

	public boolean isRuleApplicable() {
		return isRuleApplicable;
	}

	public void setRuleApplicable(boolean isRuleApplicable) {
		this.isRuleApplicable = isRuleApplicable;
	}

	public boolean isStandardLVRFlag() {
		return standardLVRFlag;
	}

	public void setStandardLVRFlag(boolean standardLVRFlag) {
		this.standardLVRFlag = standardLVRFlag;
	}

	public int getSystemLVR() {
		return systemLVR;
	}

	public void setSystemLVR(int systemLVR) {
		this.systemLVR = systemLVR;
	}

	public boolean isConditionallyApproved() {
		return conditionallyApproved;
	}

	public void setConditionallyApproved(boolean conditionallyApproved) {
		this.conditionallyApproved = conditionallyApproved;
	}

	public boolean isReferToCredit() {
		return referToCredit;
	}

	public void setReferToCredit(boolean referToCredit) {
		this.referToCredit = referToCredit;
	}

	public boolean isFinancialsRequired() {
		return financialsRequired;
	}

	public void setFinancialsRequired(boolean financialsRequired) {
		this.financialsRequired = financialsRequired;
	}

	public boolean isExit() {
		return exit;
	}

	public void setExit(boolean exit) {
		this.exit = exit;
	}

	public boolean isApprovedUnderLendingAuthority() {
		return approvedUnderLendingAuthority;
	}

	public void setApprovedUnderLendingAuthority(
			boolean approvedUnderLendingAuthority) {
		this.approvedUnderLendingAuthority = approvedUnderLendingAuthority;
	}

	public boolean isApprovedUnderRolloverPolicy() {
		return approvedUnderRolloverPolicy;
	}

	public void setApprovedUnderRolloverPolicy(boolean approvedUnderRolloverPolicy) {
		this.approvedUnderRolloverPolicy = approvedUnderRolloverPolicy;
	}

	public boolean isReviewRequired() {
		return reviewRequired;
	}

	public void setReviewRequired(boolean reviewRequired) {
		this.reviewRequired = reviewRequired;
	}	

	public boolean isSecurityAllocationRequired() {
		return securityAllocationRequired;
	}

	public void setSecurityAllocationRequired(boolean securityAllocationRequired) {
		this.securityAllocationRequired = securityAllocationRequired;
	}


}
