package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDMIO02")
@Scope("prototype")
/*
 * This rule is exclusively for "Business Equity Access loan" product. Do not use for other products.
 * */
public class PRDMIO02 extends ProductRule {
	
	private static final int MAX_INTEREST_RATE = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(isRuleApplicable && null != product.getProductValidation() && null !=product.getIsRevolvingLineOfCredit()){
			if(!product.getIsRevolvingLineOfCredit()){
				ruleResultIndicator = ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap, MAX_INTEREST_RATE, product.getProductValidation().getLoanTermYearsMaxForIORepayment());
				product.getProductValidation().setLoanTermYearsMaxForIORepayment(Integer.parseInt(ruleConfigMap.get(MAX_INTEREST_RATE)));
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
