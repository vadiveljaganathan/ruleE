package au.com.westpac.mac.rule.entity;

public class CheckListEntity {

	private String checkListId;
	private String checkListName;
	
	public String getCheckListId() {
		return checkListId;
	}
	public void setCheckListId(String checkListId) {
		this.checkListId = checkListId;
	}
	public String getCheckListName() {
		return checkListName;
	}
	public void setCheckListName(String checkListName) {
		this.checkListName = checkListName;
	}

	
	
	
}
