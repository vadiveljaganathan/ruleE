package au.com.westpac.mac.rule.checklist;

import java.util.List;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

public  abstract class CheckList extends RuleComponent {

	protected RuleComponent firstStep;
	protected String checkListId;
	protected String name;
	
	public String getCheckListId() {
		return checkListId;
	}

	public void setCheckListId(String checkListId) {
		this.checkListId = checkListId;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Executed when the checklist is being processed by ruleengine
	 */
	public  List<RuleResult> execute(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) {
		
		setValuesForChecklist();	
		exec.setExecutingCheckListId(this.checkListId);
		if(null != this.firstStep && arg instanceof LVRDetails){
			firstStep.execute(arg, ruleEngineResult, exec);
			return ruleEngineResult;
		}else if(null != this.firstStep && arg instanceof DealDetails){
			firstStep.execute(arg, ruleEngineResult, exec);
			return ruleEngineResult;
		}
		return ruleEngineResult;
	}
	
	public RuleComponent getFirstStep() {
		return firstStep;
	}

	public void setFirstStep(RuleComponent firstStep) {
		this.firstStep = firstStep;
	}

	//@PostConstruct
	public void setValuesForChecklist(){
		this.checkListId = this.getClass().getSimpleName();
		this.firstStep = ruleUtil.getFirstStepForCheckList(this);
	}
	
	public void changeFirstStep(RuleEngineExecutionContext exec){
		this.checkListId = this.getClass().getSimpleName();
		this.firstStep = ruleUtil.getStepAfterSalesQuestionsForCheckList(this);
		exec.setAfterSalesQuestionExecutedOnce(true);
	}
	
}
