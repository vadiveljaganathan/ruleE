package au.com.westpac.mac.rule.entity;

public class RuleGroupRuleMapEntity {

	private String ruleGroupId;
	private String ruleId;
	private int seqNo;
	private int successActionId;
	private String successNextId;
	private int failureActionId;
	private String failureNextId;
	private int notApplicableActionId;
	private String notApplicableNextId;

	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public void setRuleGroupId(String ruleGroupId) {
		this.ruleGroupId = ruleGroupId;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public int getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	public int getSuccessActionId() {
		return successActionId;
	}

	public void setSuccessActionId(int successActionId) {
		this.successActionId = successActionId;
	}

	public String getSuccessNextId() {
		return successNextId;
	}

	public void setSuccessNextId(String successNextId) {
		this.successNextId = successNextId;
	}

	public int getFailureActionId() {
		return failureActionId;
	}

	public void setFailureActionId(int failureActionId) {
		this.failureActionId = failureActionId;
	}

	public String getFailureNextId() {
		return failureNextId;
	}

	public void setFailureNextId(String failureNextId) {
		this.failureNextId = failureNextId;
	}

	public int getNotApplicableActionId() {
		return notApplicableActionId;
	}

	public void setNotApplicableActionId(int notApplicableActionId) {
		this.notApplicableActionId = notApplicableActionId;
	}

	public String getNotApplicableNextId() {
		return notApplicableNextId;
	}

	public void setNotApplicableNextId(String notApplicableNextId) {
		this.notApplicableNextId = notApplicableNextId;
	}
	
	

}
