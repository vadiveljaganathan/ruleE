package au.com.westpac.mac.rule.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class RuleEntityWrapper {
	private List<RuleEntity> ruleEntityList;

	public List<RuleEntity> getRuleEntityList() {
		return ruleEntityList;
	}

	public void setRuleEntityList(List<RuleEntity> ruleEntityList) {
		this.ruleEntityList = ruleEntityList;
	}
	
	
}
