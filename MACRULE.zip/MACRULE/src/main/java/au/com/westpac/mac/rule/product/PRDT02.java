package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDT02")
@Scope("prototype")
public class PRDT02 extends ProductRule {
	
	private static final int TERM_YEARS_MIN = 1;
	private static final int TERM_YEARS_MAX = 2;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		
		if (null != product.getProductValidation()) {
			ruleResultIndicator = ruleExecutionUtil.isGreaterThanOrEqual(
					ruleConfigMap, TERM_YEARS_MIN, product
							.getProductValidation().getProposedLoanTermYears())
					|| ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap,
							TERM_YEARS_MAX, product.getProductValidation()
									.getProposedLoanTermYears());

			product.getProductValidation().setProposedLoanTermYearsMin(
					Integer.valueOf(ruleConfigMap.get(TERM_YEARS_MIN)));
			product.getProductValidation().setProposedLoanTermYearsMax(
					Integer.valueOf(ruleConfigMap.get(TERM_YEARS_MAX)));
		}
		
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
