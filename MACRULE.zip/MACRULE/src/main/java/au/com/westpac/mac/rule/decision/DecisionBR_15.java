package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_15")
public class DecisionBR_15 extends Rule{

	private static final int 	PRODUCT_FAMILY = 1;
	private static final int 	PRODUCT_TYPE = 2;
	private static final int 	LLVR_FACILITY_MIN = 3;
	private static final int 	LLVR_FACILITY_MAX = 4;
	private static final int 	ASSET_FAMILY_1 = 5;
	private static final int 	ASSET_TYPE = 6;
	private static final int 	ASSET_FAMILY_2 = 7;
	
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		List<Product> applicableProductlist =applicableProductTpye(dealDetails.getProducts());
		boolean isRuleApplicable =!applicableProductlist.isEmpty(); 
		if(isRuleApplicable){
			boolean isllvrWithinLimit;
			boolean isllvrResidentialWithinLimit;
			boolean isllvrCommercialWithinLimit;
			for(Product product : applicableProductlist){
				isllvrWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvr(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
				isllvrResidentialWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvrResidential(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
				isllvrCommercialWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvrCommercial(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
				if(checkFirstCondition(product) && isllvrWithinLimit && (isllvrResidentialWithinLimit || isllvrCommercialWithinLimit)){
					ruleResultIndicator= true;
				}else{
					ruleResultIndicator= false;
					break;
				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}


	private boolean checkFirstCondition(Product product) {
		for(Asset asset : product.getAllocatedAssets()){
			if((ruleExecutionUtil.isContains(ruleConfigMap, ASSET_FAMILY_1, asset.getAssetCategory().getAssetFamilyId()) && 
					ruleExecutionUtil.isContains(ruleConfigMap, ASSET_TYPE, asset.getAssetCategory().getAssetTypeId())) || 
					ruleExecutionUtil.isContains(ruleConfigMap, ASSET_FAMILY_2, asset.getAssetCategory().getAssetFamilyId())){
				return true;
			}
		}
		return false;
	}


	private List<Product> applicableProductTpye(List<Product> productList) {

		List<Product> applicableProductlist = new ArrayList<Product>();
		for(Product product : productList){
			if(!ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY, product.getProductCategroy().getProductFamilyId())
					|| !ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_TYPE, product.getProductCategroy().getProductTypeId())){
				applicableProductlist.add(product);
			}
		}
		return applicableProductlist;

	}
}

