package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_8")
public class DecisionBR_8 extends Rule{
	/*All 'modified/new' products in the deal in the Product Family = "Guarantees and Bonds"*/
	private static final int PRODUCT_FAMILY = 1;
	private static final int LLVR_FACILITY_MIN = 2;
	private static final int LLVR_FACILITY_MAX = 3;
	private static final int TOTAL_FINANCE_AMOUNT = 10;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		
	}

	private boolean checkSumOfresultantLimit(DealDetails dealDetails) {

		List<Product> productList = dealDetails.getProducts();
		BigDecimal resultantLimit=BigDecimal.ZERO; 
		for(Product product : productList){
			if(null!=product.getRequestedAmount()){
				resultantLimit= resultantLimit.add(product.getRequestedAmount());
			}
		}
		if(ruleExecutionUtil.checkifResultantLimitIsWithinLimit(resultantLimit, ruleConfigMap, TOTAL_FINANCE_AMOUNT)){
			return true;
		}
		return false;
	}
	private boolean checkLVRFacitlities(DealDetails dealDetails) {
		List<Product> productList = dealDetails.getProducts();
		boolean isllvrWithinLimit;
		boolean isllvrResidentialWithinLimit;
		boolean isllvrCommercialWithinLimit;
		for(Product product : productList){
			isllvrWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvr(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
			isllvrResidentialWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvrResidential(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
			isllvrCommercialWithinLimit =ruleExecutionUtil.checkifLLVRFacilityisInWithinRangeForProduct(product.getLlvrCommercial(), ruleConfigMap, LLVR_FACILITY_MIN, LLVR_FACILITY_MAX);
			if(!(isllvrWithinLimit && (isllvrResidentialWithinLimit || isllvrCommercialWithinLimit))){
				return false;
			}
		}
		return true;
	}
	private boolean checkifRuleApplicable(DealDetails dealDetails){
		List<Product> productList=dealDetails.getProducts();
		return ruleExecutionUtil.checkIfAllProductIsOfGivenTypeInList(productList, ruleConfigMap, PRODUCT_FAMILY);
	}

}
