package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_49")
public class DecisionBR_49 extends Rule {

	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(ruleResults);	
		List<Product> productList = getProductsWithTerms(dealDetails.getProducts());
		if(isRuleApplicable){
			for(Product product : productList){
				long currentTermYears=product.getCurrentTerm().getYears();
				long currentTermMonth = product.getCurrentTerm().getMonths();
				long newTermYears=product.getProposedTerm().getYears();
				long newTermMonths=product.getProposedTerm().getMonths();
				long currentTerm= calculateTerm(currentTermYears, currentTermMonth);
				long newTerm= calculateTerm(newTermYears, newTermMonths);
				
				ruleResultIndicator=ruleExecutionUtil.isGreaterThan(newTerm,currentTerm);
				if(!ruleResultIndicator) {
					break;
				}					
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private long calculateTerm(long termYears, long termMonths) {
		return termYears*12 + termMonths;
	}

	private boolean checkifRuleApplicable(List<RuleResult> ruleResults){				
	
		for (RuleResult ruleResult : ruleResults) {
			if(RuleConstant.DECISIONBR_16.equals(ruleResult.getRuleId())){
				if(!ruleResult.isRuleApplicable() || (ruleResult.isRuleApplicable() && ruleResult.isRulePassed())){
					return true;
				}
			}
		}	

		return false;
	}
	
	
	private List<Product> getProductsWithTerms(List<Product> productList){
		List<Product> applicableProductList = new ArrayList<Product>();
		for (Product product : productList){
			if(null!=product.getProposedTerm() && null!=product.getCurrentTerm()){
				applicableProductList.add(product);
			}
		}
		return applicableProductList;
	}
	
}
