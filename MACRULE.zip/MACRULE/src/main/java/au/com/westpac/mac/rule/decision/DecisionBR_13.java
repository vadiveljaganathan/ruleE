package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.Trust;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_13")
public class DecisionBR_13 extends Rule{

	private static final int CUSTOMER_TYPE = 1;
	private static final int TRUST_TYPE = 2;	

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		List<Long>applicableCustomerList =checkifRuleApplicable(dealDetails); 
		boolean isRuleApplicable = applicableCustomerList.size()>0;
		if(isRuleApplicable){
			ruleResultIndicator = anyTrustWithInvlidLegalStructure(dealDetails, applicableCustomerList);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean anyTrustWithInvlidLegalStructure(DealDetails dealDetails, List<Long> applicableCustomerList){
		List<Trust> trustList = dealDetails.getTrusts();
		for(Long customerId : applicableCustomerList){
			for(Trust trust : trustList){
				if(customerId == trust.getId()){
					if(ruleExecutionUtil.isContains(ruleConfigMap, TRUST_TYPE, trust.getTrustTypeId())){
						return false;
					}
				}
			}
		}
		return true;
	}
	
	private List<Long> checkifRuleApplicable(DealDetails dealDetails) {
		List<Long>applicableCustomerList = new ArrayList<Long>();
		if (null != dealDetails.getCustomer()) {
			for(Product product : dealDetails.getProducts()){
				for(AccountOwnerCustomer aoc : dealDetails.getAccountOwnerCustomer()){
					if(product.getBorrower().getId() == aoc.getAccountOwnerId()){
						for (Customer customer : dealDetails.getCustomer()) {
							if(customer.getId() == aoc.getCustomerId()){
								if(ruleExecutionUtil.isContains(ruleConfigMap, CUSTOMER_TYPE, customer.getCustomerTypeId())){
								applicableCustomerList.add(customer.getId());
							}
						}
					  }
				   }
				}
			}
		}
		return applicableCustomerList;
	}
}
