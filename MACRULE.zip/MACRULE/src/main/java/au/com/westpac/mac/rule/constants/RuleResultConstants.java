package au.com.westpac.mac.rule.constants;

public class RuleResultConstants {
	
	private RuleResultConstants() {
		
	}

	public static final String PASS = "Yes";
	
	public static final String FAIL = "No";
	
	public static final String NOT_APPLICABLE = "NA";
}
