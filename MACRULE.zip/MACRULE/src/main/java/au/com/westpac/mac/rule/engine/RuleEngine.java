package au.com.westpac.mac.rule.engine;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.constants.ChecklistConstants;
import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.rulegroup.RuleGroup;
import au.com.westpac.mac.rule.rulegroup.RuleGroupConstant;
import au.com.westpac.mac.rule.util.RuleUtil;

public class RuleEngine {

	@Autowired
	protected RuleUtil ruleUtil;

	/**
	 * Retrieves RuleEngine
	 * @return
	 */
	public static final RuleEngine getEngine() {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"rule-services.xml");
		return (RuleEngine) context.getBean("ruleEngine");
	}

	/**
	 * Its the starting point for invoking rule engine.
	 * @param arg
	 * @return ruleResult list
	 */
	public List<RuleResult> processRequest(Object arg)  {
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		if(arg instanceof DealDetails){
			executeRuleEngineForDecision(arg, ruleEngineResult, exec);
		}else if (arg instanceof LVRDetails
				&& null != ruleUtil
				.getCheckList(ChecklistConstants.LVR_CHECKLIST)) {
			executeRuleEngineForLVR(arg, ruleEngineResult, exec);
			
		}else if (arg instanceof Product){
			executeRuleEngineForProduct(arg, ruleEngineResult, exec);
		}
		return ruleEngineResult;
	}
	
	private void executeRuleEngineForDecision(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) {
		DealDetails dealDetails = (DealDetails) arg;
		RuleComponent firstStep = null;
		firstStep =  getFirstStepForDecisionRules(dealDetails);
		firstStep.execute(arg,ruleEngineResult, exec);
	}

	private void executeRuleEngineForLVR(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) {
		RuleComponent firstStep = null;
		firstStep = ruleUtil.getCheckList(ChecklistConstants.LVR_CHECKLIST);
		firstStep.execute(arg,ruleEngineResult, exec);
	}

	private void executeRuleEngineForProduct(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) {
		RuleComponent firstStep = null;
		String ruleGroupId = "PRDRG"+((Product) arg).getProductCategroy().getProductTypeId();
		firstStep = ruleUtil.getRuleGroup("ProductRuleGroup");
		firstStep.setId(ruleGroupId);
		firstStep.execute(arg,ruleEngineResult, exec);
	}


	
	private RuleComponent getFirstStepForDecisionRules(DealDetails dealDetails){
		short indicator = dealDetails.getRuleStateId();
		RuleGroup ruleGroup = ruleUtil.getRuleGroup("DecisionRuleGroup");
		switch (indicator){

		case 1:
			 ruleGroup.setId(RuleGroupConstant.DEC_RG_1);
			 break;			
		case 3:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_2);
			break;			
		case 5:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_3);
			break;
		case 7:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_4);
			break;
		case 9:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_5);
			break;
		case 10:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_6);
			break;
		case 11:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_10);
			break;
		case 12:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_14);
			break;
		default:
			ruleGroup.setId(RuleGroupConstant.DEC_RG_1);
			break;
		}
		return ruleGroup;
	}

}

