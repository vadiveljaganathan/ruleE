package au.com.westpac.mac.rule.decision;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;
@Component("DecisionBR_31")
public class DecisionBR_31 extends Rule {
	private static final int PRODUCT_TYPE = 1;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);
		if (isRuleApplicable) {
			// Temporary Overdraft request is within policy, including:
			// - Term (<= 45 days since the initial excess)
			// - Account is not currently out of order, except where the current
			// excess complies with the Account Manager Excess authority rules

			if (dealDetails.getDeal().isTempOverDraftWithinPolicy()) {
				ruleResultIndicator = true;
			}
		} else {
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check entry criteria for Rule DecisionBR_31
	 * 
	 * @param dealDetails
	 * @return
	 */
	private boolean isRuleApplicable(DealDetails dealDetails) {
		// Any of the modified/new products has a Product Type =
		// "Temporary Overdraft"
		return ruleExecutionUtil.checkIfProductWithGivenTypeIsPresentInList(
				dealDetails.getProducts(), ruleConfigMap, PRODUCT_TYPE);
	}

	/**
	 * Method to check any of the modified/new products has a Product
	 * Type="Temporary Overdraft"
	 * 
	 * @param productList
	 * @param ruleConfigMap
	 * @param index
	 * @return
	 */
	public boolean checkIfProductWithGivenTypeIsPresentInList(
			List<Product> productList, Map<Integer, String> ruleConfigMap,
			int index) {
		if (null == productList) {
			return false;
		}			
		for (Product product : productList) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, index, product
					.getProductCategroy().getProductTypeId())) {
				return true;
			}
		}
		return false;
	}
}
