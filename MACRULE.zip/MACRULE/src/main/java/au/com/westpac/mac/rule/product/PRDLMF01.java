package au.com.westpac.mac.rule.product;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDLMF01")
@Scope("prototype")
public class PRDLMF01 extends ProductRule {
	
	private static final int LOAN_MAINTENENCE_FEE = 1;

	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		
		if(null!=productFeeList && !productFeeList.isEmpty()){
			for (ProductFee productFee : productFeeList) {
				if(null != productFee ){
					if ((productFee.getFeeTypeId() == RuleConstant.LOAN_MAINTENANCE_FEE_TYPE_ID)) {
						productFee.setFeeAmount(Double.valueOf(ruleConfigMap
								.get(LOAN_MAINTENENCE_FEE)));
						ruleResultIndicator = ruleExecutionUtil.isEqual(ruleConfigMap,
								LOAN_MAINTENENCE_FEE, productFee.getFeeAmount());
					}

				}
	
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}
		
	}


