package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDCRM01")
@Scope("prototype")
public class PRDCRM01 extends ProductRule {
	
	private static final int CUSTOMER_RISK_MARGIN = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(null != product.getProductInterestRate() && null == product.getProductInterestRate().getCustomerRiskMargin() ){
		product.getProductInterestRate().setCustomerRiskMargin(Double.valueOf(ruleConfigMap.get(CUSTOMER_RISK_MARGIN)));
		ruleResultIndicator = ruleExecutionUtil.isEqual(ruleConfigMap, CUSTOMER_RISK_MARGIN, product.getProductInterestRate().getCustomerRiskMargin());
		
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
