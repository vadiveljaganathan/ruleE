package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_16")
public class DecisionBR_16 extends Rule {

	private static final int PRODUCT_FAMILYID_1 = 1;
	private static final int PRODUCT_FAMILYID_2 = 2;
	private static final int PRODUCT_FAMILYID_3 = 3;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {

		boolean ruleResultIndicator = false;

		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails, ruleResults);

		if (isRuleApplicable) {
			ruleResultIndicator = ruleCondition1(dealDetails)
					&& ruleCondition3(dealDetails);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

	private boolean isRuleApplicable(DealDetails dealDetails,
			List<RuleResult> ruleResults) {
		// has passed DecisionBR_11 to DecisionBR_15 and up to DecisionBR_7
		if(dealDetails.isRolloverDeal()){
			return false;
		}
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}
		return true;
	}

	private boolean ruleCondition1(DealDetails dealDetails) {

		BigDecimal sumOfLimitChangeAmount1 = sumOfLimitChangeAmount(dealDetails,PRODUCT_FAMILYID_1);
		BigDecimal sumOfLimitChangeAmount2 = sumOfLimitChangeAmountForBEALBONE(dealDetails,false);

		BigDecimal sumOfLimitChangeAmount = sumOfLimitChangeAmount1.add(sumOfLimitChangeAmount2);
		
		if (sumOfLimitChangeAmount.compareTo(dealDetails
				.getCustomerGroupConditionalLimit().getBtlTotalAvail()) > 0) {
			return false;		
		}		
		
		return true;
	}

	private boolean ruleCondition3(DealDetails dealDetails) {

		BigDecimal sumOfLimitChangeAmount1 = sumOfLimitChangeAmount(dealDetails,PRODUCT_FAMILYID_2);
		BigDecimal sumOfLimitChangeAmount2 = sumOfLimitChangeAmountForBEALBONE(dealDetails,true);
		BigDecimal sumOfLimitChangeAmount = sumOfLimitChangeAmount1.add(sumOfLimitChangeAmount2);
		
		if (sumOfLimitChangeAmount.compareTo(dealDetails
				.getCustomerGroupConditionalLimit().getBodTotalAvail()) > 0) {
			return false;
		}
		
		return true;
	}

	private BigDecimal sumOfLimitChangeAmount(DealDetails dealDetails,
			int configId) {
		BigDecimal sumOfLimitChangeAmount = BigDecimal.ZERO;

		if (dealDetails.getProducts().isEmpty()) {
			return sumOfLimitChangeAmount;
		}
		for (Product product : dealDetails.getProducts()) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, configId, product
					.getProductCategroy().getProductFamilyId())
					&& null != product.getLimitChangeAmount()) {

				sumOfLimitChangeAmount = sumOfLimitChangeAmount.add(product
						.getLimitChangeAmount());

			}
		}
		return sumOfLimitChangeAmount;
	}
	
	
	private BigDecimal sumOfLimitChangeAmountForBEALBONE(DealDetails dealDetails,boolean isRevolvingLineOfCredit) {
		BigDecimal sumOfLimitChangeAmount = BigDecimal.ZERO;

		if (dealDetails.getProducts().isEmpty()) {
			return sumOfLimitChangeAmount;
		}
		for (Product product : dealDetails.getProducts()) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILYID_3, product
					.getProductCategroy().getProductFamilyId())
					&& null != product.getLimitChangeAmount() && (product.getIsRevolvingLineOfCredit()!=null && product.getIsRevolvingLineOfCredit().booleanValue()==isRevolvingLineOfCredit)) {

				sumOfLimitChangeAmount = sumOfLimitChangeAmount.add(product
						.getLimitChangeAmount());
			}
		}
		return sumOfLimitChangeAmount;
	}
}
