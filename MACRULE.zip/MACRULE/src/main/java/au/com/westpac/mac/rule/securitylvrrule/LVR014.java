package au.com.westpac.mac.rule.securitylvrrule;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.constants.LVRRuleConstants;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;



@Component("LVR014")
public class LVR014 extends Rule {
	
	
	
	public void makeDecision(Object arg, List<RuleResult> ruleResults)
	{
		LVRDetails lvrDetails = (LVRDetails) arg;
		boolean isRuleApplicable = false;
		int postcode = 0000;
		
		if (ruleExecutionUtil.isContains(ruleConfigMap, LVRRuleConstants.COLLATERAL_TYPE,lvrDetails.getAssetType())) {
			isRuleApplicable = true;
		}
		

		if (isRuleApplicable) {
			double assetValue = 0 ;
			if(null!= lvrDetails.getAssetValue()){
			assetValue = lvrDetails.getAssetValue().doubleValue();
			}
			if(null!=lvrDetails.getPostCode() && !lvrDetails.getPostCode().equals("")){
				postcode = Integer.parseInt(lvrDetails.getPostCode());
			}
			if ( ((ruleExecutionUtil.isGreaterThanOrEqual(
					assetValue, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.COLLATERAL_VALUE_1)) &&
					ruleExecutionUtil.isLessThan(
							assetValue, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.COLLATERAL_VALUE_2))))
						|| ((((ruleExecutionUtil.isGreaterThanOrEqual(
							postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_1)))
							&& (ruleExecutionUtil.isLessThanOrEqual(
									postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_2))))
					|| ((ruleExecutionUtil.isGreaterThanOrEqual(
							postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_3))) 
							&& (ruleExecutionUtil.isLessThanOrEqual(
									postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_4))))
					|| ((ruleExecutionUtil.isGreaterThanOrEqual(
							postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_5)))
							&& (ruleExecutionUtil.isLessThanOrEqual(
									postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_6))))
					|| ((ruleExecutionUtil.isGreaterThanOrEqual(
							postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_7)))
							&& (ruleExecutionUtil.isLessThanOrEqual(
									postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_8))))
					|| ((ruleExecutionUtil.isGreaterThanOrEqual(
							postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_9)))
							&& (ruleExecutionUtil.isLessThanOrEqual(
									postcode	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.POSTCODE_VALUE_10))))
						) && ((ruleExecutionUtil.isLessThanOrEqual(
								assetValue, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.COLLATERAL_VALUE_4))) && 
								(ruleExecutionUtil.isGreaterThan(
										assetValue	, ruleExecutionUtil.getDoubleValue(ruleConfigMap, LVRRuleConstants.COLLATERAL_VALUE_3)))) )	
					)//End if 
				{
				lvrDetails.setStandardLVRFlag(ruleExecutionUtil.getStandardLVRFlag(ruleConfigMap, LVRRuleConstants.STANDARD_LVR_FLAG));
				lvrDetails.setSystemLVR(ruleExecutionUtil.getSystemLVR(ruleConfigMap, LVRRuleConstants.SYSTEM_LVR));
			}else{
				isRuleApplicable = false;
			}
		}

		/* Add Rule Result to list of list of rule result */
		ruleExecutionUtil.addLVRRuleResult(this, ruleResults, isRuleApplicable,lvrDetails);
	}
}
