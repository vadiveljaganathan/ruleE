package au.com.westpac.mac.rule.domain;

import java.util.List;
import java.util.Map;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

public abstract class ProductRule extends Rule {
	protected Map<Integer, String> ruleConfigMap;
	protected String ruleId;
	protected String ruleName;
	
	public Map<Integer, String> getRuleConfigMap() {
		return ruleConfigMap;
	}
	public void setRuleConfigMap(Map<Integer, String> ruleConfigMap) {
		this.ruleConfigMap = ruleConfigMap;
	}
	public String getRuleId() {
		return ruleId;
	}
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	protected  abstract void makeDecision(Object arg,
			List<RuleResult> ruleResults) ;	
	@Override
	public List<RuleResult> execute(Object arg,
			List<RuleResult> ruleEngineResult,
			RuleEngineExecutionContext exec) {
		
		setValuesForRule((Product) arg);	
		exec.setExecutingRuleId(this.getId());
		
		makeDecision(arg, ruleEngineResult);
		
		return ruleEngineResult;
	}
	public void setValuesForRule(Product product) {
		this.ruleId = this.getClass().getSimpleName();
		ruleConfigMap = ruleUtil.getRuleConfigMap("PRDRG"+ product.getProductCategroy().getProductTypeId()+this.getClass().getSimpleName());
	}
	
}
