/**
 *
 */
package au.com.westpac.mac.rule.domain;

/**
 * @author l056819
 *
 */
public class LVRRuleResult extends RuleResult{
	private int		systemLVR;
	private boolean	isStandardLVR;

	public int getSystemLVR() {
		return systemLVR;
	}

	public void setSystemLVR(int systemLVR) {
		this.systemLVR = systemLVR;
	}

	public boolean getIsStandardLVR() {
		return isStandardLVR;
	}

	public void setStandardLVR(boolean isStandardLVR) {
		this.isStandardLVR = isStandardLVR;
	}

}
