package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.deal.DealRiskProfile;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.request.Serviceability;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("FinancialCheckRule")
public class FinancialCheckRule extends Rule{

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean isRuleApplicable = isRuleApplicable();
		boolean ruleResultIndicator = true;
		if(isRuleApplicable){
			ruleResultIndicator = checkIfServiceabilityIsCompleted(dealDetails)  &&
					checkIfServiceabiltyIsCompleted(dealDetails.getServiceability());
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}


	private boolean checkIfServiceabilityIsCompleted(DealDetails dealDetails){
		if(null == dealDetails.getServiceability()){
			return false;
		}
		return true;
	}
	private boolean checkIfServiceabiltyIsCompleted(
			Serviceability serviceability) {
		if(serviceability.getICR() == null || serviceability.getDSC() == null){
			return false;
		}
		return true;
	}



	private boolean checkIfACRPIsCompleted(
			DealRiskProfile customerGroupRiskProfile) {
		
		if(customerGroupRiskProfile.getEquityRiskRankingId()==0 ||  
				customerGroupRiskProfile.getManagementRiskRankingId() == 0 ||
				customerGroupRiskProfile.getOverallRiskRankingId()  == 0 ||
				customerGroupRiskProfile.getSecurityRiskRankingId()  == 0 ||
				customerGroupRiskProfile.getServiceabilityRiskRankingId()  == 0 ||
				customerGroupRiskProfile.getTransactionRiskRankingId() == 0){
			return false;
		}else {
			if(null ==customerGroupRiskProfile.getEquityRiskComments() || customerGroupRiskProfile.getEquityRiskComments().isEmpty() ||
					null ==customerGroupRiskProfile.getManagementRiskComments() || customerGroupRiskProfile.getManagementRiskComments().isEmpty() ||
					null ==customerGroupRiskProfile.getTransactionRiskComments() || customerGroupRiskProfile.getTransactionRiskComments().isEmpty() ||
					null ==customerGroupRiskProfile.getServiceabilityRiskComments() || customerGroupRiskProfile.getServiceabilityRiskComments().isEmpty() ||
					null ==customerGroupRiskProfile.getSecurityRiskComments() || customerGroupRiskProfile.getSecurityRiskComments().isEmpty()||
					null ==customerGroupRiskProfile.getOverallRiskComments() || customerGroupRiskProfile.getOverallRiskComments().isEmpty()){
				return false;
			}
		}
		return true;
	}

	private boolean isRuleApplicable() {
		return true;
	}

}

