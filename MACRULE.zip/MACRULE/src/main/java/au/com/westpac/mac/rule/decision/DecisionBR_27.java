package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_27")
public class DecisionBR_27 extends Rule {

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(ruleResults);
		if (isRuleApplicable) {
			// Does this request override or modify a Credit decision or
			// directive, including previously declined credit requests = FALSE?
			if (dealDetails.getDeal().isApprovalOverrideCreditDecision()) {
				ruleResultIndicator = true;
			}
		} else {
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

	/**
	 * Method to check entry criteria for rule.
	 * 
	 * @param dealDetails
	 * @param ruleResults
	 * @return
	 */
	private boolean isRuleApplicable(List<RuleResult> ruleResults) {
		// passed DecisionBR_17 to DecisionBR_26; DecisionBR_11 to
		// DecisionBR_15; and up to DecisionBR_7
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15, RuleConstant.DECISIONBR_17,
						RuleConstant.DECISIONBR_18, RuleConstant.DECISIONBR_19,
						RuleConstant.DECISIONBR_20, RuleConstant.DECISIONBR_21,
						RuleConstant.DECISIONBR_22, RuleConstant.DECISIONBR_23,
						RuleConstant.DECISIONBR_24, RuleConstant.DECISIONBR_25,
						RuleConstant.DECISIONBR_26,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}

		return true;
	}

}
