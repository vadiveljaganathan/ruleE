package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.util.MACDomainUtil;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_11")
public class DecisionBR_11 extends Rule{
	private static final int CUSTOMER_TYPE = 1;
	private static final int ANZSIC_LENGTH = 2;
	private static final int NONPROFIT_ORG_ANZSIC = 3;

	//Business Structure != Not For Profit Organisation
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {	
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		List<Customer> applicableCustomers =checkifRuleApplicable(dealDetails); 
		boolean isRuleApplicable = applicableCustomers.size()>0;
		if(isRuleApplicable){
			List<NonIndividual> nonIndividualist=dealDetails.getNonIndividualCustomers();
			for(Customer customer : applicableCustomers){
				for(NonIndividual nonIndividual : nonIndividualist){
					if(customer.getId() == nonIndividual.getId()){
						ruleResultIndicator = true;
						String anzsicCode = nonIndividual.getAnzsicCode();
						int index = Integer.valueOf(ruleConfigMap.get(ANZSIC_LENGTH))-1;
						if(!MACDomainUtil.isEmptyString(anzsicCode) && ruleExecutionUtil.isEqual(ruleConfigMap, ANZSIC_LENGTH, anzsicCode.length()) 
								&& ruleExecutionUtil.isContains(ruleConfigMap,NONPROFIT_ORG_ANZSIC, anzsicCode.charAt(index))){
							ruleResultIndicator=false;
							ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
							return;
						}
					}
				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	
	//A Borrowing entity involved in the deal is a non-individual; Customer Type  = non-individual
	private List<Customer> checkifRuleApplicable(DealDetails dealDetails) {
		List<Customer> customerList = dealDetails.getCustomer();
		List<Customer> applicableCustomers = new ArrayList<Customer>();
		if (!dealDetails.isRolloverDeal()) {
			for (Product product : dealDetails.getProducts()) {
				for (AccountOwnerCustomer acustomer : dealDetails
						.getAccountOwnerCustomer()) {
					if (product.getBorrower().getId() == acustomer
							.getAccountOwnerId()) {
						for (Customer customer : customerList) {
							if (acustomer.getCustomerId() == customer.getId()) {
								if (ruleExecutionUtil.isContains(ruleConfigMap,
										CUSTOMER_TYPE,
										customer.getCustomerTypeId())) {
									applicableCustomers.add(customer);
								}
							}
						}
					}
				}
			}
		}
		return applicableCustomers;
	}

}
