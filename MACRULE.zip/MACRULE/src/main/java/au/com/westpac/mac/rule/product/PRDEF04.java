package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

/*
 * This Rule will be applicable for Business OverDraft Family ,SubType Temporary Overdraft - Business
 * Establishment Fee=
 Purchase Amount / Requested Amount (ID 146)
 $100 < $20,000
 $250 between  $20,001 - $50,000 
 $350 plus 0.20% of the amount above $50,000
 */

@Component("PRDEF04")
@Scope("prototype")
public class PRDEF04 extends ProductRule {

	private static final int ESTABLISHMENT_FEE1 = 1;// 100
	private static final int ESTABLISHMENT_FEE2 = 2;// 250
	private static final int ESTABLISHMENT_FEE3 = 3;// 350+20%Amount
	private static final int PURCHASE_AMOUNT1 = 4;// <20000
	private static final int PURCHASE_AMOUNT2 = 5;// 20001-50000
	private static final int PURCHASE_AMOUNT3 = 6;// >50000
	private static final int PERCENTAGE = 7;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {

					if (null != product.getProductValidation()
							&& null != product.getProductValidation()
									.getResultantAmount()) {

						if (ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap,
								PURCHASE_AMOUNT1, product
										.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(ESTABLISHMENT_FEE1)));

						} else if (ruleExecutionUtil.isGreaterThan(
								ruleConfigMap, PURCHASE_AMOUNT2, product
										.getProductValidation()
										.getResultantAmount().doubleValue())
								&& ruleExecutionUtil.isLessThan(ruleConfigMap,
										PURCHASE_AMOUNT3, product
												.getProductValidation()
												.getResultantAmount()
												.doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(ESTABLISHMENT_FEE2)));
						} else if (ruleExecutionUtil.isGreaterThan(
								ruleConfigMap, PURCHASE_AMOUNT3, product
										.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							double estFee = 0;
							double estFeeConfig = ruleExecutionUtil
									.getDoubleValue(ruleConfigMap,
											ESTABLISHMENT_FEE3);
							double estFeePercent = ruleExecutionUtil
									.getDoubleValue(ruleConfigMap, PERCENTAGE);
							double amoutAbovePurchaseAmount = product
									.getProductValidation()
									.getResultantAmount().doubleValue()
									- Double.parseDouble((ruleConfigMap
											.get(PURCHASE_AMOUNT3)));
							estFee = ruleExecutionUtil.calcAmountOnPercent(
									amoutAbovePurchaseAmount, estFeePercent);
							estFee = estFeeConfig + estFee;
							productFee.setFeeAmount(estFee);
						}
					}
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
