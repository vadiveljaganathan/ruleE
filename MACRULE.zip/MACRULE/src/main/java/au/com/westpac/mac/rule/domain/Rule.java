package au.com.westpac.mac.rule.domain;

import java.util.List;
import java.util.Map;

import au.com.westpac.mac.rule.constants.RuleActionConstants;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.rulegroup.RuleGroup;

public abstract class Rule extends RuleComponent {

	protected Map<Integer, String> ruleConfigMap;
	protected String ruleId;
	protected String ruleName;

	protected  abstract void makeDecision(Object arg,
			List<RuleResult> ruleResults) ;		

	public void setRuleConfigMap(Map<Integer, String> ruleConfigMap) {
		this.ruleConfigMap = ruleConfigMap;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public List<RuleResult> execute(Object arg,
			List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec) {

		setValuesForRule();
		exec.setExecutingRuleId(this.getRuleId());

		makeDecision(arg, ruleEngineResult);
		RuleResult ruleResult = null;
		if (ruleEngineResult != null && !ruleEngineResult.isEmpty()) {
			ruleResult = ruleEngineResult.get(ruleEngineResult.size() - 1);
		}
		if (ruleResult != null) {

			int nextStep = -1;

			RuleExecutionActionParams ruleExeAcnParmas = ruleUtil
					.getExecutionActionParamsForRule(
							exec.getExecutingRuleGroupId(),
							exec.getExecutingRuleId());
			nextStep = getNextStepIndicator(ruleResult, exec, ruleExeAcnParmas);

			if (nextStep == RuleActionConstants.GO_TO_NEXT_RULE) {
				
				if(!ruleResult.isRuleApplicable){
					ruleResult.setNextRuleId(ruleExeAcnParmas.getNotApplicableNextId());
					ruleUtil.getRule(ruleExeAcnParmas.getNotApplicableNextId()).execute(
							arg, ruleEngineResult, exec);
				}else if(ruleResult.isRulePassed()){
					ruleResult.setNextRuleId(ruleExeAcnParmas.getSuccessNextId());

					ruleUtil.getRule(ruleExeAcnParmas.getSuccessNextId()).execute(
							arg, ruleEngineResult, exec);
				}else{
					ruleResult.setNextRuleId(ruleExeAcnParmas.getFailureNextId());

					ruleUtil.getRule(ruleExeAcnParmas.getFailureNextId()).execute(
							arg, ruleEngineResult, exec);
				}
			} else if (nextStep == RuleActionConstants.GO_TO_NEXT_RULE_GROUP) {
				RuleGroup ruleGroup = ruleUtil.getRuleGroup("DecisionRuleGroup");
				if(!ruleResult.isRuleApplicable){
					ruleResult.setNextRuleGroupId(ruleExeAcnParmas.getNotApplicableNextId());
					ruleResult.setGoToNextRuleGroup(true);
				}else if(ruleResult.isRulePassed()){
				ruleResult.setNextRuleGroupId(ruleExeAcnParmas
						.getSuccessNextId());
				ruleResult.setGoToNextRuleGroup(true);
				return ruleEngineResult;
				}else{
					ruleResult.setNextRuleGroupId(ruleExeAcnParmas
							.getFailureNextId());
					ruleResult.setGoToNextRuleGroup(true);
					ruleGroup.setId(ruleExeAcnParmas
							.getFailureNextId());
					return ruleEngineResult;
				}
			}else if (nextStep == RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_CONDITIONAL_LIMITS) {
				ruleResult.setExit(true);
				ruleResult.setConditionallyApproved(true);
				return ruleEngineResult;
			}else if (nextStep == RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_YOUR_LENDING_AUTHORITY) {
				ruleResult.setExit(true);
				ruleResult.setApprovedUnderLendingAuthority(true);
				return ruleEngineResult;
			}else if (nextStep == RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_ROLLOVER_POLICY) {
				ruleResult.setExit(true);
				ruleResult.setApprovedUnderRolloverPolicy(true);
				return ruleEngineResult;
			}else if (nextStep == RuleActionConstants.COMPLETE_FINANCIALS) {
				ruleResult.setExit(true);
				ruleResult.setFinancialsRequired(true);
				return ruleEngineResult;
			}else if (nextStep == RuleActionConstants.REFER_TO_CREDIT) {
				ruleResult.setExit(true);
				ruleResult.setReferToCredit(true);
				return ruleEngineResult;
			} else if (nextStep == RuleActionConstants.FOR_REVIEW) {
				ruleResult.setExit(true);
				ruleResult.setReviewRequired(true);
				return ruleEngineResult;
			}else if (nextStep == RuleActionConstants.NO_DECISION) {
				ruleResult.setExit(true);
				ruleResult.setSecurityAllocationRequired(true);
				return ruleEngineResult;
			}

		}
		return ruleEngineResult;
	}


	private int getNextStepIndicator(RuleResult ruleResult, RuleEngineExecutionContext exec, RuleExecutionActionParams ruleExeAcnParmas){
		int nextStep = -1;
		if(!ruleResult.isRuleApplicable){
			nextStep = determineNextAction(ruleExeAcnParmas.getNotApplicableActionId());
		}else if (ruleResult.isRulePassed()) {
			nextStep = determineNextAction(ruleExeAcnParmas
					.getSuccessActionId());
		} else if(!ruleResult.isRulePassed()) {
			nextStep = determineNextAction(ruleExeAcnParmas
					.getFailureActionId());
		}
		return nextStep;
	}

	private int determineNextAction(int actionId) {

		switch (actionId) {
		case RuleActionConstants.GO_TO_NEXT_RULE:
			return RuleActionConstants.GO_TO_NEXT_RULE;
		case RuleActionConstants.GO_TO_NEXT_RULE_GROUP:
			return RuleActionConstants.GO_TO_NEXT_RULE_GROUP;
		case RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_CONDITIONAL_LIMITS:
			return RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_CONDITIONAL_LIMITS;
		case RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_YOUR_LENDING_AUTHORITY:
			return RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_YOUR_LENDING_AUTHORITY;
		case RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_ROLLOVER_POLICY:
			return RuleActionConstants.CONDITIONALLY_APPROVED_UNDER_ROLLOVER_POLICY;
		case RuleActionConstants.COMPLETE_FINANCIALS:
			return RuleActionConstants.COMPLETE_FINANCIALS;
		case RuleActionConstants.REFER_TO_CREDIT:
			return RuleActionConstants.REFER_TO_CREDIT;
		case RuleActionConstants.FOR_REVIEW:
			return RuleActionConstants.FOR_REVIEW;
		case RuleActionConstants.NO_DECISION:
			return RuleActionConstants.NO_DECISION;
		default : return -1;
		}
	}

	public void setValuesForRule() {
		this.ruleId = this.getClass().getSimpleName();
		ruleConfigMap = ruleUtil.getRuleConfigMap(this.getClass()
				.getSimpleName());
	}	
}
