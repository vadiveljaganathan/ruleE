package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.customer.Individual;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_10")
public class DecisionBR_10 extends Rule {

	private static final int PRODUCT_FAMILY = 1;
	private static final int TIME_IN_CORE_BUSINESS = 2;
	private static final int TIME_IN_INDUSTRY = 4;
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {

		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(dealDetails); 
		if(isRuleApplicable){
			ruleResultIndicator = compareGuaranteeAmtAndAllocationAmt(dealDetails) && (checkTimeInCoreBusinessAndCustomerType(dealDetails) 
					|| checkTimeInIndustryAndCustomerTpye(dealDetails));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}
	private boolean checkTimeInIndustryAndCustomerTpye(DealDetails dealDetails) {
		List<Individual> individualist = dealDetails.getIndividualCustomers();
		for(Individual individual : individualist){
			if(!ruleExecutionUtil.isGreaterThanOrEqualForLong(ruleConfigMap, TIME_IN_INDUSTRY, individual.getMonthsInIndustry())){
				return false;
			}
		}
		return true;
	}
	private boolean checkTimeInCoreBusinessAndCustomerType(DealDetails dealDetails) {
		List<NonIndividual> nonIndividualist=dealDetails.getNonIndividualCustomers();
		for(NonIndividual nonIndividual : nonIndividualist){
			if(!ruleExecutionUtil.isGreaterThanOrEqualForLong(ruleConfigMap, TIME_IN_CORE_BUSINESS, nonIndividual.getTimeInCoreBusiness())){
				return false;
			}
		}
		return true;
	}

	private boolean compareGuaranteeAmtAndAllocationAmt(DealDetails dealDetails) {
		BigDecimal requestedAmount = BigDecimal.ZERO; 
		BigDecimal allocatedAmount =BigDecimal.ZERO;
		List<Product> productList = dealDetails.getProducts();
		for(Product product : productList){
			if(null!=product.getRequestedAmount()){
				requestedAmount = requestedAmount.add(product.getRequestedAmount());
			}
			if(null!=product.getAllocatedAmount()){
				allocatedAmount = allocatedAmount.add(product.getAllocatedAmount());
			}
		}
		if(ruleExecutionUtil.isGreaterThan(requestedAmount,allocatedAmount)){
			return true;
		}
		return false;
	}
	private boolean checkifRuleApplicable(DealDetails dealDetails){
		List<Product> productList=dealDetails.getProducts();	
		return ruleExecutionUtil.checkIfAllProductIsOfGivenTypeInList(productList, ruleConfigMap, PRODUCT_FAMILY);
	}
}
