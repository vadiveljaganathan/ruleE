package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_0")
public class DecisionBR_0 extends Rule {

	/*Desc : Deal facility have security Check*/
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(dealDetails);
		if(isRuleApplicable && isAllTheFacilitiesHaveSecurityInDeal(dealDetails)){
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean checkifRuleApplicable(DealDetails dealDetails){
		if(dealDetails.getProducts().size()!=0){
			for(Product product : dealDetails.getProducts()){
				if(!product.getIsExtendedInDeal()){					
					return true;
				}
			}
		}
		return false;
	}
	
	private boolean isAllTheFacilitiesHaveSecurityInDeal(DealDetails dealDetails){
		List<AssetAllocations> allocations = dealDetails.getAssetAllocations();
		List<Product> facilities = dealDetails.getProducts();
		Boolean allocated = null;	
		for(Product facility : facilities){
			if(null==allocated || allocated){
				allocated = false;
				for(AssetAllocations alloc : allocations){
					if(alloc.getProductId()==facility.getId() && alloc.getAllocatedToTypeId()==1 && alloc.getAssetId()!=0){
						if(null!=alloc.getAllocationAmount()){					
							allocated = true;
						}else if(null==alloc.getAllocationAmount()){
							allocated = false;
							break;
						}
					}
				}
			}
		}
		
		return allocated;
	}

}
