package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;


@Component("DecisionBR_22")
public class DecisionBR_22 extends Rule {
	private static final int CAL_LEVEL = 1;
	private static final int PRODUCT_FAMILY = 4;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);

		if (isRuleApplicable) {
			// Check Broker or Introducer Id is not Null
			if (null != dealDetails.getDeal()) {
				ruleResultIndicator = checkForExistingBusinessPrdouct(dealDetails
						.getProducts());
			}

		}else{
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check Entry Criteria for Rule DecisionBR_22
	 * 
	 * @param dealDetails
	 * @return
	 */

	private boolean isRuleApplicable(DealDetails dealDetails) {
		// The logged in user have a CAL Level that is 1 or 2
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel());
	}

	/**
	 * Method to check that Borrowing Entity has at least one existing business
	 * Lending facility where Product Family = (Business Term Lending,
	 * Business Overdraft, Business Credit Card or Guarantees & Bonds)
	 * 
	 * @param productList
	 * @return
	 */
	private boolean checkForExistingBusinessPrdouct(List<Product> productList) {
		for (Product product : productList) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY,
					product.getProductCategroy().getProductFamilyId()) && product.isExistingProduct()) {
				return true;
			}
		}
		return false;
	}

}
