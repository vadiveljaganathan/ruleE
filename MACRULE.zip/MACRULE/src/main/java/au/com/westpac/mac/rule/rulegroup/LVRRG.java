package au.com.westpac.mac.rule.rulegroup;

import org.springframework.stereotype.Component;

@Component("LVRRG")
public class LVRRG extends RuleGroup {

}
