package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_42")
public class DecisionBR_42 extends Rule{
	
	private static final int CURRENT_LIMIT = 1;
	
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(ruleResults,dealDetails);
		
		BigDecimal currentLimit = ruleExecutionUtil.getBigDecimalValue(ruleConfigMap,CURRENT_LIMIT);
		if(isRuleApplicable){			
			for(Product product : dealDetails.getProducts()){
				BigDecimal extendedFacilityCurrentLimit = product.getCurrentLimit();
				BigDecimal extendedFacilityProposedLimit = product.getProposedLimit();
				if(null==extendedFacilityProposedLimit){
					ruleResultIndicator = ruleExecutionUtil.isLessThanOrEqual(extendedFacilityCurrentLimit,currentLimit.doubleValue());	
				}else {
					ruleResultIndicator = ruleExecutionUtil.isLessThanOrEqual(extendedFacilityProposedLimit,currentLimit.doubleValue());
				}
				
				if(!ruleResultIndicator)
					break;
			}			
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean checkifRuleApplicable(List<RuleResult> ruleResults,DealDetails dealDetails){
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,RuleConstant.DECISIONBR_2,
						RuleConstant.DECISIONBR_4,RuleConstant.DECISIONBR_6,						
						RuleConstant.DECISIONBR_13,RuleConstant.DECISIONBR_15));
		if(dealDetails.isRolloverDeal()){
		for (RuleResult ruleResult : ruleResults) {
			if(requiredRuleNameList.contains(ruleResult.getRuleId())){
				if(ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()){
					return false;
				}
			}
		}
		}else{
			for (RuleResult ruleResult : ruleResults) {
				if(RuleConstant.DECISIONBR_49.equals(ruleResult.getRuleId())){
					if(ruleResult.isRulePassed()){
						return true;
					}
				}
			}
		}
		return true;
	}
	
}

