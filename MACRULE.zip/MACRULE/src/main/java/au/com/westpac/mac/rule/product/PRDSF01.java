package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDSF01")
@Scope("prototype")
public class PRDSF01 extends ProductRule {
	
	private static final int SERVICE_FEE_MIN = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(null !=  product.getFulfillment() && null != product.getFulfillment().getServiceFeePercentage() ){
		ruleResultIndicator = ruleExecutionUtil.isGreaterThanOrEqual(ruleConfigMap, SERVICE_FEE_MIN, product.getFulfillment().getServiceFeePercentage());
		
		product.getFulfillment().setServiceFeePercentageMin(Double.valueOf(ruleConfigMap.get(SERVICE_FEE_MIN)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
