package au.com.westpac.mac.rule.constants;

public class RuleConstant {

	public static final String DECISIONBR_1 = "DecisionBR_1";
	public static final String DECISIONBR_2 = "DecisionBR_2";
	public static final String DECISIONBR_3 = "DecisionBR_3";
	public static final String DECISIONBR_4 = "DecisionBR_4";
	public static final String DECISIONBR_5 = "DecisionBR_5";
	public static final String DECISIONBR_6 = "DecisionBR_6";
	public static final String DECISIONBR_7 = "DecisionBR_7";
	public static final String DECISIONBR_8 = "DecisionBR_8";
	public static final String DECISIONBR_9 = "DecisionBR_9";
	public static final String DECISIONBR_10 = "DecisionBR_10";
	public static final String DECISIONBR_11 = "DecisionBR_11";
	public static final String DECISIONBR_12 = "DecisionBR_12";
	public static final String DECISIONBR_13 = "DecisionBR_13";
	public static final String DECISIONBR_14 = "DecisionBR_14";
	public static final String DECISIONBR_15 = "DecisionBR_15";
	public static final String DECISIONBR_16 = "DecisionBR_16";
	public static final String DECISIONBR_17 = "DecisionBR_17";
	public static final String DECISIONBR_18 = "DecisionBR_18";
	public static final String DECISIONBR_19 = "DecisionBR_19";
	public static final String DECISIONBR_20 = "DecisionBR_20";
	public static final String DECISIONBR_21 = "DecisionBR_21";
	public static final String DECISIONBR_22 = "DecisionBR_22";
	public static final String DECISIONBR_23 = "DecisionBR_23";
	public static final String DECISIONBR_24 = "DecisionBR_24";
	public static final String DECISIONBR_25 = "DecisionBR_25";
	public static final String DECISIONBR_26 = "DecisionBR_26";
	public static final String DECISIONBR_27 = "DecisionBR_27";
	public static final String DECISIONBR_28 = "DecisionBR_28";
	public static final String DECISIONBR_29 = "DecisionBR_29";
	public static final String DECISIONBR_30 = "DecisionBR_30";
	public static final String DECISIONBR_31 = "DecisionBR_31";
	public static final String DECISIONBR_32 = "DecisionBR_32";
	public static final String DECISIONBR_33 = "DecisionBR_33";
	public static final String DECISIONBR_34 = "DecisionBR_34";
	public static final String DECISIONBR_35 = "DecisionBR_35";
	public static final String DECISIONBR_36 = "DecisionBR_36";
	public static final String DECISIONBR_37 = "DecisionBR_37";
	public static final String DECISIONBR_38 = "DecisionBR_38";
	public static final String DECISIONBR_42 = "DecisionBR_42";
	public static final String DECISIONBR_43 = "DecisionBR_43";
	public static final String DECISIONBR_44 = "DecisionBR_44";
	public static final String DECISIONBR_45 = "DecisionBR_45";
	public static final String DECISIONBR_46 = "DecisionBR_46";
	public static final String DECISIONBR_47 = "DecisionBR_47";
	public static final String DECISIONBR_49 = "DecisionBR_49";
	public static final int LOAN_SERVICE_FEE_TYPE_ID = 41;
	public static final int ESTABLISHMENT_FEE_TYPE_ID = 26;
	public static final int TOP_UP_FEE_TYPE_ID = 80;
	public static final int LINE_FEE_TYPE_ID = 39;
	public static final int OVERDRAFT_FACILITY_FEE_TYPE_ID = 52;
	
	public static final String FINANCIALCHECKRULE = "FinancialCheckRule";
	
	public static final short INDIVIDUAL = 1;
	public static final short NON_INDIVIDUAL = 2;
	public static final short TRUST = 3;
	
	public static final int GX_SERVICE_FEE_TYPE_ID = 31;
	public static final int LOAN_MAINTENANCE_FEE_TYPE_ID = 40;
}
