package au.com.westpac.mac.rule.entity;

public class CheckListRuleGroup {

}
