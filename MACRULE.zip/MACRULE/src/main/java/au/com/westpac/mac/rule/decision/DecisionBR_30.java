package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;
@Component("DecisionBR_30")
public class DecisionBR_30 extends Rule {
	private static final int CAL_LEVEL = 2;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);
		if (isRuleApplicable) {
			// Is the borrower trading with a positive net worth and is
			// solvent?" = TRUE?
			if (dealDetails.getDeal().isBrwerTradingPositveNetWorthAndSolvent()) {
				ruleResultIndicator = true;
			}
		}else {
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check entry criteria for Rule DecisionBR_30
	 * 
	 * @param dealDetails
	 * @return
	 */
	private boolean isRuleApplicable(DealDetails dealDetails) {
		// The logged in user have a CAL Level that is 4 or 5
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel());
	}

}
