package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Fulfillment;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDFD01")
@Scope("prototype")
public class PRDFD01 extends ProductRule {
	
	private static final int FACILITY_DRAWDOWN_SELF_SERIVICE = 1;
	private static final int FACILITY_DRAWDOWN_STAFF_ASSISTED = 2;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		Fulfillment fullFulfillment = product.getFulfillment();
		if(null != fullFulfillment){
			ruleResultIndicator = ruleExecutionUtil.isGreaterThanOrEqualBigDecimal(ruleConfigMap, FACILITY_DRAWDOWN_SELF_SERIVICE, fullFulfillment.getFacilityDrawDownFeeAmount()) ||
					ruleExecutionUtil.isGreaterThanOrEqualBigDecimal(ruleConfigMap, FACILITY_DRAWDOWN_STAFF_ASSISTED, fullFulfillment.getFacilityDrawDownFeeAmount());
			if(null == fullFulfillment.getFacilityDrawDownFeeAmountMax()){
				fullFulfillment.setFacilityDrawDownFeeAmountMin(Double.parseDouble(ruleConfigMap.get(FACILITY_DRAWDOWN_SELF_SERIVICE)));
			}
			if(null == fullFulfillment.getFacilityDrawDownFeeAmountMax()){
				fullFulfillment.setFacilityDrawDownFeeAmountMax(Double.parseDouble(ruleConfigMap.get(FACILITY_DRAWDOWN_STAFF_ASSISTED)));
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}

