package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDEF01")
@Scope("prototype")
public class PRDEF01 extends ProductRule {

	private static final int ESTABLISHMENT_FEE = 1;

	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		
		if(null!=productFeeList && !productFeeList.isEmpty()){
			for (ProductFee productFee : productFeeList) {
				if(null != productFee ){
					if ((productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID)) {
						productFee.setFeeAmount(Double.valueOf(ruleConfigMap
								.get(ESTABLISHMENT_FEE)));
						ruleResultIndicator = ruleExecutionUtil.isEqual(ruleConfigMap,
								ESTABLISHMENT_FEE, productFee.getFeeAmount());
					}

				}
	
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
