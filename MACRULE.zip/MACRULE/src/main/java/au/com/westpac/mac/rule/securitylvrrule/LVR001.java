package au.com.westpac.mac.rule.securitylvrrule;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.constants.LVRRuleConstants;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

/*
 * This Rule will be applicable for Applies to all Collateral Family = Real Estate
 * Ownership Type (L63) in  (Leasehold, Other) OR Postcode (TLAS092) = 0000
 */

@Component("LVR001")
public class LVR001 extends Rule {	
	public void makeDecision(Object arg, List<RuleResult> ruleResults)
	{
		LVRDetails lvrDetails = (LVRDetails) arg;
		boolean isRuleApplicable = false;

		/* applicable only if Asset Family = "Real Estate" */
		if (ruleExecutionUtil.isContains(ruleConfigMap, LVRRuleConstants.COLLATERAL_FAMILY,
				lvrDetails.getAssetFamily())) {
			isRuleApplicable = true;
		}

		if (isRuleApplicable) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, LVRRuleConstants.OWNERSHIP_TYPE_L63,
					lvrDetails.getOwnershipTypeId())
					|| ruleExecutionUtil.isContains(ruleConfigMap,
							LVRRuleConstants.POSTCODE, lvrDetails.getPostCode())) {
				lvrDetails.setStandardLVRFlag(ruleExecutionUtil.getStandardLVRFlag(ruleConfigMap, LVRRuleConstants.STANDARD_LVR_FLAG));
				lvrDetails.setSystemLVR(ruleExecutionUtil.getSystemLVR(ruleConfigMap, LVRRuleConstants.SYSTEM_LVR));
			}else{
				isRuleApplicable = false;
			}
		}

		/* Add Rule Result to list of list of rule result */
		ruleExecutionUtil.addLVRRuleResult(this, ruleResults, isRuleApplicable,lvrDetails);
	}
}
