package au.com.westpac.mac.rule.checklist;

import org.springframework.stereotype.Component;

@Component("LVRCL")
public class LVRCL extends CheckList {

}
