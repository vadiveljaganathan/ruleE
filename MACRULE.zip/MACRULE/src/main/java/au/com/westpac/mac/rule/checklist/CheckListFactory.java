package au.com.westpac.mac.rule.checklist;

public interface CheckListFactory {
	public CheckList lookup(String ruleGroupId); 
}
