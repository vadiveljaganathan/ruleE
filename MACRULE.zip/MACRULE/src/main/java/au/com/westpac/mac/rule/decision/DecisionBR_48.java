package au.com.westpac.mac.rule.decision;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_48")
public class DecisionBR_48 extends Rule{

	private static final int NO_OF_BORROWINGENTITY = 1;
	
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =isRuleApplicable(); 
		if (isRuleApplicable) {			
			ruleResultIndicator=ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap, NO_OF_BORROWINGENTITY, getNumberOfBorrowingEntityInDeal(dealDetails));			
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

	private boolean isRuleApplicable() {
		return true;
	}
	
	private int getNumberOfBorrowingEntityInDeal(DealDetails dealDetails){		
		Map<Long,Borrower> borrowerMap = new HashMap<Long,Borrower>();
		for(Product product : dealDetails.getProducts()){
			long borrowerId= product.getBorrower().getId();
			if(!borrowerMap.containsKey(borrowerId)){
				borrowerMap.put(borrowerId, product.getBorrower());
			}			
		}
		return borrowerMap.size();
	}
}
