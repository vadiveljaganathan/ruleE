package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;


@Component("DecisionBR_23")
public class DecisionBR_23 extends Rule {
	private static final int PRODUCT_FAMILY = 4;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails) arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = isRuleApplicable(ruleResults);
		if (isRuleApplicable) {
			ruleResultIndicator = checkForExistingBusinessPrdouct(dealDetails
					.getProducts());
		}else{
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check that Borrowing Entity has at least one existing business
	 * Lending facility where Product Family = (Business Term Lending,
	 * Business Overdraft, Business Credit Card or Guarantees & Bonds)
	 * 
	 * @param productList
	 * @return
	 */
	private boolean checkForExistingBusinessPrdouct(List<Product> productList) {
		for (Product product : productList) {
			if (!product.getIsNewFacility() && ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY,
					product.getProductCategroy().getProductFamilyId())) {
				return true;
			}
		}
		return false;
	}
	/**
	 * Method to check Entry Criteria for a rule
	 * @param dealDetails
	 * @param ruleResults
	 * @return
	 */

	private boolean isRuleApplicable(List<RuleResult> ruleResults) {
		// passed DecisionBR_17 to DecisionBR_22; DecisionBR_11 to
		// DecisionBR_15; and up to DecisionBR_7
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15, RuleConstant.DECISIONBR_17,
						RuleConstant.DECISIONBR_18, RuleConstant.DECISIONBR_19,
						RuleConstant.DECISIONBR_20, RuleConstant.DECISIONBR_21,
						RuleConstant.DECISIONBR_22,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}

		return true;
	}

}
