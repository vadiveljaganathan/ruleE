package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDSF02")
@Scope("prototype")
public class PRDSF02 extends ProductRule {
	
	private static final int SERVICE_FEE_PERCENTAGE = 1;
	private static final int MIN_SERVICE_FEE = 2;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		Double serviceFee=0.0;
		if (null != product.getProposedLimit()) {
			serviceFee = Double.parseDouble(ruleConfigMap
					.get(SERVICE_FEE_PERCENTAGE))
					* product.getProposedLimit().doubleValue() / 100;
		}
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.GX_SERVICE_FEE_TYPE_ID) {
					if(ruleExecutionUtil.isGreaterThanOrEqual(ruleConfigMap,
							MIN_SERVICE_FEE, serviceFee)){
						productFee.setFeeAmount(Double.valueOf(serviceFee));
						
					}else{
						productFee.setFeeAmount(Double.valueOf(ruleConfigMap.get(MIN_SERVICE_FEE)));
						
					}

				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
