package au.com.westpac.mac.rule.domain;

import org.springframework.context.annotation.Lazy;

@Lazy
public interface  RuleFactory {
	public Rule lookup(String ruleId); 
}
