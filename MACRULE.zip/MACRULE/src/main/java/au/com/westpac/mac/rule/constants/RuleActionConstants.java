package au.com.westpac.mac.rule.constants;

public class RuleActionConstants {
	
	private RuleActionConstants() {
		
	}
	
	public static final int  GO_TO_NEXT_RULE = 1;
	
	public static final int  GO_TO_NEXT_RULE_GROUP = 2;
	
	public static final int  CONDITIONALLY_APPROVED_UNDER_CONDITIONAL_LIMITS = 3;
	
	public static final int  GO_TO_NEXT_CHECKLIST = 4;
	
	public static final int  COMPLETE_FINANCIALS= 6;
	
	public static final int CONDITIONALLY_APPROVED_UNDER_YOUR_LENDING_AUTHORITY = 7;
	
	public static final int CONDITIONALLY_APPROVED_UNDER_ROLLOVER_POLICY = 8;
	
	public static final int REFER_TO_CREDIT = 5;

	public static final int FOR_REVIEW = 11;
	
	public static final int NO_DECISION = 12;
	
}
