package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

/*
 * This Rule will be applicable for Business OverDraft Family ,SubType Business OverDraft-RP
 * Establishment Fee=Purchase Amount / Requested Amount (ID 146)
 $540 < $20,000
 $820 > = $20,000
 */

@Component("PRDEF06")
@Scope("prototype")
public class PRDEF06 extends ProductRule {

	private static final int ESTABLISHMENT_FEE1 = 1;
	private static final int ESTABLISHMENT_FEE2 = 2;
	private static final int PURCHASE_AMOUNT = 3;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;

		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {
					if (null != product.getProductValidation()
							&& null != product.getProductValidation()
									.getResultantAmount()) {
						if (ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap,
								PURCHASE_AMOUNT, product.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(ESTABLISHMENT_FEE1)));

						} else if (ruleExecutionUtil
								.isGreaterThanBigDecimal(ruleConfigMap,
										PURCHASE_AMOUNT, product
												.getProductValidation()
												.getResultantAmount())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(ESTABLISHMENT_FEE2)));

						}
					}
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
