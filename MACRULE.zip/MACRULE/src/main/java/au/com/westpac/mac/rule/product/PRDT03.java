package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDT03")
@Scope("prototype")
public class PRDT03 extends ProductRule{

	private static final int TERM_DAYS_MAX = 1;
	
	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		int termInDays=0;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if (null != product.getProductValidation() && null != product.getProductValidation().getProposedLoanTermDays()) {

			termInDays = product.getProductValidation()
					.getProposedLoanTermDays();

			ruleResultIndicator = ruleExecutionUtil.isLessThanOrEqual(
					ruleConfigMap, TERM_DAYS_MAX, termInDays);
			product.getProductValidation().setProposedLoanTermDaysMax(
					Integer.valueOf(ruleConfigMap.get(TERM_DAYS_MAX)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);		
		
	}

}
