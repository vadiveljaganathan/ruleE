package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.AllocationGuarantors;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_5")
public class DecisionBR_5 extends Rule {

	/*Is the Guarantor Status (Old MAC ID 474) of the allocated guarantees = Category B and Has the customer asked for legal advice to be waived */
	private static final int GUARANTOR_STATUS= 1;

	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		List<AllocationGuarantors> applicableGuarantors  = getApplicableGuarantors(dealDetails);
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(dealDetails); 
		if(isRuleApplicable){
			ruleResultIndicator = true;
			for(AllocationGuarantors guarantor : applicableGuarantors){
				if(guarantor.getWaiveLegalAdvice()){
					ruleResultIndicator = false;
					break;
				}else{
					ruleResultIndicator = true;
				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}
	private boolean checkifRuleApplicable(DealDetails dealDetails){
		return !dealDetails.isRolloverDeal();
	}

	private List<AllocationGuarantors> getApplicableGuarantors(DealDetails dealDetails){
		List<AllocationGuarantors> applicableGuarantors = new ArrayList<AllocationGuarantors>();
		for(Product product : dealDetails.getProducts()){
			for(AssetAllocations assetAllocation : dealDetails.getAssetAllocations()){
				if(product.getId()==assetAllocation.getProductId()){
					for(AllocationGuarantors aGuarantor : dealDetails.getGuarantors()){
						if(assetAllocation.getAllocationId()==aGuarantor.getAllocationId()){
							if(ruleExecutionUtil.isContains(ruleConfigMap, GUARANTOR_STATUS, aGuarantor.getGuarantorStatusId())){
								applicableGuarantors.add(aGuarantor);
							}
						}
					}
				}
			}
		}
		
		return applicableGuarantors;
	}

	private boolean isLegalAdviceWaived(Boolean isLegalAdviceWaived){
		if(isLegalAdviceWaived){
			return true;
		}
		return false;
	}
}
