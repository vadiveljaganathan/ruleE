package au.com.westpac.mac.rule.domain;

import java.util.List;

public class RuleEngineResult {

	private List<RuleResult> ruleResultList;
	

}
