package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;
@Component("DecisionBR_34")
public class DecisionBR_34 extends Rule {

	private static final int CAL_LEVEL = 1;
	private static final int ACRP = 2;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;
		boolean isRuleApplicable = isRuleApplicable(dealDetails, ruleResults);
		if (isRuleApplicable) {					
			ruleResultIndicator = ruleExecutionUtil.isContains(ruleConfigMap,
					ACRP, dealDetails.getCustomerGroupRiskProfile().getOverallRiskRankingId());
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

	private boolean isRuleApplicable(DealDetails dealDetails,
			List<RuleResult> ruleResults) {
		return checkCALLevelOfLoggedInUser(dealDetails) && checkIfFinancialsAreComplete(dealDetails) && checkIfPreviousRulePassed(ruleResults);
	}

	// passed DecisionBR_17 to DecisionBR_32; DecisionBR_11 to
	// DecisionBR_15; and up to DecisionBR_7
	private boolean checkIfPreviousRulePassed(List<RuleResult> ruleResults) {
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15, RuleConstant.DECISIONBR_17,
						RuleConstant.DECISIONBR_18, RuleConstant.DECISIONBR_19,
						RuleConstant.DECISIONBR_20, RuleConstant.DECISIONBR_21,
						RuleConstant.DECISIONBR_22, RuleConstant.DECISIONBR_23,
						RuleConstant.DECISIONBR_24, RuleConstant.DECISIONBR_25,
						RuleConstant.DECISIONBR_26, RuleConstant.DECISIONBR_27,
						RuleConstant.DECISIONBR_28, RuleConstant.DECISIONBR_29,
						RuleConstant.DECISIONBR_30, RuleConstant.DECISIONBR_31,
						RuleConstant.DECISIONBR_32,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}
		return true;
	}
	//Check if financials are completed.
	// TODO - Design question - Do we need financial check in rule code?
	private boolean checkIfFinancialsAreComplete(DealDetails dealDetails) {
		if (null == dealDetails.getServiceability().getICR()
				|| null == dealDetails.getServiceability().getDSC()) {
			return false;
		}
		return true;
	}

	//check CAL Level of logged in user
	private boolean checkCALLevelOfLoggedInUser(DealDetails dealDetails) {
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel());
	}
}
