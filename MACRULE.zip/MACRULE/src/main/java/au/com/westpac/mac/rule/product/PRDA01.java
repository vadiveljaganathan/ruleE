package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDA01")
@Scope("prototype")
public class PRDA01 extends ProductRule {
	
	private static final int AMOUNT_MAX_LIMIT = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if (null != product.getProductValidation()) {
			ruleResultIndicator = ruleExecutionUtil.isLessThanOrEqual(
					ruleConfigMap, AMOUNT_MAX_LIMIT, product
							.getProductValidation().getTotalFinanceAmount());
			product.getProductValidation().setTotalFinanceAmountMax(
					Double.valueOf(ruleConfigMap.get(AMOUNT_MAX_LIMIT)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
