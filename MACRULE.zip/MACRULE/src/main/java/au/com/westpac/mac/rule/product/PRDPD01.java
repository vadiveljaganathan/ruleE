package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Fulfillment;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDPD01")
@Scope("prototype")
public class PRDPD01 extends ProductRule {
	
	private static final int PROGRESSIVE_DRAWDOWN = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		Fulfillment fullFulfillment = product.getFulfillment();
		if(null != fullFulfillment && null == fullFulfillment.getProgressiveDrawDownFeeAmount() ){
			ruleResultIndicator = ruleExecutionUtil.isGreaterThanOrEqualBigDecimal(ruleConfigMap, PROGRESSIVE_DRAWDOWN, fullFulfillment.getProgressiveDrawDownFeeAmount());
			fullFulfillment.setProgressiveDrawDownFeeAmountMin(Double.parseDouble(ruleConfigMap.get(PROGRESSIVE_DRAWDOWN)));
		}
		
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
