package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_24")
public class DecisionBR_24 extends Rule {
	private static final int PRODUCT_FAMILY_1 = 1;
	private static final int PRODUCT_FAMILY_2 = 2;
	private static final int PRODUCT_FAMILY_3 = 3;
	private static final int PRODUCT_FAMILY_4 = 4;
	private static final int PRODUCT_FAMILY_7 = 7;
	private static final int PRODUCT_FAMILY_6 = 6;
	private static final int PRODUCT_FAMILY_8 = 8;
	
	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails) arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = isRuleApplicable(ruleResults);
		if (isRuleApplicable) {
			ruleResultIndicator = checkForCALLimitsForProducts(dealDetails);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}
	/**
	 * Method to check CAL Limits For Product
	 * @param dealDetails
	 * @return
	 */

	private boolean checkForCALLimitsForProducts(DealDetails dealDetails) {
		
		BigDecimal resultantLimitChangeAmount1 = BigDecimal.ZERO;
		BigDecimal resultantLimitChangeAmount2= BigDecimal.ZERO;
		BigDecimal resultantLimitChangeAmount3 = BigDecimal.ZERO;
		
		
		for (Product product : dealDetails.getProducts()) {
			if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_1, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}else if (ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_2, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}else if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_3, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}else if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_4, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}else if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_7, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			} else if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_6, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}else if(ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY_8, product.getProductCategroy().getProductFamilyId())){
				resultantLimitChangeAmount1 =resultantLimitChangeAmount1.add(product.getLimitChangeAmount());
			}
			
		}
		
		return isLimitChangeAmountWithinCALLimit(resultantLimitChangeAmount1, dealDetails.getCustomerGroupLendingAuthority().getGeneralCALAvail()) && 
										isLimitChangeAmountWithinCALLimit(resultantLimitChangeAmount2,  dealDetails
												.getCustomerGroupLendingAuthority().getBusinessCC()) &&
												isLimitChangeAmountWithinCALLimit(resultantLimitChangeAmount3, dealDetails
														.getCustomerGroupLendingAuthority().getTemporarayOD());
								
	}
	
	
	
	private boolean isLimitChangeAmountWithinCALLimit(BigDecimal limitChangeAmount,
			BigDecimal calLimit) {
		if (limitChangeAmount.doubleValue() <= calLimit.doubleValue()) {
			return true;
		}
		return false;
	}


	private boolean isRuleApplicable(List<RuleResult> ruleResults) {
		// passed DecisionBR_17 to DecisionBR_20; DecisionBR_11 to
		// DecisionBR_15; and up to DecisionBR_7
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15, RuleConstant.DECISIONBR_17,
						RuleConstant.DECISIONBR_18, RuleConstant.DECISIONBR_19,
						RuleConstant.DECISIONBR_20,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}

		return true;
	}
}
