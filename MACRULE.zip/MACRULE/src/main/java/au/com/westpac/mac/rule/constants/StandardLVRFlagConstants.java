package au.com.westpac.mac.rule.constants;

public class StandardLVRFlagConstants {

public static final String STANDARD_LVR_YES = "1";	
public static final String STANDARD_LVR_NO = "0";


  private StandardLVRFlagConstants() {
	  
  }
}
