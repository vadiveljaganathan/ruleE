package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDBRT01")
@Scope("prototype")
public class PRDBRT01 extends ProductRule {
	
	private static final int BASE_RATE_TYPE = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(null != product.getProductInterestRate() && null == product.getProductInterestRate().getLolaBaseRateTypeId()){
		product.getProductInterestRate().setLolaBaseRateTypeId(Integer.valueOf(ruleConfigMap.get(BASE_RATE_TYPE)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
