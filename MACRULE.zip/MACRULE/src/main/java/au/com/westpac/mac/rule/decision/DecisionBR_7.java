package au.com.westpac.mac.rule.decision;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_7")
public class DecisionBR_7 extends Rule {

	/*Any of the allocated assets have an Asset Family (ID 7) = Real Estate*/

	private static final int ASSET_FAMILY = 1;
	private static final int VALUATION_AMOUNT = 2;
	private static final int ASSET_TYPE = 3;
	private static final int VALUATION_PERIOD_YEARS = 4;
	private static final int LLVR = 5;

	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {

		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		
		boolean condition1 = false;
		boolean condition2 = false;
		boolean condition3 = false;
		
		List<Asset> applicableAssetsList = getAssetWithinGivenFamilyWithConfiguredValuation(dealDetails);
		if(!applicableAssetsList.isEmpty()){			
			condition1 = checkValuationPeriodAndllvr(applicableAssetsList,dealDetails);		
		}
		
		if(!condition1){
			applicableAssetsList = getAssetWithinGivenTypes(dealDetails);
			if(!applicableAssetsList.isEmpty()){			
				condition2 = checkValuationPeriodAndllvr(applicableAssetsList,dealDetails);				
			}
		}
		
		condition3 = isValuationOfAssetsChangedInDeal(dealDetails);
		
		boolean isRuleApplicable = checkifRuleApplicable(dealDetails)&& (condition1 || condition2 || condition3);
		
		if(isRuleApplicable){
			ruleResultIndicator = allRuleConditionPassed(dealDetails, applicableAssetsList);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}
	private boolean allRuleConditionPassed(DealDetails dealDetails,
			List<Asset> applicableAssetsList) {
		for(Asset asset : applicableAssetsList){
			/*
			 * Need to check whether Security conditions met
			}*/
		}
		return dealDetails.getDeal().isPropertyValuationWithinPolicy();
	}
	private List<Asset> getAssetWithinGivenFamilyWithConfiguredValuation(DealDetails dealDetails) {
		List<Asset> applicableAssets = new ArrayList<Asset>();
		for(Asset asset : dealDetails.getAsset()){
			if(null != asset.getAssetValuation()){
				if(ruleExecutionUtil.isContains(ruleConfigMap, ASSET_FAMILY, asset.getAssetCategory().getAssetFamilyId()) &&
						ruleExecutionUtil.isGreaterThanBigDecimal(ruleConfigMap, VALUATION_AMOUNT, asset.getAssetValuation().getAssetValue())){
					applicableAssets.add(asset);				
				}
			}
		}
		return applicableAssets;
	}
	
	private List<Asset> getAssetWithinGivenTypes(DealDetails dealDetails) {
		List<Asset> applicableAssets = new ArrayList<Asset>();
		for(Asset asset : dealDetails.getAsset()){			
			if(ruleExecutionUtil.isContains(ruleConfigMap, ASSET_TYPE, asset.getAssetCategory().getAssetTypeId())){				
					applicableAssets.add(asset);			
			}
		}
		return applicableAssets;
	}
	
	private boolean checkValuationPeriodAndllvr(List<Asset> applicableAssetsList,DealDetails dealDetails){
		applicableAssetsList = getAssetsWithMoreThanConfiguredValuationPeriod(applicableAssetsList);
		if(!applicableAssetsList.isEmpty()){
			return isLlvrIsMoreThanConfigureValue(applicableAssetsList,dealDetails);
		}
		return false;
	}
	
	private List<Asset> getAssetsWithMoreThanConfiguredValuationPeriod(List<Asset> assets){
		List<Asset> applicableAssets = new ArrayList<Asset>();
		for(Asset asset : assets){
			
			int noOfYrs = Integer.valueOf(ruleConfigMap.get(VALUATION_PERIOD_YEARS));
			Date now = new Date();
			Date expDate = DateUtils.addYears(now, -noOfYrs);
			if (null != asset.getAssetValuation().getValuationDate() && asset.getAssetValuation().getValuationDate().before(expDate)){
				applicableAssets.add(asset);
			}
		}
		return applicableAssets;
	}
	
	private boolean isLlvrIsMoreThanConfigureValue(List<Asset> assets,DealDetails dealDetails){
		boolean llvrFacilityOfAsset = false; 
		
		Map<Long,BigDecimal> facilityAllocation = new HashMap<Long,BigDecimal>();
		Map<Long,BigDecimal> facilityConsumption = new HashMap<Long,BigDecimal>();
		
		for(Asset asset : assets){
			for(AssetAllocations assetAlloc : dealDetails.getAssetAllocations()){
				if(asset.getAssetId()==assetAlloc.getAssetId()){
					long productId = assetAlloc.getProductId();
					
					for(Product prod : dealDetails.getAllProducts()){
						if(prod.getId()==productId){
							facilityConsumption.put(productId,prod.isModifiedInDeal()?prod.getProposedLimit():prod.getCurrentLimit());
							for(AssetAllocations prodAlloc : dealDetails.getAssetAllocations()){
								if(prodAlloc.getProductId()==productId){
									BigDecimal allocation = prodAlloc.getAllocationAmount();
									allocation = null==allocation?BigDecimal.ZERO:allocation;
									if(facilityAllocation.containsKey(productId)){				
										BigDecimal totalAllocation = facilityAllocation.get(productId);
										BigDecimal amount = totalAllocation.add(allocation);
										facilityAllocation.put(productId, amount);
									}else{
										facilityAllocation.put(productId, allocation);
									}
								}
							}
						}					
						
					}					
				}
			}
		}
		
		for(Map.Entry<Long, BigDecimal> entry : facilityConsumption.entrySet()){
			Long productId = entry.getKey();
			BigDecimal limit = entry.getValue();
			BigDecimal allocation = facilityAllocation.get(productId);
			if(null!=limit && null!=allocation && allocation.intValue()>0){
				BigDecimal llvr = limit.divide(allocation,2, RoundingMode.HALF_EVEN).multiply(new BigDecimal(100));
				llvrFacilityOfAsset = ruleExecutionUtil.isGreaterThanBigDecimal(ruleConfigMap,LLVR,llvr);
				if(!llvrFacilityOfAsset){
					break;
				}
			}
		}
		return llvrFacilityOfAsset;
	}
	
	private boolean isValuationOfAssetsChangedInDeal(DealDetails dealDetails){
		boolean valuationModified = false;
		List<Asset> assets = dealDetails.getAsset();
		for(Asset asset: assets){
			if(asset.isModifiedInDeal()){
				return true;
			}
		}
		return valuationModified;
	}
	
	private boolean checkifRuleApplicable(DealDetails dealDetails){		
		return !dealDetails.isRolloverDeal();		
	}
}
