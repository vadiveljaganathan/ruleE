package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDIRT01")
@Scope("prototype")
public class PRDIRT01 extends ProductRule {
	
	private static final int INTEREST_RATE_TYPE = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(null != product.getProductValidation() && null ==  product.getProductValidation().getCurrentInterestRateTypeId() ){
			ruleResultIndicator = ruleExecutionUtil.isEqual(ruleConfigMap, INTEREST_RATE_TYPE, product.getProductValidation().getCurrentInterestRateTypeId());
			product.getProductValidation().setCurrentInterestRateTypeId(Integer.parseInt(ruleConfigMap.get(INTEREST_RATE_TYPE)));
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
