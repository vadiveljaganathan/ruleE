package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

/**
 * Total Finance Amount (ID 159) < 100,000 = $820 Total Finance Amount (ID 159)
 * > 100,000 = $820 + 0.6% of any amount above $100,000
 * 
 * @author L048037
 * 
 */

@Component("PRDEF02")
@Scope("prototype")
public class PRDEF02 extends ProductRule {

	private static final int ESTABLISHMENT_FEE1 = 1;// 820
	private static final int ESTABLISHMENT_FEE2 = 2;// 820+ 0.6Amount
	private static final int PURCHASE_AMOUNT1 = 3;// <=100000
	private static final int PURCHASE_AMOUNT2 = 4;// >100000
	private static final int PERCENTAGE = 5;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {
					if (null != product.getProductValidation()
							&& null != product.getProductValidation()
									.getResultantAmount()) {

						if (ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap,
								PURCHASE_AMOUNT1, product
										.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(ESTABLISHMENT_FEE1)));

						} else if (ruleExecutionUtil.isGreaterThan(
								ruleConfigMap, PURCHASE_AMOUNT2, product
										.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							double estFee = 0;
							double estFeeConfig = ruleExecutionUtil
									.getDoubleValue(ruleConfigMap,
											ESTABLISHMENT_FEE2);
							double estFeePercent = ruleExecutionUtil
									.getDoubleValue(ruleConfigMap, PERCENTAGE);
							double amoutAbovePurchaseAmount = product
									.getProductValidation()
									.getResultantAmount().doubleValue()
									- Double.parseDouble((ruleConfigMap
											.get(PURCHASE_AMOUNT2)));
							estFee = ruleExecutionUtil.calcAmountOnPercent(
									amoutAbovePurchaseAmount, estFeePercent);
							estFee = estFeeConfig + estFee;
							productFee.setFeeAmount(estFee);
						}
					}
				}
			}
		}

		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
