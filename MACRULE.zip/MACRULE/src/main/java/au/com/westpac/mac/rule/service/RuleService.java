package au.com.westpac.mac.rule.service;

import java.util.List;

import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.entity.RuleEngineDataEntity;
import au.com.westpac.mac.rule.entity.RuleEntity;

public interface RuleService {
	
	public String getIdOfFirstRuleGroupForCheckList(String checkListId);
	
	public RuleEngineDataEntity loadCheckListGroupsAndRuleData();

	public void saveRuleResultsForDeal(long dealId, long userId,
			List<RuleResult> ruleResultList);
	
	/**
	 * This method get the RuleResult for a deal
	 * @param dealId
	 * @return
	 */
	public List<RuleResult> getRuleResultsForDeal(long dealId);
	
	public List<RuleEntity> getDecisionRules(String rulePattern);

	public void saveDecisionRuleDetails(String xmlData);

	public void updateRuleConfigDetails(RuleEntity ruleEntity);
	
}
