package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_20")
public class DecisionBR_20 extends Rule {
	private static final int CAL_LEVEL = 1;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(dealDetails);

		if (isRuleApplicable) {
			ruleResultIndicator = dealDetails.getDeal().isCustomerTradedProfitablyForMinYears();
		}else{
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

	/**
	 * Method to check Entry Criteria for Rule DecisionBR_20
	 * 
	 * @param dealDetails
	 * @return
	 */

	private boolean isRuleApplicable(DealDetails dealDetails) {
		// The logged in user have a CAL Level that is 3,4,5
		return ruleExecutionUtil.isContains(ruleConfigMap, CAL_LEVEL,
				dealDetails.getLoggedInUser().getCalLevel());
	}
}
