package au.com.westpac.mac.rule.securitylvrrule;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.constants.LVRRuleConstants;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("LVR009")
public class LVR009 extends Rule {
	

	public void makeDecision(Object arg, List<RuleResult> ruleResults)
	{
		LVRDetails lvrDetails = (LVRDetails) arg;
		boolean isRuleApplicable = false;
		
		if (ruleExecutionUtil.isContains(ruleConfigMap, LVRRuleConstants.COLLATERAL_TYPE,lvrDetails.getAssetType())) {
			isRuleApplicable = true;
		}

		if (isRuleApplicable) {
			if (ruleExecutionUtil.isContains(ruleConfigMap, LVRRuleConstants.LVR_RESTRICTIONS_TLSAS106,
					lvrDetails.getLvrRestriction())
					|| ruleExecutionUtil.compareBoolean(ruleConfigMap,
							LVRRuleConstants.OWNER_BUILDER_TLAS117,
							lvrDetails.getIsOwnerBuilder())) {
				/* Setting Standard LVR flag and System LVR value if rule conditions matched */
				lvrDetails.setStandardLVRFlag(ruleExecutionUtil.getStandardLVRFlag(ruleConfigMap, LVRRuleConstants.STANDARD_LVR_FLAG));
				lvrDetails.setSystemLVR(ruleExecutionUtil.getSystemLVR(ruleConfigMap, LVRRuleConstants.SYSTEM_LVR));
			}else{
				isRuleApplicable = false;
			}		
		}

		/* Add Rule Result to list of list of rule result */
		ruleExecutionUtil.addLVRRuleResult(this, ruleResults, isRuleApplicable,lvrDetails);
	}
}
