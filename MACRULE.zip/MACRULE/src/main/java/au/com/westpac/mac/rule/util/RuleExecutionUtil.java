package au.com.westpac.mac.rule.util;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.domain.business.product.EquipmentFinance;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.constants.StandardLVRFlagConstants;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

public class RuleExecutionUtil {

	/**************************** Arithmetic Operations START *****************************************************/
	public boolean isInRange(Map<Integer, String> ruleConfigMap, int index1,
			int index2, int value) {
		try {

			if (null == ruleConfigMap.get(index1)
					|| null == ruleConfigMap.get(index2)) {
				return false;
			}
			int value1 = Integer.valueOf(ruleConfigMap.get(index1)).intValue();
			int value2 = Integer.valueOf(ruleConfigMap.get(index2)).intValue();

			if (value >= value1 && value <= value2) {
				return true;
			}
		} catch (NumberFormatException e) {
			return false;
		}
		return false;
	}

	public boolean isGreaterThanOrEqualForLong(
			Map<Integer, String> ruleConfigMap, int index, Object arg) {
		try {
			if (null == arg || null == ruleConfigMap.get(index)) {
				return false;
			} 
			Long value = (Long) arg;

			Integer value1 = Integer.valueOf(ruleConfigMap.get(index));
			return value.intValue() >= value1.intValue();

		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isLessThanOrEqualForLong(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		try {
			if (null == arg || null == ruleConfigMap.get(index)) {
				return false;
			} 
			Long value = (Long) arg;

			Integer value1 = Integer.valueOf(ruleConfigMap.get(index));
			return value.intValue() <= value1.intValue();			
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isGreaterThan(Map<Integer, String> ruleConfigMap, int index,
			Object arg) {
		try {
			double value1 = getDoubleValue(ruleConfigMap, index);
			if (null == arg) {
				return false;
			}
			double value2 = ((Double) arg).doubleValue();
			if (value1 > value2) {
				return true;
			}
			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isGreaterThan(double value1, double value2) {
		if (value1 > value2) {
			return true;
		}
		return false;
	}

	public boolean isGreaterThan(BigDecimal value1, BigDecimal value2) {
		if (null == value1 || null == value2) {
			return false;
		}
		return value1.doubleValue() > value2.doubleValue();

	}

	public boolean isGreaterThan(BigDecimal value1, Double value2) {
		if (null == value1 || null == value2) {
			return false;
		}
		return value1.doubleValue() > value2.doubleValue();
	}

	public boolean isLessThanOrEqual(BigDecimal value1, Double value2) {
		if (null == value1 || null == value2) {
			return false;
		}
		return value1.doubleValue() <= value2.doubleValue();
	}

	public boolean isGreaterThan(Map<Integer, String> ruleConfigMap, int index,
			double value2) {
		try {
			if (null == ruleConfigMap.get(index)) {
				return false;
			}
			double value1 = Double.valueOf(ruleConfigMap.get(index))
					.doubleValue();

			if (value2 >= value1) {
				return true;
			}
			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isGreaterThanBigDecimal(Map<Integer, String> ruleConfigMap,
			int index, BigDecimal value) {
		try {
			if (null == ruleConfigMap.get(index) || null == value) {
				return false;
			}

			double value1 = Double.valueOf(ruleConfigMap.get(index))
					.doubleValue();
			double value2 = value.doubleValue();

			if (value2 > value1) {
				return true;
			}
			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isLessThanBigDecimal(Map<Integer, String> ruleConfigMap,
			int index, BigDecimal value) {
		try {
			if (null == ruleConfigMap.get(index) || null == value) {
				return false;
			}

			double value1 = Double.valueOf(ruleConfigMap.get(index))
					.doubleValue();
			double value2 = value.doubleValue();

			if (value2 < value1) {
				return true;
			}
			return false;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public boolean isGreaterThanOrEqualBigDecimal(
			Map<Integer, String> ruleConfigMap, int index, BigDecimal value) {
		if (null == value || null == ruleConfigMap.get(index)) {
			return false;
		}

		double value1 = Double.valueOf(ruleConfigMap.get(index)).doubleValue();

		double value2 = value.doubleValue();
		if (value2 >= value1) {
			return true;
		}
		return false;
	}

	public boolean isLessThanOrEqualBigDecimal(
			Map<Integer, String> ruleConfigMap, int index, BigDecimal value) {
		if (null == ruleConfigMap.get(index) || null == value) {
			return false;
		}
		double value1 = Double.valueOf(ruleConfigMap.get(index)).doubleValue();

		double value2 = value.doubleValue();
		if (value2 <= value1) {
			return true;
		}
		return false;
	}

	public boolean isInRangeBigDecimal(Map<Integer, String> ruleConfigMap,
			int index1, int index2, BigDecimal value) {
		if (null == value || null == ruleConfigMap.get(index1)
				|| null == ruleConfigMap.get(index2)) {
			return false;
		}

		double value1 = Double.valueOf(ruleConfigMap.get(index1)).doubleValue();
		double value2 = Double.valueOf(ruleConfigMap.get(index2)).doubleValue();

		double dblvalue = value.doubleValue();
		if ((value2 >= dblvalue) && (dblvalue >= value1)) {
			return true;
		}
		return false;
	}

	public boolean isGreaterThan(Map<Integer, String> ruleConfigMap, int index,
			int value2) {
		if (null == ruleConfigMap.get(index)) {
			return false;
		}
		Integer value = Integer.valueOf(ruleConfigMap.get(index));
		int value1 = value.intValue();

		if (value2 > value1) {
			return true;
		}
		return false;
	}

	public boolean isLessThanOrEqual(Map<Integer, String> ruleConfigMap,
			int index, int value2) {
		if (null == ruleConfigMap.get(index)) {
			return false;
		}
		int value1 = Integer.valueOf(ruleConfigMap.get(index)).intValue();

		if (value2 <= value1) {
			return true;
		}
		return false;
	}

	public boolean isLessThan(Map<Integer, String> ruleConfigMap, int index,
			Double value2) {

		if (null == ruleConfigMap.get(index) || null == value2) {
			return false;
		}
		double value1 = Double.valueOf(ruleConfigMap.get(index)).doubleValue();

		if (value2 < value1) {
			return true;
		}

		return false;
	}

	public boolean isLessThan(Map<Integer, String> ruleConfigMap, int index,
			Object arg) {
		if (null == ruleConfigMap.get(index) || null == arg) {
			return false;
		}

		double value1 = getDoubleValue(ruleConfigMap, index);
		double value2 = 0;
		if (arg instanceof Integer) {
			value2 = (Double.valueOf(arg.toString()));
		} else {
			value2 = ((Double) arg).doubleValue();
		}
		if (value1 < value2) {
			return true;
		}
		return false;
	}

	public boolean isLessThanLVR(Map<Integer, String> ruleConfigMap, int index,
			Object arg) {
		if (null == ruleConfigMap.get(index) || null == arg) {
			return false;
		}

		double value1 = getDoubleValue(ruleConfigMap, index);
		double value2 = 0;
		if (arg instanceof Integer) {
			value2 = (Double.valueOf(arg.toString()));
		} else {
			value2 = ((Double) arg).doubleValue();
		}
		if (value2 < value1) {
			return true;
		}
		return false;
	}

	public boolean isLessThan(double value1, double value2) {
		if (value1 < value2) {
			return true;
		}
		return false;
	}

	public boolean isLessThanOrEqual(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		if (null == ruleConfigMap.get(index) || null == arg) {
			return false;
		}
		double value1 = getDoubleValue(ruleConfigMap, index);
		double value2 = 0;		
		value2 = Double.valueOf(arg.toString()).doubleValue();
		
		if (value2 <= value1) {
			return true;
		}
		return false;
	}

	public boolean isLessThanOrEqual(double value1, double value2) {
		if (value1 <= value2) {
			return true;
		}
		return false;
	}

	public boolean isGreaterThanOrEqual(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		if (null == ruleConfigMap.get(index) || null == arg) {
			return false;
		}
		double value1 = getDoubleValue(ruleConfigMap, index);
		double value2 = 0;

		if (arg instanceof Integer) {
			value2 = (Double.valueOf(arg.toString()));
		} else if (arg instanceof Long) {
			value2 = (Double.valueOf(arg.toString()));
		} else {
			value2 = ((Double) arg).doubleValue();
		}
		if (value2 >= value1) {
			return true;
		}
		return false;
	}

	public int calculateDaysBetweenTwoDates(Date d1, Date d2) {
		if (d1 == null || d2 == null) {
			return 0;
		}
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));

	}
	
	public int calculateMonthsBetweenTwoDates(Date d1, Date d2) {
		if (d1 == null || d2 == null) {
			return 0;
		}
		
		Calendar startCalendar = new GregorianCalendar();
        startCalendar.setTime(d1);
        Calendar endCalendar = new GregorianCalendar();
        endCalendar.setTime(d2);

        int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		return diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
	}

	public Integer getIntValue(Map<Integer, String> ruleConfigMap, int index) {
		if (ruleConfigMap.get(index) == null) {
			return 0;
		}
		return Integer.valueOf(ruleConfigMap.get(index).toString());
	}

	public String getStrings(Map<Integer, String> ruleConfigMap, int index) {
		if (ruleConfigMap.get(index) == null) {
			return null;
		}
		return ruleConfigMap.get(index).toString();
	}

	public Long getLongValue(Map<Integer, String> ruleConfigMap, int index) {
		if (ruleConfigMap.get(index) == null) {
			return (long) 0;
		}
		return Long.valueOf(ruleConfigMap.get(index).toString());
	}

	public Double getDoubleValue(Map<Integer, String> ruleConfigMap, int index) {
		if (ruleConfigMap.get(index) == null) {
			return (double) 0;
		}
		return Double.valueOf(ruleConfigMap.get(index).toString());
	}

	public BigDecimal getBigDecimalValue(Map<Integer, String> ruleConfigMap,
			int index) {
		if (ruleConfigMap.get(index) == null) {
			return BigDecimal.ZERO;
		}
		return new BigDecimal(ruleConfigMap.get(index).toString());
	}

	public double calcAmountOnPercent(double amount, double percentage) {
		return amount * percentage / 100;
	}
	public double getMaxOfTwoNumbers(double x, double y) {
		if(x>=y){
			return x;
		}
		return y;
		
	}
	public boolean isGreaterThanOrEqual(double value1, double value2) {
		if (value1 >= value2) {
			return true;
		}
		return false;
	}

	public boolean isGreartThan(Map<Integer, String> ruleConfigMap, int index,
			double value) {
		if (null == ruleConfigMap.get(index)) {
			return false;
		}
		double value1 = Double.valueOf(ruleConfigMap.get(index)).doubleValue();

		if (value > value1) {
			return true;
		}
		return false;
	}

	public boolean isGreaterThanLong(Map<Integer, String> ruleConfigMap,
			int index, Long value) {
		try {
			if (null == ruleConfigMap.get(index) || null == value) {
				return false;
			}
			double value1 = Long.valueOf(ruleConfigMap.get(index)).longValue();

			if (value > value1) {
				return true;
			}
		} catch (NumberFormatException e) {
			return false;
		}
		return false;
	}

	public boolean isGreartThanOrEqual(Map<Integer, String> ruleConfigMap,
			int index, double value) {
		if (null == ruleConfigMap.get(index)) {
			return false;
		}
		double value1 = Double.valueOf(ruleConfigMap.get(index)).doubleValue();

		if (value >= value1) {
			return true;
		}
		return false;
	}

	/**************************** Arithmetic Operations END *****************************************************/

	/***************************** String Operations START *************************************************************************/

	public boolean isContains(Map<Integer, String> ruleConfigMap, int index,
			Object arg) {
		if (null == arg || null == ruleConfigMap.get(index)) {
			return false;
		}
		String temp = "," + arg.toString() + ",";
		String value = "," + ruleConfigMap.get(index) + ",";
		return value.contains(temp);
	}

	public boolean compareStrings(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		if (null == arg || null == ruleConfigMap.get(index)) {
			return false;
		}
		String strVal = ruleConfigMap.get(index);
		return strVal.equals(arg);
	}

	public boolean compareBoolean(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		if (null == arg || null == ruleConfigMap.get(index)) {
			return false;
		}
		String strValue = ruleConfigMap.get(index);
		Boolean booleanValue = false;
		if ("TRUE".equalsIgnoreCase(strValue)) {
			booleanValue = true;
		}
		Boolean boolean1 = (Boolean) arg;
		if (booleanValue.booleanValue() == boolean1.booleanValue()) {
			return true;
		} 
		return false;

	}

	/***************************** String Operations END *************************************************************************/

	/***************************** Rule Utilities *************************************************************************/

	public void addRuleResult(Rule rule, List<RuleResult> ruleResults,
			boolean isRuleApplicable, boolean ruleResultIndicator) {

		RuleResult ruleResult = new RuleResult(rule.getRuleId(),
				isRuleApplicable, ruleResultIndicator);
		ruleResults.add(ruleResult);

	}

	public void addChecklistCriteriaRuleResult(Rule rule,
			List<RuleResult> ruleResults, boolean isRuleApplicable,
			boolean ruleResultIndicator) {

		RuleResult ruleResult = new RuleResult(rule.getRuleId(),
				isRuleApplicable, ruleResultIndicator);
		ruleResults.add(ruleResult);

	}

	public void addProductRuleResult(Rule rule, List<RuleResult> ruleResults) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(rule.getRuleId());
		ruleResults.add(ruleResult);
	}

	public void addLVRRuleResult(Rule rule, List<RuleResult> ruleResults,
			boolean isRuleApplicable, LVRDetails lvrDetails) {

		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(rule.getRuleId());
		ruleResult.setRulePassed(isRuleApplicable);
		ruleResult.setRuleApplicable(isRuleApplicable);
		if (isRuleApplicable) {
			ruleResult.setSystemLVR(lvrDetails.getSystemLVR());
			ruleResult.setStandardLVRFlag(lvrDetails.isStandardLVRFlag());
		}
		ruleResults.add(ruleResult);
	}

	public boolean getStandardLVRFlag(Map<Integer, String> ruleConfigMap,
			int index) {
		if (null != ruleConfigMap.get(index)) {
			String standardLVRFlag = (String) ruleConfigMap.get(index);
			if (standardLVRFlag
					.equalsIgnoreCase(StandardLVRFlagConstants.STANDARD_LVR_YES)) {
				return true;
			} 
		}
		return false;
	}

	public int getSystemLVR(Map<Integer, String> ruleConfigMap, int index) {
		if (null != ruleConfigMap.get(index)) {
			String systemLVR = (String) ruleConfigMap.get(index);
			return Integer.valueOf(systemLVR);

		}

		return 0;
	}

	/***************************** Rule Utilities END *************************************************************************/

	/************************************************* Helper Method START ******************************/

	public boolean listIsNull(List<?> objList) {
		if (null == objList) {
			return true;
		}			
		return false;
	}

	public boolean checkIfProductWithGivenFamilyIdIsPresentInList(
			List<Product> productList, Map<Integer, String> ruleConfigMap,
			int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductFamilyId())) {
				return true;
			}
		}
		return false;

	}

	public boolean checkIfProductWithGivenTypeIsPresentInList(
			List<Product> productList, Map<Integer, String> ruleConfigMap,
			int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductTypeId())) {
				return true;
			}
		}
		return false;

	}

	public boolean checkIfProductWithGivenSubTypeIsPresentInList(
			List<Product> productList, Map<Integer, String> ruleConfigMap,
			int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductTypeId())) {
				return true;
			}
		}
		return false;

	}

	public boolean checkForProductType(List<Product> productList,
			Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (!isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductTypeId())) {
				return false;
			}
		}
		return true;
	}

	public boolean checkForProductTypeForEquipmentFinance(
			List<EquipmentFinance> productList,
			Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (!isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductTypeId())) {
				return false;
			}
		}
		return true;
	}

	public boolean checkForProductFamilyandProductType(
			Product bProduct, Map<Integer, String> ruleConfigMap,
			int productFamilyIndex, int productTypeIndex) {
		if (bProduct == null) {
			return false;
		} else if (isContains(ruleConfigMap, productFamilyIndex, bProduct
				.getProductCategroy().getProductFamilyId()) &&
				!isContains(ruleConfigMap, productTypeIndex, bProduct
						.getProductCategroy().getProductTypeId())) {
			return true;			
		}
		return false;
	}
	public boolean checkForProductFamily(List<Product> productList,
			Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (!isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductFamilyId())) {
				return false;
			}
		}
		return true;
	}

	public boolean checkForBusinessProductTypeWithGivenId(
			List<Product> productList,
			Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(productList)) {
			return false;
		}
		for (Product product : productList) {
			if (isContains(ruleConfigMap, index, product.getProductCategroy()
					.getProductTypeId())) {
				return true;
			}
		}
		return false;
	}

	public boolean checkValueOfAssetType(List<Asset> assetsList,
			Map<Integer, String> ruleSpecificConfigMap, int index) {
		if (listIsNull(assetsList)) {
			return false;
		}
		for (Asset asset : assetsList) {
			if (!isContains(ruleSpecificConfigMap, index, asset
					.getAssetCategory().getAssetTypeId())) {
				return false;
			}
		}
		return true;
	}

	public boolean checkIfAssetWithGivenTypeIsPresentInList(
			List<Asset> assetList, Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(assetList)) {
			return false;
		}
		for (Asset asset : assetList) {
			if (isContains(ruleConfigMap, index, asset.getAssetCategory()
					.getAssetTypeId())) {
				return true;
			}
		}
		return false;

	}

	public boolean checkIfAssetWithGivenFamilyIsPresentInList(
			List<Asset> assetList, Map<Integer, String> ruleConfigMap, int index) {
		if (listIsNull(assetList)) {
			return false;
		}
		for (Asset asset : assetList) {
			if (isContains(ruleConfigMap, index, asset.getAssetCategory()
					.getAssetFamilyId())) {
				return true;
			}
		}
		return false;

	}

	/************************************************* Helper Method END ******************************/

	public static boolean isGivenRiskGradeisGreaterThanOrEqual(
			String givenRiskGrade, String configuredValue) {
		if ((int) givenRiskGrade.charAt(0) <= (int) configuredValue.charAt(0)
				&& Integer.valueOf(
						givenRiskGrade.substring(1, givenRiskGrade.length()))
						.intValue() >= Integer.valueOf(
								configuredValue.substring(1, configuredValue.length()))
								.intValue()) {
			return true;			
		}
		return false;
	}
	public boolean isEqual(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		if(null == ruleConfigMap || null ==arg || null == ruleConfigMap.get(index)){
			return false;
		}
		return (ruleConfigMap.get(index).equals(arg.toString()));
	}

	public boolean isGreaterThanOrEqual(Map<Integer, String> ruleConfigMap, int index,
			int value2) {
		if (null == ruleConfigMap.get(index)) {
			return false;
		}
		Integer value = Integer.valueOf(ruleConfigMap.get(index));
		int value1 = value.intValue();

		if (value2 >= value1) {
			return true;
		}
		return false;
	}

	public boolean checkIfAllProductIsOfGivenTypeInList(List<Product> productList, Map<Integer, String> ruleConfigMap,
			int index){
		boolean areProductsPresent = false;
		for(Product product : productList){
			areProductsPresent = true;
			if (!isContains(ruleConfigMap, index, product)) {
				areProductsPresent = false;
				break;
			}
		}
		return areProductsPresent;
	}
	public boolean checkifLLVRFacilityisInWithinRangeForProduct(Double llvr,
			Map<Integer, String> ruleConfigMap, int index1, int index2){
		double value1 = getDoubleValue(ruleConfigMap, index1);
		double value2 = getDoubleValue(ruleConfigMap, index2);
		if(llvr==null){
			return false;
		}
		if(value1 < llvr && llvr < value2){
			return true;
		}else{
			return false;
		}
	}
	public boolean checkifResultantLimitIsWithinLimit(BigDecimal resultant,
			Map<Integer, String> ruleConfigMap, int index){
		BigDecimal valu1 =getBigDecimalValue(ruleConfigMap, index);
		return resultant.compareTo(valu1) <= 0;
	}
	
	public boolean isTermLessThanOrEqualForLong(Map<Integer, String> ruleConfigMap,
			int index, Object arg) {
		try {
			if (null == arg || null == ruleConfigMap.get(index)) {
				return false;
			} 
			Long value = (Long) arg;

			Integer value1 = Integer.valueOf(ruleConfigMap.get(index)) * 12;
			return value.intValue() <= value1.intValue();			
		} catch (NumberFormatException e) {
			return false;
		}
	}
	
	public boolean isTermInRangeYears(Map<Integer, String> ruleConfigMap, int index1,
			int index2, long value) {
		try {

			if (null == ruleConfigMap.get(index1)
					|| null == ruleConfigMap.get(index2)) {
				return false;
			}
			int value1 = Integer.valueOf(ruleConfigMap.get(index1)).intValue() * 12;
			int value2 = Integer.valueOf(ruleConfigMap.get(index2)).intValue() * 12;

			if (value >= value1 && value <= value2) {
				return true;
			}
		} catch (NumberFormatException e) {
			return false;
		}
		return false;
	}
	
	public boolean isTermInRangeMonth(Map<Integer, String> ruleConfigMap, int index1,
			int index2, long value) {
		try {

			if (null == ruleConfigMap.get(index1)
					|| null == ruleConfigMap.get(index2)) {
				return false;
			}
			int value1 = Integer.valueOf(ruleConfigMap.get(index1)).intValue();
			int value2 = Integer.valueOf(ruleConfigMap.get(index2)).intValue() * 12;

			if (value >= value1 && value <= value2) {
				return true;
			}
		} catch (NumberFormatException e) {
			return false;
		}
		return false;
	}
}
