package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_6")
public class DecisionBR_6 extends Rule{

	/*Validate if Requested term is within the Product maximum*/
	private static final int LOAN_TERM1 = 1;
	private static final int PRODUCT_TYPE1 = 2;
	private static final int LOAN_TERM2 = 3;
	private static final int PRODUCT_TYPE2 = 4;
	private static final int LOAN_TERM3 = 5;
	private static final int PRODUCT_TYPE3 = 6;
	
	private static final int PRODUCT_TYPE4 = 7;
	private static final int LOAN_TERM_MIN4 = 8;
	private static final int LOAN_TERM_MAX4 = 9;
	
	private static final int PRODUCT_TYPE5 = 10;
	private static final int LOAN_TERM_MIN5 = 11;
	private static final int LOAN_TERM_MAX5 = 12;
	
	private static final int PRODUCT_TYPE6 = 13;
	private static final int LOAN_TERM_MIN6 = 14;
	private static final int LOAN_TERM_MAX6 = 15;
	
	private static final int PRODUCT_TYPE7 = 16;
	private static final int LOAN_TERM_MIN7 = 17;
	private static final int LOAN_TERM_MAX7 = 18;
	

	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		List<Product> productList1 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE1);
		List<Product> productList2 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE2);
		List<Product> productList3 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE3);
		List<Product> productList4 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE4);
		List<Product> productList5 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE5);
		List<Product> productList6 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE6);
		List<Product> productList7 =  getProductsWithGivenTypes(dealDetails.getProducts(), PRODUCT_TYPE7);
		
		boolean isRuleApplicable = !productList1.isEmpty() || !productList2.isEmpty() || !productList3.isEmpty() || !productList4.isEmpty() || !productList5.isEmpty() || !productList6.isEmpty() || !productList7.isEmpty();
		if(isRuleApplicable){
			boolean condition1  = true;
			boolean condition2  = true;			
			boolean condition3  = true;
			boolean condition4  = true;
			boolean condition5  = true;
			boolean condition6  = true;
			boolean condition7  = true;
			if(!productList1.isEmpty()){
				condition1  = checkIfValidTerm(productList1, LOAN_TERM1);
			}
			if(!productList2.isEmpty()){
				condition2  = checkIfValidTerm(productList2, LOAN_TERM2);
			}
			if(!productList3.isEmpty()){
				condition3  = checkIfValidTerm(productList3, LOAN_TERM3);
			}
			if(!productList4.isEmpty()){
				condition4  = checkIfTermInRangeYears(productList4, LOAN_TERM_MIN4, LOAN_TERM_MAX4);
			}
			if(!productList5.isEmpty()){
				condition4  = checkIfTermInRangeYears(productList5, LOAN_TERM_MIN5, LOAN_TERM_MAX5);
			}
			if(!productList6.isEmpty()){
				condition4  = checkIfTermInRangeYears(productList6, LOAN_TERM_MIN6, LOAN_TERM_MAX6);
			}
			if(!productList7.isEmpty()){
				condition4  = checkIfTermInRangeMonths(productList7, LOAN_TERM_MIN7, LOAN_TERM_MAX7);
			}
			//isTermInRange
			ruleResultIndicator = condition1 && condition2 && condition3 && condition4 && condition5 && condition6 && condition7;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean checkIfValidTerm(List<Product> productList, int loanTerm) {
		boolean validTerm = true;
		
		for (Product product : productList){
			long totalTerm = calculateTerm(product.getProposedTerm().getYears(), product.getProposedTerm().getMonths());
			if(!ruleExecutionUtil.isTermLessThanOrEqualForLong(ruleConfigMap, loanTerm, totalTerm)){
				validTerm = false;
				break;
			}
		}
		return validTerm;
	}
	
	private boolean checkIfTermInRangeYears(List<Product> productList, int loanTermMin, int loanTermMax) {
		boolean validTerm = true;
		
		for (Product product : productList){
			if(null!=product.getIsRevolvingLineOfCredit() && !product.getIsRevolvingLineOfCredit()) {
				long totalTerm = calculateTerm(product.getProposedTerm().getYears(), product.getProposedTerm().getMonths());
				if(!ruleExecutionUtil.isTermInRangeYears(ruleConfigMap, loanTermMin, loanTermMax, totalTerm)){
					validTerm = false;
					break;
				}
			}			
		}
		return validTerm;
	}
	
	private boolean checkIfTermInRangeMonths(List<Product> productList, int loanTermMin, int loanTermMax) {
		boolean validTerm = true;
		
		for (Product product : productList){
			if(null!=product.getIsRevolvingLineOfCredit() && !product.getIsRevolvingLineOfCredit()) {
				long totalTerm = calculateTerm(product.getProposedTerm().getYears(), product.getProposedTerm().getMonths());
				if(!ruleExecutionUtil.isTermInRangeYears(ruleConfigMap, loanTermMin, loanTermMax, totalTerm)){
					validTerm = false;
					break;
				}
			}			
		}
		return validTerm;
	}
	
	private List<Product> getProductsWithGivenTypes(List<Product> productList, int ruleConfigId){
		List<Product> applicableProductList = new ArrayList<Product>();
		for (Product product : productList){
			if(null!= product.getIsIncreaseOnly() && product.getIsIncreaseOnly()){
				continue;
			}else{
				if(ruleExecutionUtil.isContains(ruleConfigMap, ruleConfigId, product.getProductCategroy().getProductTypeId())){
					applicableProductList.add(product);
				}
			}
		}
		return applicableProductList;
	}
	
	private long calculateTerm(long termYears, long termMonths) {
		return termYears * 12 + termMonths;
	}

}
