package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;
@Component("DecisionBR_17")
public class DecisionBR_17 extends Rule {
	private static final int CAL_LEVEL1 = 1;
	private static final int CAL_LEVEL2 = 2;

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		DealDetails dealDetails = (DealDetails) arg;

		boolean isRuleApplicable = isRuleApplicable(ruleResults);

		if (isRuleApplicable) {
			//The logged in user have a CAL Level that is >=1 and <= 5?
			ruleResultIndicator = ruleExecutionUtil.isInRange(ruleConfigMap, CAL_LEVEL1, CAL_LEVEL2, dealDetails.getLoggedInUser().getCalLevel());
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check Entry Criteria for Rule DecisionBR_17
	 * 
	 * @param dealDetails
	 * @param ruleResults
	 * @return
	 */
	private boolean isRuleApplicable(List<RuleResult> ruleResults) {

		// Check following rules passed or not
		// DecisionBR_11 to DecisionBR_15; and up to DecisionBR_7
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,
						RuleConstant.DECISIONBR_11, RuleConstant.DECISIONBR_12,
						RuleConstant.DECISIONBR_13, RuleConstant.DECISIONBR_14,
						RuleConstant.DECISIONBR_15,RuleConstant.DECISIONBR_37));

		for (RuleResult ruleResult : ruleResults) {
			if (requiredRuleNameList.contains(ruleResult.getRuleId())
					&& ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()) {
				return false;
			}
		}

		return true;
	}

}
