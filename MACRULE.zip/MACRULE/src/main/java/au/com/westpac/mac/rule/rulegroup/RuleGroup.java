package au.com.westpac.mac.rule.rulegroup;

import java.util.List;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

public abstract class RuleGroup extends RuleComponent{
	
	protected RuleComponent firstStep;
	protected String ruleGroupId;
	protected String name;
	protected String ruleGroupTypeId;
	
	/**
	 * This method is invoked when the rulegroup is being processed by the rule engine
	 */
	public  List<RuleResult> execute(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec){
		
		setValuesForRuleGroup();	
		exec.setExecutingRuleGroupId(this.ruleGroupId);
		
		if(null != this.firstStep && arg instanceof LVRDetails){
			firstStep.execute(arg, ruleEngineResult, exec);
			return ruleEngineResult;
		}
		
		if(null != this.firstStep){
			firstStep.execute(arg, ruleEngineResult, exec);
		}		
		for(RuleResult ruleResult1 : ruleEngineResult){
			if(null == ruleResult1.getRuleGroupId() || "".equals(ruleResult1.getRuleGroupId())){
				ruleResult1.setRuleGroupId(this.ruleGroupId);
			}
		}
		return ruleEngineResult;
	}

	public void setFirstStep(RuleComponent firstStep) {
		this.firstStep = firstStep;
	}


	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRuleGroupTypeId() {
		return ruleGroupTypeId;
	}

	public void setRuleGroupTypeId(String ruleGroupTypeId) {
		this.ruleGroupTypeId = ruleGroupTypeId;
	}

	//@PostConstruct
	public void setValuesForRuleGroup(){
		this.ruleGroupId = this.getClass().getSimpleName();
		this.firstStep = ruleUtil.getFirstStepForRuleGroup(this);
		
	}
	
}
