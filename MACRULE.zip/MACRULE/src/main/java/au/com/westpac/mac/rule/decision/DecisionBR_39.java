package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_39")
public class DecisionBR_39 extends Rule{

	/*Approved under Lending authority*/
	private static final int LENDING_AUTHORITY_APPROVED = 1;
	private static final int DECISION_COND_APPROVED_UNDER_LA = 2;

	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =isRuleApplicable(dealDetails); 
		if (isRuleApplicable) {
			if(dealDetails.getDealDecision().getApprovedUnderLendingAuthority()!= null){
				if(ruleExecutionUtil.compareBoolean(ruleConfigMap, LENDING_AUTHORITY_APPROVED, dealDetails.getDealDecision().getApprovedUnderLendingAuthority())){
					ruleResultIndicator=true;
				}
			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean isRuleApplicable(DealDetails dealDetails) {
		return ruleExecutionUtil.isContains(ruleConfigMap, DECISION_COND_APPROVED_UNDER_LA, dealDetails.getDealDecision().getDecisionStatusId()) && null!=dealDetails.getDealDecision().getApprovedUnderLendingAuthority();
	}
}
