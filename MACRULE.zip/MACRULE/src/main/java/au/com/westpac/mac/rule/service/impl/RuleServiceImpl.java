package au.com.westpac.mac.rule.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.dao.RuleDAO;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.entity.CheckListEntity;
import au.com.westpac.mac.rule.entity.CheckListRuleGroupMapEntity;
import au.com.westpac.mac.rule.entity.ProductRuleConfigEntity;
import au.com.westpac.mac.rule.entity.RuleConfigEntity;
import au.com.westpac.mac.rule.entity.RuleEngineDataEntity;
import au.com.westpac.mac.rule.entity.RuleEntity;
import au.com.westpac.mac.rule.entity.RuleGroupEntity;
import au.com.westpac.mac.rule.entity.RuleGroupRuleMapEntity;
import au.com.westpac.mac.rule.service.RuleService;



@Service
public class RuleServiceImpl implements RuleService {

	 @Autowired 
	public RuleDAO ruleDAO;
	public static RuleEngineDataEntity staticDataEntity1 = null;  
	
	/**
	 * Loads checklist, rule groups and rule data
	 */
	//@PostConstruct
	@Override
	@Cacheable(value = "ruleEngineDataEntityCache" , key="#root.methodName")
	public RuleEngineDataEntity loadCheckListGroupsAndRuleData() {
		List<CheckListEntity> checkListDetails = null;
		List<RuleGroupEntity> ruleGroupDetails = null;
		List<RuleEntity> ruleDetails = null;
		List<CheckListRuleGroupMapEntity> checkListRuleGroupMap = null;
		List<RuleGroupRuleMapEntity> ruleGroupRuleMap = null;
		List<RuleConfigEntity> ruleConfigDetails = null;
		List<ProductRuleConfigEntity> productRuleConfigDetails = null;
		
		List<List<?>> ruleEngineDataDetailsList = ruleDAO
				.loadCheckListGroupsAndRuleData();

		checkListDetails = (List<CheckListEntity>) ruleEngineDataDetailsList
				.get(0);
		ruleGroupDetails = (List<RuleGroupEntity>) ruleEngineDataDetailsList
				.get(1);
		ruleDetails = (List<RuleEntity>) ruleEngineDataDetailsList.get(2);
		checkListRuleGroupMap = (List<CheckListRuleGroupMapEntity>) ruleEngineDataDetailsList
				.get(3);
		ruleGroupRuleMap = (List<RuleGroupRuleMapEntity>) ruleEngineDataDetailsList
				.get(4);
		ruleConfigDetails = (List<RuleConfigEntity>) ruleEngineDataDetailsList
				.get(5);
		productRuleConfigDetails = (List<ProductRuleConfigEntity>) ruleEngineDataDetailsList
				.get(6);

		
		RuleEngineDataEntity ruleEngineDataEntity = new RuleEngineDataEntity();

		ruleEngineDataEntity.setCheckListDetails(checkListDetails);
		ruleEngineDataEntity.setRuleGroupDetails(ruleGroupDetails);
		ruleEngineDataEntity.setRuleDetails(ruleDetails);
		ruleEngineDataEntity.setMacCheckListRuleGroupMap(checkListRuleGroupMap);
		ruleEngineDataEntity.setCheckListRuleGroupMap(convertCLRuleGroupListToMap(checkListRuleGroupMap));
		ruleEngineDataEntity.setRuleGroupRuleMap(convertRuleGroupRuleListToMap(ruleGroupRuleMap));
		ruleEngineDataEntity.setRuleConfigMap(convertRuleConfigListToMap(ruleConfigDetails, productRuleConfigDetails));
		ruleEngineDataEntity.setMacRuleGroupRuleMapDetails(ruleGroupRuleMap);
		return ruleEngineDataEntity;
	}
	
	/**
	 * Constructs map based on checklist and rulegroup data
	 * @param checkListRuleGroupMap
	 * @return
	 */
	private Map<String, List<String>>convertCLRuleGroupListToMap(List<CheckListRuleGroupMapEntity> checkListRuleGroupMap){
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<CheckListRuleGroupMapEntity> checkListRuleGroupTempMap = checkListRuleGroupMap;
		
		for(CheckListRuleGroupMapEntity checkListRGEntity : checkListRuleGroupMap){
			String checkListId = checkListRGEntity.getCheckListId();
			List<String> ruleGroupList = new ArrayList<String>();
			for(CheckListRuleGroupMapEntity checkListRGTempEntity : checkListRuleGroupTempMap){
				if(checkListRGTempEntity.getCheckListId().equals(checkListId)){
					String ruleGroupId = checkListRGTempEntity.getRuleGroupId();
					ruleGroupList.add(ruleGroupId);
				}
			}
			map.put(checkListId, ruleGroupList);
		}
		
		return map;
	}
	
	/**
	 * Constructs map based on rule group and rule data
	 * @param ruleGroupRuleMap
	 * @return
	 */
	private Map<String, List<String>>convertRuleGroupRuleListToMap(List<RuleGroupRuleMapEntity> ruleGroupRuleMap){
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<RuleGroupRuleMapEntity> ruleGroupRuleTempMap = ruleGroupRuleMap;
		
		for(RuleGroupRuleMapEntity ruleGroupRuleEntity : ruleGroupRuleMap){
			String ruleGroupId = ruleGroupRuleEntity.getRuleGroupId();
			Map<String,Integer> ruleIDSeqMap = new HashMap<String, Integer>();
			for(RuleGroupRuleMapEntity ruleGroupRuleTempEntity : ruleGroupRuleTempMap){
				if(ruleGroupRuleTempEntity.getRuleGroupId().equals(ruleGroupId)){
					String ruleId = ruleGroupRuleTempEntity.getRuleId();
					ruleIDSeqMap.put(ruleId,ruleGroupRuleTempEntity.getSeqNo());
				}
			}
			ValueComparator bvc =  new ValueComparator(ruleIDSeqMap);
	        TreeMap<String,Integer> sortedMap = new TreeMap<String,Integer>(bvc);
	        sortedMap.putAll(ruleIDSeqMap);
	        Set<String> ruleIDLst = sortedMap.keySet();
	        List<String> ruleIDList = new ArrayList<String>(ruleIDLst);			
			map.put(ruleGroupId, ruleIDList);
		}
		
		return map;
	}
	
	/**
	 * Constructs map based on ruleconfig data
	 * @param ruleConfigDetails
	 * @param productRuleConfigDetails 
	 * @return
	 */
	private Map<String, Map<Integer, String>> convertRuleConfigListToMap(List<RuleConfigEntity> ruleConfigDetails, List<ProductRuleConfigEntity> productRuleConfigDetails){
		Map<String, Map<Integer, String>> map = new HashMap<String, Map<Integer, String>>();
		List<RuleConfigEntity> ruleConfigDetailsTemp = ruleConfigDetails;
		List<ProductRuleConfigEntity> productRuleConfigDetailsTemp = productRuleConfigDetails;
		
		for(RuleConfigEntity macRuleConfigEntity : ruleConfigDetails){
			String ruleId = macRuleConfigEntity.getRuleId();
			Map<Integer, String> configMap = new HashMap<Integer, String>();
			for(RuleConfigEntity macRuleConfigTempEntity : ruleConfigDetailsTemp){
				if(macRuleConfigTempEntity.getRuleId().equals(ruleId)){
					configMap.put(macRuleConfigTempEntity.getConfigId(), macRuleConfigTempEntity.getValue());
				}
			}
			map.put(ruleId, configMap);
		}
		for(ProductRuleConfigEntity productConfigEntity : productRuleConfigDetails){
			String ruleId = productConfigEntity.getRuleId();
			String ruleGroupId = productConfigEntity.getRuleGroupId();
			Map<Integer, String> configMap = new HashMap<Integer, String>();
			for(ProductRuleConfigEntity productRuleConfigTempEntity : productRuleConfigDetailsTemp){
				if((productRuleConfigTempEntity.getRuleGroupId()).equals(ruleGroupId) && productRuleConfigTempEntity.getRuleId().equals(ruleId)){
					configMap.put(productRuleConfigTempEntity.getConfigId(), productRuleConfigTempEntity.getValue());
				}
			}
			map.put(ruleGroupId.concat(ruleId), configMap);
		}
		
		return map;
	}
	
	public String getIdOfFirstRuleGroupForCheckList(String checkListId) {
		return "";
	}

	public void saveRuleResultsForDeal(long dealId, long userId,
			List<RuleResult> ruleResultList){
		boolean canDelete = true;
				
		for(RuleResult ruleResult : ruleResultList){
			if(ruleResultList.size() == 1 && ruleResult.getRuleId().equalsIgnoreCase(RuleConstant.DECISIONBR_16)) {
				canDelete = false;
			}			
			ruleDAO.saveRuleResult(dealId, userId, canDelete, ruleResult);
			canDelete = false;
		}
		
	}
	
	public List<RuleResult> getRuleResultsForDeal(long dealId){
		return ruleDAO.getRuleResultsForDeal(dealId);
	}
	
	@Override
	public List<RuleEntity> getDecisionRules(String rulePattern) {
		return ruleDAO.getDecisionRules(rulePattern);
	}

	@Override
	public void saveDecisionRuleDetails(String xmlData) {
		ruleDAO.saveDecisionRuleDetails(xmlData);
	}

	@Override
	public void updateRuleConfigDetails(RuleEntity ruleEntity) {
		if(null != ruleEntity && null!=ruleEntity.getRuleConfigList() && !ruleEntity.getRuleConfigList().isEmpty()){
			for(RuleConfigEntity entity:ruleEntity.getRuleConfigList()){
				ruleDAO.updateRuleConfigDetails(entity);
			}
		}
	}
}
class ValueComparator implements Comparator<String> {

    Map<String, Integer> base;
    public ValueComparator(Map<String, Integer> base) {
        this.base = base;
    }

    // Note: this comparator imposes orderings that are inconsistent with equals.    
    public int compare(String a, String b) {
        if (base.get(a) <= base.get(b)) {
            return -1;
        } else {
            return 1;
        } // returning 0 would merge keys
    }
   
}

