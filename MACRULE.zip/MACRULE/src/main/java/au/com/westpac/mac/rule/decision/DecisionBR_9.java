package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_9")
public class DecisionBR_9 extends Rule{
	/*Is the Customer has traded profitably (after adjustments) for a minimum of 2 years (based on latest available financial statements)*/
	private static final int PRODUCT_FAMILY = 1;
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {		
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(dealDetails); 
		if(isRuleApplicable && dealDetails.getDeal().isCustomerTradedProfitablyForMinYears()){
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}
	private boolean checkifRuleApplicable(DealDetails dealDetails){
		List<Product> productList=dealDetails.getProducts();
		return ruleExecutionUtil.checkIfAllProductIsOfGivenTypeInList(productList, ruleConfigMap, PRODUCT_FAMILY);
	}
}
