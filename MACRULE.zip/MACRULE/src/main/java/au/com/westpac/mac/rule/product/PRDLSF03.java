package au.com.westpac.mac.rule.product;


import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDLSF03")
@Scope("prototype")
public class PRDLSF03 extends ProductRule {

	private static final int LOAN_SERVICE_FEE1 = 1;// 10
	private static final int LOAN_SERVICE_FEE2 = 2;// 35
	private static final int LOAN_SERVICE_FEE3 = 3;// 75
	private static final int LOAN_SERVICE_FEE4 = 4;// 100
	private static final int PURCHASE_AMOUNT1 = 5;// 20000
	private static final int PURCHASE_AMOUNT3 = 7;// 60000
	private static final int PURCHASE_AMOUNT4 = 8;// 99999
	private static final int PURCHASE_AMOUNT5 = 9;// 100000

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		List<ProductFee> productFeeList = product.getProductFeeList();
		if (null != productFeeList && !productFeeList.isEmpty()) {
			for (ProductFee productFee : productFeeList) {
				if (productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID || productFee.getFeeTypeId() == RuleConstant.OVERDRAFT_FACILITY_FEE_TYPE_ID) {
					if (null != product.getProductValidation()
							&& null != product.getProductValidation()
									.getResultantAmount()) {
						if (ruleExecutionUtil.isLessThan(ruleConfigMap,
								PURCHASE_AMOUNT1, product
										.getProductValidation()
										.getResultantAmount().doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(LOAN_SERVICE_FEE1)));
						}

						else if (ruleExecutionUtil.isGreaterThanOrEqual(ruleConfigMap,
								PURCHASE_AMOUNT1, product
										.getProductValidation()
										.getResultantAmount().doubleValue())
								&& ruleExecutionUtil.isLessThan(ruleConfigMap,
										PURCHASE_AMOUNT3, product
												.getProductValidation()
												.getResultantAmount()
												.doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(LOAN_SERVICE_FEE2)));
							;
						}

						else if (ruleExecutionUtil.isGreaterThanOrEqual(ruleConfigMap,
								PURCHASE_AMOUNT3, product
										.getProductValidation()
										.getResultantAmount().doubleValue())
								&& ruleExecutionUtil.isLessThanOrEqual(ruleConfigMap,
										PURCHASE_AMOUNT4, product
												.getProductValidation()
												.getResultantAmount()
												.doubleValue())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(LOAN_SERVICE_FEE3)));
						}
						if (ruleExecutionUtil.isGreaterThanOrEqualBigDecimal(
								ruleConfigMap, PURCHASE_AMOUNT5, product
										.getProductValidation()
										.getResultantAmount())) {
							ruleResultIndicator = true;
							productFee.setFeeAmount(Double
									.valueOf(ruleConfigMap
											.get(LOAN_SERVICE_FEE4)));
						}
					}
				}

			}
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);
	}

}
