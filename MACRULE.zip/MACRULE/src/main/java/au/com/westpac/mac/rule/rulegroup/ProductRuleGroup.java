package au.com.westpac.mac.rule.rulegroup;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.rule.domain.RuleComponent;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;


@Component("ProductRuleGroup")
@Scope("prototype")
public class ProductRuleGroup extends RuleGroup{
	
	protected List<RuleComponent> listOFRules;
	protected String ruleGroupId;
	protected String name;
	protected String ruleGroupTypeId;
	
	
	public void setListOFRules(List<RuleComponent> listOFRules) {
		this.listOFRules = listOFRules;
	}

	public  List<RuleResult> execute(Object arg, List<RuleResult> ruleEngineResult, RuleEngineExecutionContext exec){
		setValuesForRuleGroup();
		exec.setExecutingRuleGroupId(this.ruleGroupId);
		for(RuleComponent rule: listOFRules){
			rule.execute(arg, ruleEngineResult, exec);
		}
		return ruleEngineResult;
	}

	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRuleGroupTypeId() {
		return ruleGroupTypeId;
	}

	public void setRuleGroupTypeId(String ruleGroupTypeId) {
		this.ruleGroupTypeId = ruleGroupTypeId;
	}

	//@PostConstruct
	public void setValuesForRuleGroup(){
		this.ruleGroupId = this.id;
		this.listOFRules = ruleUtil.getRulesForRuleGroup(this);
	}
	
}
