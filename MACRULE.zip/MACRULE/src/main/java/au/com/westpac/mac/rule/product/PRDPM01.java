package au.com.westpac.mac.rule.product;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.ProductRule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("PRDPM01")
@Scope("prototype")
public class PRDPM01 extends ProductRule {
	
	private static final int PRODUCT_MARGIN = 1;
	
	@Override
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = true;
		boolean isRuleApplicable = true;
		Product product = (Product) arg;
		if(null != product.getProductValidation()){
			product.getProductValidation().setProductMargin(Double.valueOf(ruleConfigMap.get(PRODUCT_MARGIN)));
		ruleResultIndicator = ruleExecutionUtil.isEqual(ruleConfigMap, PRODUCT_MARGIN, product.getProductValidation().getProductMargin());
		
		}
		
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable, ruleResultIndicator);
	}

}
