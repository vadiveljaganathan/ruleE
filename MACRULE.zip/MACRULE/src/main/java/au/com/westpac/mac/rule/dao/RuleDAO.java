package au.com.westpac.mac.rule.dao;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.mapping.StatementType;
import org.springframework.stereotype.Repository;

import au.com.westpac.mac.domain.business.rule.RuleDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.entity.RuleConfigEntity;
import au.com.westpac.mac.rule.entity.RuleEntity;

@Repository("ruleDAO")
public interface RuleDAO {

	@Select(value = "{CALL usp_GetCheckListGroupsAndRuleData}")
	@Options(statementType = StatementType.CALLABLE)
	@ResultMap("checkListDetails,ruleGroupDetails,ruleDetails,checkListRuleGroupMap, ruleGroupRuleMap, ruleConfigDetails, productRuleConfigDetails")
	public List<List<?>> loadCheckListGroupsAndRuleData();
	
	
	@Select(value = "{CALL usp_InsertOrUpdateRuleResult(#{dealId, mode=IN,jdbcType=INTEGER},"
			+ " #{userId, mode=IN,jdbcType=INTEGER}, "
			+ " #{canDelete, mode=IN,jdbcType=BIT}, "
			+ " #{ruleResult.ruleId, mode=IN,jdbcType=VARCHAR}, "
			+ " #{ruleResult.ruleGroupId, mode=IN, jdbcType=VARCHAR}, "
			+ " #{ruleResult.isRuleApplicable, mode=IN, jdbcType=BIT},"
			+ " #{ruleResult.rulePassed, mode=IN, jdbcType=BIT}"
			+ ")}")
	@Options(statementType = StatementType.CALLABLE)
	public void saveRuleResult(@Param ("dealId")long dealId, @Param ("userId")long userId,@Param ("canDelete") boolean canDelete,
			@Param ("ruleResult") RuleResult ruleResult);
	
		
	@Select(value = "{CALL usp_GetRuleResultsForDeal(#{dealId, mode=IN, jdbcType=INTEGER})}")
	@Results(value = {
			@Result(property = "ruleId", column = "RuleId"),
			@Result(property = "isRuleApplicable", column = "IsRuleApplicable"),
			@Result(property = "rulePassed", column = "RuleResult")})
	public List<RuleResult> getRuleResultsForDeal(long dealId);	
	
	@Select(value = "{CALL usp_getRuleDetails(#{rulePattern, mode=IN,jdbcType=VARCHAR})}")
   	@Options(statementType = StatementType.CALLABLE)
    @ResultMap("ruleDetails")
	public List<RuleEntity> getDecisionRules(@Param("rulePattern")String rulePattern);

    @Select(value = "{CALL usp_saveDecisionRuleDetails(#{XmlData, mode=IN,jdbcType=INTEGER})}")
	@Options(statementType = StatementType.CALLABLE)
	public void saveDecisionRuleDetails(@Param("XmlData")String rulesLitXmlString);

    @Select(value = "{CALL usp_updateRuleConfigDetails(#{ruleConfigEntity.ruleId, mode=IN,jdbcType=VARCHAR},"
			+ " #{ruleConfigEntity.configId, mode=IN,jdbcType=INTEGER}, "
			+ " #{ruleConfigEntity.value, mode=IN,jdbcType=VARCHAR}"
			+ ")}")
	@Options(statementType = StatementType.CALLABLE)
	public void updateRuleConfigDetails(@Param("ruleConfigEntity")RuleConfigEntity entity);
    
	
}
