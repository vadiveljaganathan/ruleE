package au.com.westpac.mac.rule.engine;

public class RuleEngineExecutionContext {

	private String executingCheckListId;
	
	private String executingRuleGroupId;
	
	private String executingRuleId;
	
	private boolean afterSalesQuestionExecutedOnce;
	
	public boolean isAfterSalesQuestionExecutedOnce() {
		return afterSalesQuestionExecutedOnce;
	}

	public void setAfterSalesQuestionExecutedOnce(
			boolean afterSalesQuestionExecutedOnce) {
		this.afterSalesQuestionExecutedOnce = afterSalesQuestionExecutedOnce;
	}

	public String getExecutingCheckListId() {
		return executingCheckListId;
	}

	public void setExecutingCheckListId(String executingCheckListId) {
		this.executingCheckListId = executingCheckListId;
	}

	public String getExecutingRuleGroupId() {
		return executingRuleGroupId;
	}

	public void setExecutingRuleGroupId(String executingRuleGroupId) {
		this.executingRuleGroupId = executingRuleGroupId;
	}

	public String getExecutingRuleId() {
		return executingRuleId;
	}

	public void setExecutingRuleId(String executingRuleId) {
		this.executingRuleId = executingRuleId;
	}
	
}
