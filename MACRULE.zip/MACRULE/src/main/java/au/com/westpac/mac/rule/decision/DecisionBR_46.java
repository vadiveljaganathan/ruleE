package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_46")
public class DecisionBR_46 extends Rule {
		
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(ruleResults);
				
		if (isRuleApplicable) {
			
			if (dealDetails.getDeal().isApprovalOverrideCreditDecision()) {
				ruleResultIndicator = true;
			}
		} else {
			ruleResultIndicator = true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);

	}

	private boolean checkifRuleApplicable(List<RuleResult> ruleResults){
		for (RuleResult ruleResult : ruleResults) {
			if(RuleConstant.DECISIONBR_44.equalsIgnoreCase(ruleResult.getRuleId())){
				if((!ruleResult.isRuleApplicable()) || (ruleResult.isRuleApplicable() && ruleResult.isRulePassed())){
					return true;
				}
			}
		}		
		return false;
	}
}
