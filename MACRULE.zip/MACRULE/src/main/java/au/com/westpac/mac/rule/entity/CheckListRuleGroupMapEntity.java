package au.com.westpac.mac.rule.entity;


public class CheckListRuleGroupMapEntity {

	private String checkListId;
	
	private String ruleGroupId;

	private boolean afterDisplay;
	
	public boolean isAfterDisplay() {
		return afterDisplay;
	}

	public void setAfterDisplay(boolean afterDisplay) {
		this.afterDisplay = afterDisplay;
	}

	public String getCheckListId() {
		return checkListId;
	}

	public void setCheckListId(String checkListId) {
		this.checkListId = checkListId;
	}

	public String getRuleGroupId() {
		return ruleGroupId;
	}

	public void setRuleGroupId(String ruleGroupId) {
		this.ruleGroupId = ruleGroupId;
	}
	
}
