package au.com.westpac.mac.rule.decision;

import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_50")
public class DecisionBR_50 extends Rule {

	
	public void makeDecision(Object arg, List<RuleResult> ruleResults) {
			DealDetails dealDetails = (DealDetails)arg;
			boolean ruleResultIndicator = false;
			boolean isRuleApplicable = false;	
			ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}	

}

