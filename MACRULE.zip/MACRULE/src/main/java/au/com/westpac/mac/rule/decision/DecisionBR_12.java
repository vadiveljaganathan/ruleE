package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_12")
public class DecisionBR_12 extends Rule{

	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		DealDetails dealDetails = (DealDetails)arg;
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable =checkifRuleApplicable(ruleResults,dealDetails); 
		if(isRuleApplicable && dealDetails.getDeal().isSectorPolicyApplicable()){
			ruleResultIndicator=true;
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,ruleResultIndicator);
	}

	private boolean checkifRuleApplicable(List<RuleResult> ruleResults,DealDetails dealDetails){
		final List<String> requiredRuleNameList = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_1,
						RuleConstant.DECISIONBR_2, RuleConstant.DECISIONBR_3,
						RuleConstant.DECISIONBR_4, RuleConstant.DECISIONBR_5,
						RuleConstant.DECISIONBR_6, RuleConstant.DECISIONBR_7,RuleConstant.DECISIONBR_37));
		final List<String> ruleBR11 = new ArrayList<String>(
				Arrays.asList(RuleConstant.DECISIONBR_11));
		if(!dealDetails.isRolloverDeal()){
		for (RuleResult ruleResult : ruleResults) {
			if(requiredRuleNameList.contains(ruleResult.getRuleId())){
				if(ruleResult.isRuleApplicable() && !ruleResult.isRulePassed()){
					return false;
				}
			}else if(ruleBR11.contains(ruleResult.getRuleId()) && !(ruleResult.isRulePassed() || !ruleResult.isRuleApplicable())){
					return false;	
			}
		}
		}
		return true;
	}
}
