package au.com.westpac.mac.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AllocationGuarantors;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.rule.domain.Rule;
import au.com.westpac.mac.rule.domain.RuleResult;

@Component("DecisionBR_18")
public class DecisionBR_18 extends Rule {
	private static final int PRODUCT_FAMILY = 1;
	private static final int PRODUCT_TYPE = 2;
	private static final int RELATIONSHIP_ID = 4;
	public List<Product> listOFProducts = new ArrayList<Product>();

	@Override
	protected void makeDecision(Object arg, List<RuleResult> ruleResults) {
		boolean ruleResultIndicator = false;
		boolean isRuleApplicable = false;
		DealDetails dealDetails = (DealDetails) arg;
		
		isRuleApplicable = isRuleApplicable(dealDetails);

		if (isRuleApplicable) {
			ruleResultIndicator = checkIfDirectorGuaranteeExists(
					listOFProducts, dealDetails);
		}
		ruleExecutionUtil.addRuleResult(this, ruleResults, isRuleApplicable,
				ruleResultIndicator);

	}

	/**
	 * Method to check Entry Criteria for Rule DecisionBR_18
	 * 
	 * @param dealDetails
	 * @param listOFProducts
	 * @return
	 */
	private boolean isRuleApplicable(DealDetails dealDetails) {
		listOFProducts = getListOfEligibleProducts(dealDetails.getProducts(),
				dealDetails);
		if (null != listOFProducts && listOFProducts.size() > 0) {
							return true;
		}
		return false;
	}

	/**
	 * Method to check if Director Guarantee Exists for all eligible product
	 * 
	 * @param listOFProducts
	 * @param dealDetails
	 * @return
	 */
	private boolean checkIfDirectorGuaranteeExists(
			List<Product> listOFProducts, DealDetails dealDetails) {
		for (Product product : listOFProducts) {
						if (!isProductSecuredByDirectorsGuarantee(product, dealDetails)) {
							return false;
			}
		}
		return true;
	}

	/**
	 * Method to check if product is secured by directors Guarantee
	 * 
	 * @param product
	 * @param dealDetails
	 * @return
	 */

	private boolean isProductSecuredByDirectorsGuarantee(Product product,
			DealDetails dealDetails) {
		if(null!=dealDetails.getGuarantors()){
			for(AllocationGuarantors ag: dealDetails.getGuarantors()){
				if (product.getId() == ag.getDmProductId() && ruleExecutionUtil.isContains(ruleConfigMap,
						RELATIONSHIP_ID,
						ag.getRelationshipTypeId())) {
					return true;
				}
			}
		}
		return false;

	}

	/**
	 * Check if Given Products Owned By Non-individual Customer
	 * 
	 * @param borrower
	 * @param dealDetails
	 * @return
	 */
	private boolean checkIfGivenProductIsOwnByNonIndividual(DealDetails dealDetails, Borrower borrower) {
		if(null != dealDetails.getNonIndividualCustomers()){
			for (NonIndividual nonIndividual : dealDetails
					.getNonIndividualCustomers()) {	
				List<AccountOwnerCustomer> accList = dealDetails.getAccountOwnerCustomer();
				if(null!=accList){
					for(AccountOwnerCustomer acc: accList){
						if(acc.getAccountOwnerId() == borrower.getId()){
						if (!nonIndividual.getIsSoleTrader()
								&& nonIndividual.getId() == acc.getCustomerId()) {
							return true;
							}
						}
					}
				}			
			}
		}		
		return false;
	}

	/**
	 * Get list of products where Customer Type (ID 26) for any of the Borrowing
	 * entities involved in the Deal = "Non-Individual" AND NOT IN Product
	 * Family = Business Credit Card OR Product Type = "Temporary Overdraft -
	 * Business
	 * 
	 * @param products
	 * @param dealDetails
	 * @return
	 */

	private List<Product> getListOfEligibleProducts(List<Product> products,
			DealDetails dealDetails) {
		List<Product> listOFProducts = new ArrayList<Product>();
		for (Product product : products) {
			boolean isNonIndividualCustomer = false;
			// Check For Product Type Temporary Overdraft - Business and
			// Business Credit Cards
			if (!ruleExecutionUtil.isContains(ruleConfigMap, PRODUCT_FAMILY,
					product.getProductCategroy().getProductFamilyId())
					&& !ruleExecutionUtil.isContains(ruleConfigMap,
							PRODUCT_TYPE, product.getProductCategroy()
									.getProductTypeId())) {
				isNonIndividualCustomer = checkIfGivenProductIsOwnByNonIndividual(
						dealDetails, product.getBorrower());
				if (isNonIndividualCustomer) {
					listOFProducts.add(product);
				}
			}

		}
		return listOFProducts;
	}

}
