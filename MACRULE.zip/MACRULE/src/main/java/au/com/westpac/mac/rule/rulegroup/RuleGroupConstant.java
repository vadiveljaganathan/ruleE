package au.com.westpac.mac.rule.rulegroup;

public class RuleGroupConstant {

	public static final String DEC_RG_1 = "DEC_RG_1";

	public static final String DEC_RG_2 ="DEC_RG_2";

	public static final String DEC_RG_3 ="DEC_RG_3";

	public static final String DEC_RG_4 ="DEC_RG_4";

	public static final String DEC_RG_5 ="DEC_RG_5";

	public static final String DEC_RG_6 ="DEC_RG_6";

	public static final String DEC_RG_10 = "DEC_RG_10";

	public static final String DEC_RG_14 = "DEC_RG_14";
}
