package au.com.westpac.mac.unittest.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.customergroup.CustomerGroupLendingAuthority;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_17;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_17 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_17 decisionBR_17;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR17Pass() {
		dealDetails = new DealDetails();
		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);
		Deal deal = new Deal();	
		deal.setCustomerTradedProfitablyForMinYears(true);
		dealDetails.setDeal(deal);
		dealDetails.setProducts(new ArrayList<Product>());
		dealDetails.setCustomerGroupLendingAuthority(new CustomerGroupLendingAuthority());
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_17");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		decisionBR_17.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_17".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR17Negative() {
		dealDetails = new DealDetails();
		User loggedInUser = new User();
		loggedInUser.setCalLevel(6);
		dealDetails.setLoggedInUser(loggedInUser);
		dealDetails.setProducts(new ArrayList<Product>());
		dealDetails.setCustomerGroupLendingAuthority(new CustomerGroupLendingAuthority());
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_17");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		decisionBR_17.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_17".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_11");
		populateRuleResultObject(ruleEngineResult, "decisionBR_12");
		populateRuleResultObject(ruleEngineResult, "decisionBR_13");
		populateRuleResultObject(ruleEngineResult, "decisionBR_14");
		populateRuleResultObject(ruleEngineResult, "decisionBR_15");
		populateRuleResultObject(ruleEngineResult, "decisionBR_1");
		populateRuleResultObject(ruleEngineResult, "decisionBR_2");
		populateRuleResultObject(ruleEngineResult, "decisionBR_3");
		populateRuleResultObject(ruleEngineResult, "decisionBR_4");
		populateRuleResultObject(ruleEngineResult, "decisionBR_5");
		populateRuleResultObject(ruleEngineResult, "decisionBR_6");
		populateRuleResultObject(ruleEngineResult, "decisionBR_7");

	}

	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(true);
		ruleEngineResult.add(ruleResult);

	}

	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
