package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR026;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR026 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR026 lvr026;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR026Pass() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(86);
		lvrDetails.setPostCode("2899");
		lvrDetails.setAllocatedProductTypes("142");
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR026");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr026.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR026".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	

}
