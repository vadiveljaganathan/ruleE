package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR021;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR021 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR021 lvr021;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR021Pass() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(86);
		lvrDetails.setAssetValue(new BigDecimal(3228000));
		lvrDetails.setPostCode("1");
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR021");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr021.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR021".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	

}
