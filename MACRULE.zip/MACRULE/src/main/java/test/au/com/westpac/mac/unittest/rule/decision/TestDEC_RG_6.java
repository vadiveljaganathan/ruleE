package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.request.Serviceability;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
//import au.com.westpac.mac.domain.business.customergroup.risk.CustomerGroupRiskProfile;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDEC_RG_6 {
	@Autowired
	RuleEngine ruleEngine;

	DealDetails dealDetails;
	private static final String CUST_IN_GOOD_STANGING = "Y";
	/******************************************* RULE 33 TESTING ******************************************/
	@Test
	public void testDecisionBR33PassForNewFacility() {
		
		createDecisionBR33PassForNewFacility();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33PassForModifiedFacility() {
		dealDetails.setAssetAllocations(new ArrayList<AssetAllocations>());
		
		createDecisionBR33PassForModifiedFacility();
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
/*	@Test
	public void testDecisionBR33PassForCondition3() {
		
		createDecisionBR33PassForCondition3();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}*/
	@Test
	public void testDecisionBR33FailForModifiedFacilityRequestedAmount() {
		
		createDecisionBR33FailForModifiedFacilityRequestedAmount();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33FailForNewFacilityRequestedAmount() {
		
		createDecisionBR33FailForNewFacilityRequestedAmount();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33FailForModifiedFacilityLimitChangeAmount() {
		
		createDecisionBR33FailForModifiedFacilityLimitChangeAmount();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33FailForNewFacilityLLVR() {
		
		createDecisionBR33FailForNewFacilityLLVR();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33NotApplicableForCondition3() {
		
		createDecisionBR33NotApplicableForCondition3();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33NotApplicableForModifiedFacility() {
		
		createDecisionBR33NotApplicableForModifiedFacility();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR33NotApplicableForNewFacility() {
		
		createDecisionBR33NotApplicableForNewFacility();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	/******************************************* RULE 34 TESTING******************************************/
	@Test
	public void testDecisionBR34Pass() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR34FailForACRP() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34FailForACRP();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR34NotApplicableForCalLevel() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34NotApplicableForCalLevel();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR34NotApplicableForICRDSC() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34NotApplicableForICRDSC();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	/******************************************* RULE 35 TESTING ******************************************/
	@Test
	public void testDecisionBR35Pass() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {				
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR35FailForICRDSC() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35FailForICRDSC();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	/******************************************* RULE 36 TESTING ******************************************/
	@Test
	public void testDecisionBR36Pass() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		createDecisionBR36Pass();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_36".equals(ruleResult.getRuleId())) {				
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR36FailForWithinThresholdFlag() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		createDecisionBR36FailForWithinThresholdFlag();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR36NotApplicableForCalLevel() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		createDecisionBR36NotApplicableForCalLevel();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR36NotApplicableForICRDSC() {
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		createDecisionBR36NotApplicableForICRDSC();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_34".equals(ruleResult.getRuleId())) {				
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	/******************************************* RULE 33 DEAL CREATION ******************************************/

	private void createDecisionBR33PassForNewFacility() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setFacilityId(1000L);
		product.setProposedLimit(new BigDecimal(30000));
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setRequestedAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		return;
	}

	private void createDecisionBR33PassForModifiedFacility() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(7);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		
		
		product.setId(1000L);
		product.setFacilityId(1000000L);
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setLimitChangeAmount(new BigDecimal(30000));
		product.setRequestedAmount(new BigDecimal(30000));
		product.setProposedLimit(new BigDecimal(30000));
		//product.setBsb("ABC");
		//product.setAccountNumber("ABC");
		
		Asset asset = new Asset();
		asset.setAssetId(111L);
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(224);
		asset.setAllocationAmount(new BigDecimal(50000));
		product.setAllocatedAssets(Arrays.asList(asset));
		Map<Long, BigDecimal> assetIdAndAllocationMap = new HashMap<Long, BigDecimal>();
		assetIdAndAllocationMap.put(111L, new BigDecimal(20000));
		product.setAssetIdAndAllocationMap(assetIdAndAllocationMap);
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		

		HashMap<Long, BigDecimal> productIdAllocationAmountMap = new HashMap<Long, BigDecimal>();
		productIdAllocationAmountMap.put(1000L, new BigDecimal(30001));
		asset.setAssetCategory(assetCategory);
		asset.setProductIdAllocationAmountMap(productIdAllocationAmountMap);
		dealDetails.setAsset(Arrays.asList(asset));
		

		return;
	}

	private void createDecisionBR33PassForCondition3() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(14);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		dealDetails.setProducts(Arrays.asList(product));

		return;
	}

	private void createDecisionBR33FailForNewFacilityRequestedAmount() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(7);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setFacilityId(1000L);
		product.setProposedLimit(new BigDecimal(20000));
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setLimitChangeAmount(new BigDecimal(30000));
		product.setRequestedAmount(new BigDecimal(500001));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		return;
	}

	private void createDecisionBR33FailForNewFacilityLLVR() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLlvr(101d);
		product.setLimitChangeAmount(new BigDecimal(30000));
		product.setRequestedAmount(new BigDecimal(300000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		return;
	}

	private void createDecisionBR33FailForModifiedFacilityRequestedAmount() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setId(1000L);
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setLimitChangeAmount(new BigDecimal(30000));
		product.setRequestedAmount(new BigDecimal(500));
		//product.setBsb("ABC");
		//product.setAccountNumber("ABC");
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);

		HashMap<Long, BigDecimal> productIdAllocationAmountMap = new HashMap<Long, BigDecimal>();
		productIdAllocationAmountMap.put(1000L, new BigDecimal(300));
		asset.setAssetCategory(assetCategory);
		asset.setProductIdAllocationAmountMap(productIdAllocationAmountMap);
		dealDetails.setAsset(Arrays.asList(asset));

		return;
	}

	private void createDecisionBR33FailForModifiedFacilityLimitChangeAmount() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(4);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setId(1000L);
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setLimitChangeAmount(new BigDecimal(500001));
		product.setRequestedAmount(new BigDecimal(3000));
		//product.setBsb("ABC");
		//product.setAccountNumber("ABC");
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);

		HashMap<Long, BigDecimal> productIdAllocationAmountMap = new HashMap<Long, BigDecimal>();
		productIdAllocationAmountMap.put(1000L, new BigDecimal(30000));
		asset.setAssetCategory(assetCategory);
		asset.setProductIdAllocationAmountMap(productIdAllocationAmountMap);
		dealDetails.setAsset(Arrays.asList(asset));

		return;
	}

	private void createDecisionBR33NotApplicableForNewFacility() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(2);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		dealDetails.setProducts(Arrays.asList(product));

		return;
	}

	private void createDecisionBR33NotApplicableForModifiedFacility() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(2);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		dealDetails.setProducts(Arrays.asList(product));
		return;
	}

	private void createDecisionBR33NotApplicableForCondition3() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(26);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		dealDetails.setProducts(Arrays.asList(product));

		return;
	}
	/******************************************* RULE 34 DEAL CREATION ******************************************/
	private void createDecisionBR34Pass() {
	//	CustomerGroupRiskProfile customerGroupRiskProfile = new CustomerGroupRiskProfile();
	//	customerGroupRiskProfile.setOverAllRiskId(1);
		//dealDetails.setCustomerGroupRiskProfile(customerGroupRiskProfile);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR34FailForACRP() {
	//	CustomerGroupRiskProfile customerGroupRiskProfile = new CustomerGroupRiskProfile();
		//customerGroupRiskProfile.setOverAllRiskId(4);
	//	dealDetails.setCustomerGroupRiskProfile(customerGroupRiskProfile);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR34NotApplicableForCalLevel() {
		//CustomerGroupRiskProfile customerGroupRiskProfile = new CustomerGroupRiskProfile();
	//	customerGroupRiskProfile.setOverAllRiskId(1);
		//dealDetails.setCustomerGroupRiskProfile(customerGroupRiskProfile);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(1);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR34NotApplicableForICRDSC() {
		//CustomerGroupRiskProfile customerGroupRiskProfile = new CustomerGroupRiskProfile();
	//	customerGroupRiskProfile.setOverAllRiskId(1);
		//dealDetails.setCustomerGroupRiskProfile(customerGroupRiskProfile);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(null);
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}
	/******************************************* RULE 35 DEAL CREATION ******************************************/

	private void createDecisionBR35Pass() {

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR35FailForICRDSC() {

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(null);
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		return;
	}

	/********************************* RULE 36 DEAL CREATION **************************************/

	private void createDecisionBR36Pass() {

		//dealDetails.setApprovalConsistentWithinThreshold(true);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(1);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(BigDecimal.ONE);
		serviceability.setDSC(BigDecimal.ONE);
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR36FailForWithinThresholdFlag() {
		dealDetails.getDeal().setApprovalConsistentWithinThreshold(false);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(1);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(BigDecimal.ONE);
		serviceability.setDSC(BigDecimal.ONE);
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR36NotApplicableForCalLevel() {

		dealDetails.getDeal().setApprovalConsistentWithinThreshold(false);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(BigDecimal.ONE);
		serviceability.setDSC(BigDecimal.ONE);
		dealDetails.setServiceability(serviceability);

		return;
	}

	private void createDecisionBR36NotApplicableForICRDSC() {

		dealDetails.getDeal().setApprovalConsistentWithinThreshold(false);

		User loggedInUser = new User();
		loggedInUser.setCalLevel(1);
		dealDetails.setLoggedInUser(loggedInUser);

		Serviceability serviceability = new Serviceability();
		serviceability.setICR(null);
		serviceability.setDSC(BigDecimal.ONE);
		dealDetails.setServiceability(serviceability);

		return;
	}

	@Before
	public void setup() {
		dealDetails = new DealDetails();
		dealDetails.setDeal(new Deal());
		dealDetails.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetails.setCustomer(new ArrayList<Customer>());
		dealDetails.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		
		dealDetails.setRuleStateId((short) 10);
		
		createDecisionBR33PassForNewFacility();
		createDecisionBR34Pass();
		createDecisionBR35Pass();
		createDecisionBR36Pass();
	}
}
