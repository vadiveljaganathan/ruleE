package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroupConditionalLimit;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.request.Serviceability;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDEC_RG_4 {
	@Autowired
	RuleEngine ruleEngine;

	DealDetails dealDetails;

	/******************************************* RULE 16 TESTING ******************************************/
	@Test
	public void testDecisionBR16PassForCondition1() {

		createDecisionBR16PassForCondition1();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16PassForCondition2() {

		createDecisionBR16PassForCondition2();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16PassForCondition3() {

		createDecisionBR16PassForCondition3();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16PassForCondition4() {

		createDecisionBR16PassForCondition4();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16FailForCondition1() {

		createDecisionBR16FailForCondition1();
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setProducts(new ArrayList<Product>());
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16FailForCondition2() {

		createDecisionBR16FailForCondition2();
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setProducts(new ArrayList<Product>());
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16FailForCondition3() {

		createDecisionBR16FailForCondition3();
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setProducts(new ArrayList<Product>());
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	@Test
	public void testDecisionBR16FailForCondition4() {

		createDecisionBR16FailForCondition4();
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setProducts(new ArrayList<Product>());
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_35".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	/******************************************* RULE 16 DEAL CREATION ******************************************/

	private void createDecisionBR16PassForCondition1() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(1);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setBtlTotalAvail(new BigDecimal(30001));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);
		return;
	}

	private void createDecisionBR16PassForCondition2() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setGxAvail(new BigDecimal(30001));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	private void createDecisionBR16PassForCondition3() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(3);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setBodTotalAvail(new BigDecimal(30001));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	private void createDecisionBR16PassForCondition4() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(9);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setUnsecuredAvail(new BigDecimal(30001));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	private void createDecisionBR16FailForCondition1() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(1);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30001));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setBtlTotalAvail(new BigDecimal(30000));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);
		return;
	}

	private void createDecisionBR16FailForCondition2() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30001));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setGxAvail(new BigDecimal(30000));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	private void createDecisionBR16FailForCondition3() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(3);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30001));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setBodTotalAvail(new BigDecimal(30000));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	private void createDecisionBR16FailForCondition4() {

		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(9);
		Product product = new Product();
		product.setProductCategroy(productCategory);
		product.setLimitChangeAmount(new BigDecimal(30001));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroupConditionalLimit customerGroupConditionalLimit = new CustomerGroupConditionalLimit();
		customerGroupConditionalLimit.setUnsecuredAvail(new BigDecimal(30000));
		dealDetails
				.setCustomerGroupConditionalLimit(customerGroupConditionalLimit);

		return;
	}

	@Before
	public void setup() {
		dealDetails = new DealDetails();
		dealDetails.setRuleStateId((short) 7);
		
		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);
		
		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		dealDetails.setServiceability(serviceability);

		createDecisionBR16PassForCondition1();
	}
}
