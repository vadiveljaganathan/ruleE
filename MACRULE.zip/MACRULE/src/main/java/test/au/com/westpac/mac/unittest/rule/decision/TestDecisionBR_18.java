package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.Guarantee;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroupLendingAuthority;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AllocationGuarantors;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_18;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_18 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_18 decisionBR_18;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR18Pass() {
		dealDetails= new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_18");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);		
		Deal deal = new Deal();	
		deal.setCustomerTradedProfitablyForMinYears(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(28);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		Borrower borrower = new Borrower();
		borrower.setId(1111L);
		product.setBorrower(borrower);
		product.setProposedTerm(productTerm);
		product.setId(222222);
		List<Asset> assetList =new ArrayList<Asset>();
		Asset asset = new Asset();
		List<Guarantee> guaranteelist= new ArrayList<Guarantee>();
		guaranteelist.add(new Guarantee());
		asset.setGuaranteeList(guaranteelist);
		assetList.add(asset);
		product.setAllocatedAssets(assetList);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		User user = new User();
		user.setCalLevel(4);
		dealDetails.setLoggedInUser(user);
		CustomerGroupLendingAuthority authority = new CustomerGroupLendingAuthority();
		authority.setGeneralCALAvail(new BigDecimal(250000));
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setId(1111L);
		List<NonIndividual> nonIndList = new ArrayList<NonIndividual>();
		nonIndList.add(nonIndividual);
		dealDetails.setNonIndividualCustomers(nonIndList);
		dealDetails.setCustomerGroupLendingAuthority(authority);
		List<AccountOwnerCustomer> accountOwnerCustomers = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer accountOwnerCustomer = new AccountOwnerCustomer();
		accountOwnerCustomer.setCustomerId(1111L);
		accountOwnerCustomer.setAccountOwnerId(1111);
		accountOwnerCustomers.add(accountOwnerCustomer);
		dealDetails.setAccountOwnerCustomer(accountOwnerCustomers);
		List<AllocationGuarantors> guarantorsList = new ArrayList<AllocationGuarantors>();
		AllocationGuarantors guarantors = new AllocationGuarantors();
		guarantors.setRelationshipTypeId(4);
		guarantors.setDmProductId(222222);
		guarantorsList.add(guarantors);
		dealDetails.setGuarantors(guarantorsList);
		decisionBR_18.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_18".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "DecisionBR_11");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_12");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_13");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_14");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_15");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_1");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_2");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_3");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_4");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_5");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_6");
		populateRuleResultObject(ruleEngineResult, "DecisionBR_7");

	}

	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(true);
		ruleEngineResult.add(ruleResult);

	}

	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}


}
