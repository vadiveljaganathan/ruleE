package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR012;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR012 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR012 lvr012;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR012Pass() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(103);
		lvrDetails.setAssetValue(new BigDecimal(3038001));
		lvrDetails.setPostCode("2500");
		lvrDetails.setStandardLVRFlag(false);
		lvrDetails.setSystemLVR(79);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR012");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr012.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR012".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	

}
