package au.com.westpac.mac.unittest.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.Trust;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_13;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_13 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_13 decisionBR_13;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR13Pass() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_3");
		exec.setExecutingRuleId("decisionBR_13");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setPropertyValuationWithinPolicy(true);
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setAllocatedAssets(new ArrayList<Asset>());
		Borrower borrower = new Borrower();
		borrower.setId(1234);
		product.setBorrower(borrower);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		assetCategory.setAssetFamilyId(13);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		List<Customer> customerList= new ArrayList<Customer>();
		Customer customer = new Customer();
		customer.setId(1111L);
		customer.setCustomerTypeId((short) 3);
		customerList.add(customer);
		List<AccountOwnerCustomer> listOfaccAccountOwnerCustomers = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer aoc = new AccountOwnerCustomer();
		aoc.setCustomerId(1111L);
		aoc.setAccountOwnerId(1234);
		listOfaccAccountOwnerCustomers.add(aoc);
		
		List<Trust> trustList = new ArrayList<Trust>();
		Trust trust= new Trust();
		trust.setId(1111L);
		trust.setTrustTypeId((short) 3);
		trustList.add(trust);
		dealDetails.setTrusts(trustList);
		dealDetails.setAccountOwnerCustomer(listOfaccAccountOwnerCustomers);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
		
		decisionBR_13.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_13".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	@Test
	public void testDecisionBR13Negative() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_3");
		exec.setExecutingRuleId("decisionBR_13");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setPropertyValuationWithinPolicy(true);
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setAllocatedAssets(new ArrayList<Asset>());
		Borrower borrower = new Borrower();
		borrower.setId(1234);
		product.setBorrower(borrower);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		assetCategory.setAssetFamilyId(13);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		List<Customer> customerList= new ArrayList<Customer>();
		Customer customer = new Customer();
		customer.setId(1111L);
		customer.setCustomerTypeId((short) 3);
		customerList.add(customer);
		List<AccountOwnerCustomer> listOfaccAccountOwnerCustomers = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer aoc = new AccountOwnerCustomer();
		aoc.setCustomerId(1111L);
		aoc.setAccountOwnerId(1234);
		listOfaccAccountOwnerCustomers.add(aoc);
		
		List<Trust> trustList = new ArrayList<Trust>();
		Trust trust= new Trust();
		trust.setId(1111L);
		trust.setTrustTypeId((short) 5);
		trustList.add(trust);
		dealDetails.setTrusts(trustList);
		dealDetails.setAccountOwnerCustomer(listOfaccAccountOwnerCustomers);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
		
		decisionBR_13.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_13".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
