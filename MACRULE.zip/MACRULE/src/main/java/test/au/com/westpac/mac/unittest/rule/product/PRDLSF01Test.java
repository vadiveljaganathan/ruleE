package au.com.westpac.mac.unittest.rule.product;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class PRDLSF01Test {

	@Autowired
	RuleEngine ruleEngine;

	@Test
	public void testLoanServiceFee() {
		ProductCategory productCategroy = new ProductCategory();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();
		//Business Loan - VR - CP
		productCategroy.setProductTypeId((short) 39);
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		populateProductFee(productFeeList, RuleConstant.LOAN_SERVICE_FEE_TYPE_ID, "Loan Service Fee", 0);
		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(35.00),productFee.getFeeAmount());
			}
		}

	}
	
	@Test
	public void testLoanServiceFeePRDRG33() {
		ProductCategory productCategroy = new ProductCategory();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();
		//Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 33);
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		populateProductFee(productFeeList, RuleConstant.LOAN_SERVICE_FEE_TYPE_ID, "Loan Service Fee", 0);
		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(10.00),productFee.getFeeAmount());
			}
		}

	}
	@Test
	public void testLoanServiceFeePRDRG35() {
		ProductCategory productCategroy = new ProductCategory();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 35);
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		populateProductFee(productFeeList, RuleConstant.LOAN_SERVICE_FEE_TYPE_ID, "Loan Service Fee", 0);
		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(35.00),productFee.getFeeAmount());
			}
		}

	}
	@Test
	public void testLoanServiceFeePRDRG37() {
		ProductCategory productCategroy = new ProductCategory();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();
		//Business Loan - FR - BA
		productCategroy.setProductTypeId((short) 37);
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		populateProductFee(productFeeList, RuleConstant.LOAN_SERVICE_FEE_TYPE_ID, "Loan Service Fee", 0);
		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.LOAN_SERVICE_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(35.00),productFee.getFeeAmount());
			}
		}

	}

	private void populateProductFee(List<ProductFee> productFeeList,
			int feeTypeId, String feeTypeName, int index) {
		ProductFee productFee = new ProductFee();
		productFee.setFeeTypeId(feeTypeId);
		productFee.setFeeType(feeTypeName);
		productFeeList.add(index, productFee);

	}

}
