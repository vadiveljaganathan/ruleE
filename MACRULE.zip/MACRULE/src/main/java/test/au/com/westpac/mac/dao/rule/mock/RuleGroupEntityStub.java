package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.RuleGroupEntity;

public class RuleGroupEntityStub {
	private List<RuleGroupEntity> ruleGroupEntity;

	public List<RuleGroupEntity> getRuleGroupEntity() {
		return ruleGroupEntity;
	}

	public void setRuleGroupEntity(List<RuleGroupEntity> ruleGroupEntity) {
		this.ruleGroupEntity = ruleGroupEntity;
	}



}
