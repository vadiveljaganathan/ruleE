package au.com.westpac.mac.unittest.rule.product;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
	PRDBRT02Test.class,
	PRDEF02Test.class,
	PRDLSF01Test.class,
	PRDCRM02Test.class,
	PRDLSF03Test.class,
	PRDEF06Test.class,
	PRDEF04Test.class,
	PRDEF01Test.class,
	PRDCRM01Test.class
})
public class ProductRuleTestSuite {

}
