package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.RuleConfigEntity;

public class RuleConfigEntityStub {
	private List<RuleConfigEntity> ruleConfigEntity;

	public List<RuleConfigEntity> getRuleConfigEntity() {
		return ruleConfigEntity;
	}

	public void setRuleConfigEntity(List<RuleConfigEntity> ruleConfigEntity) {
		this.ruleConfigEntity = ruleConfigEntity;
	}
	

}
