package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR009;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR009 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR009 lvr009;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR009Pass() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(90);
		lvrDetails.setLvrRestriction(3);
		lvrDetails.setIsOwnerBuilder(true);
		lvrDetails.setStandardLVRFlag(false);
		lvrDetails.setSystemLVR(0);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR009");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr009.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR009".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
}
