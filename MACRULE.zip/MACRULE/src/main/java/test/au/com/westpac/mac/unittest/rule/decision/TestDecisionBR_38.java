package au.com.westpac.mac.unittest.rule.decision;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.request.Serviceability;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_38 {
	
	@Autowired
	RuleEngine ruleEngine;

	DealDetails dealDetails;
	
	@Test
	public void testDecisionBR38PassForAgeOfFinancials() {
		
		dealDetails = new DealDetails();
		dealDetails.setDeal(new Deal());
		dealDetails.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetails.setCustomer(new ArrayList<Customer>());
		dealDetails.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		
		dealDetails.setRuleStateId((short) 10);
		createDecisionBR38PassForAgeOfFinancials();
		
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_38".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	private void createDecisionBR38PassForAgeOfFinancials() {
		
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);
		Product product = new Product();
		product.setFacilityId(1000L);
		product.setProposedLimit(new BigDecimal(30000));
		product.setProductCategroy(productCategory);
		product.setLlvr(50d);
		product.setRequestedAmount(new BigDecimal(30000));
		dealDetails.setProducts(Arrays.asList(product));

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setCustGrpCappedStatus(false);
		//customerGroup.setIsCustomerGroupInGoodStanding(CUST_IN_GOOD_STANGING);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		Serviceability serviceability = new Serviceability();
		serviceability.setICR(new BigDecimal(5));
		serviceability.setDSC(new BigDecimal(5));
		serviceability.setAgeOfFinancial(18);
		dealDetails.setServiceability(serviceability);
		return;
	}
	
}
