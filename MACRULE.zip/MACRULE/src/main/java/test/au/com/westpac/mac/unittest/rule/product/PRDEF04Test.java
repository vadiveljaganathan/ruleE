package au.com.westpac.mac.unittest.rule.product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.domain.business.product.ProductValidation;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class PRDEF04Test {
	@Autowired
	RuleEngine ruleEngine;
	Product product ;
	
	@Before
	public void setup(){
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();
		
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - VR - CP
		productCategroy.setProductTypeId((short) 22);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation  = new ProductValidation();
		product.setProductValidation(productValidation);
		populateProductFee(productFeeList, RuleConstant.LOAN_SERVICE_FEE_TYPE_ID, "Loan Service Fee", 0);
		populateProductFee(productFeeList, RuleConstant.ESTABLISHMENT_FEE_TYPE_ID, "Establishment Fee", 1);
		populateProductFee(productFeeList, RuleConstant.LINE_FEE_TYPE_ID, "Line Fee", 2);
		product.setProductFeeList(productFeeList);
		
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testEstablishmentFeeTFALessThan20000() {
		product.getProductValidation().setResultantAmount(new BigDecimal(20000));
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(540), productFee.getFeeAmount());
			}
		}
	
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testEstablishmentFeeTFA20001Between100000() {
		product.getProductValidation().setResultantAmount(new BigDecimal(50000));
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(820), productFee.getFeeAmount());
			}
		}
	
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testEstablishmentFeeTFAGreaterThan100000() {
		product.getProductValidation().setResultantAmount(new BigDecimal(110000));
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.ESTABLISHMENT_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(880), productFee.getFeeAmount());
			}
		}
	
	}
	
	private void populateProductFee(List<ProductFee> productFeeList,
			int feeTypeId, String feeTypeName, int index) {
		ProductFee productFee = new ProductFee();
		productFee.setFeeTypeId(feeTypeId);
		productFee.setFeeType(feeTypeName);
		productFeeList.add(index, productFee);

	}

}
