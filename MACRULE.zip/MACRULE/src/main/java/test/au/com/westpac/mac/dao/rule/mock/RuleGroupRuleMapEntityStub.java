package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.RuleGroupRuleMapEntity;

public class RuleGroupRuleMapEntityStub {
	private List<RuleGroupRuleMapEntity> ruleGroupRuleMapEntity;

	public List<RuleGroupRuleMapEntity> getRuleGroupRuleMapEntity() {
		return ruleGroupRuleMapEntity;
	}

	public void setRuleGroupRuleMapEntity(
			List<RuleGroupRuleMapEntity> ruleGroupRuleMapEntity) {
		this.ruleGroupRuleMapEntity = ruleGroupRuleMapEntity;
	}
	

}
