package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.Individual;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_26;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_26 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_26 decisionBR_26;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR26Pass() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_26");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setClearCreditBureau(true);
		deal.isCustomerTradedProfitablyForMinYears();
		deal.setTimeInIndNCoreBusUnderLimit(true);
		dealDetails.setDeal(deal);		
		Individual individual=new Individual();
		individual.setMonthsInIndustry(6L);
		List<Individual> individualCustomers=new ArrayList<Individual>();
		individualCustomers.add(individual);
		dealDetails.setIndividualCustomers(individualCustomers);
		NonIndividual nonIndividual=new NonIndividual();
		nonIndividual.setTimeInCoreBusiness(16L);
		nonIndividual.setId(1111L);
		List<NonIndividual> nonIndividualCustomers=new ArrayList<NonIndividual>();
		nonIndividualCustomers.add(nonIndividual);
		dealDetails.setNonIndividualCustomers(nonIndividualCustomers);
		List<Customer> customer = new ArrayList<Customer>();
		dealDetails.setCustomer(customer);
		List<AccountOwnerCustomer> acccustomer = new ArrayList<AccountOwnerCustomer>();
		dealDetails.setAccountOwnerCustomer(acccustomer);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(28);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setRequestedAmount(new BigDecimal(100));
		product.setAllocatedAmount(new BigDecimal(200));
		List<Product> productList = new ArrayList<Product>();
		Borrower borrower = new Borrower();
		borrower.setId(1111L);
		product.setBorrower(borrower);
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		List<AccountOwnerCustomer> listOfaccAccountOwnerCustomers = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer aoc = new AccountOwnerCustomer();
		aoc.setCustomerId(1111L);
		aoc.setAccountOwnerId(1111);
		listOfaccAccountOwnerCustomers.add(aoc);
		dealDetails.setAccountOwnerCustomer(listOfaccAccountOwnerCustomers);
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
		User loggedInUser = new User();
		loggedInUser.setCalLevel(4);
		dealDetails.setLoggedInUser(loggedInUser);
				
		decisionBR_26.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_26".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_11");
		populateRuleResultObject(ruleEngineResult, "decisionBR_12");
		populateRuleResultObject(ruleEngineResult, "decisionBR_13");
		populateRuleResultObject(ruleEngineResult, "decisionBR_14");
		populateRuleResultObject(ruleEngineResult, "decisionBR_15");
		populateRuleResultObject(ruleEngineResult, "decisionBR_16");
		populateRuleResultObject(ruleEngineResult, "decisionBR_17");
		populateRuleResultObject(ruleEngineResult, "decisionBR_18");
		populateRuleResultObject(ruleEngineResult, "decisionBR_19");
		populateRuleResultObject(ruleEngineResult, "decisionBR_20");
		populateRuleResultObject(ruleEngineResult, "decisionBR_21");
		populateRuleResultObject(ruleEngineResult, "decisionBR_22");
		populateRuleResultObject(ruleEngineResult, "decisionBR_23");
		populateRuleResultObject(ruleEngineResult, "decisionBR_24");
		populateRuleResultObject(ruleEngineResult, "decisionBR_25");
		populateRuleResultObject(ruleEngineResult, "decisionBR_37");		
		populateRuleResultObject(ruleEngineResult, "decisionBR_1");
		populateRuleResultObject(ruleEngineResult, "decisionBR_2");
		populateRuleResultObject(ruleEngineResult, "decisionBR_3");
		populateRuleResultObject(ruleEngineResult, "decisionBR_4");
		populateRuleResultObject(ruleEngineResult, "decisionBR_5");
		populateRuleResultObject(ruleEngineResult, "decisionBR_6");
		populateRuleResultObject(ruleEngineResult, "decisionBR_7");

	}
	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(true);
		ruleEngineResult.add(ruleResult);

	}
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
