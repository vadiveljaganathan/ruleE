package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR003;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR003 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR003 lvr003;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR003PassForRestriction() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(99);
		lvrDetails.setLvrRestriction(3);		
		lvrDetails.setStandardLVRFlag(true);
		lvrDetails.setSystemLVR(60);
			
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("lvr003");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr003.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR003".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	@Test
	public void testLVR003PassForOwner() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(99);		
		lvrDetails.setIsOwnerBuilder(false);
		lvrDetails.setStandardLVRFlag(true);
		lvrDetails.setSystemLVR(60);
		lvrDetails.setLvrRestriction(2);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("lvr003");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr003.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR003".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	


}
