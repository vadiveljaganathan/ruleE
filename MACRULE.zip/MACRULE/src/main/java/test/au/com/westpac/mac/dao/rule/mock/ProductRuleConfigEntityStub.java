package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.ProductRuleConfigEntity;

public class ProductRuleConfigEntityStub {
	private List<ProductRuleConfigEntity> productRuleConfigEntity;

	public List<ProductRuleConfigEntity> getProductRuleConfigEntity() {
		return productRuleConfigEntity;
	}

	public void setProductRuleConfigEntity(
			List<ProductRuleConfigEntity> productRuleConfigEntity) {
		this.productRuleConfigEntity = productRuleConfigEntity;
	}
	

}
