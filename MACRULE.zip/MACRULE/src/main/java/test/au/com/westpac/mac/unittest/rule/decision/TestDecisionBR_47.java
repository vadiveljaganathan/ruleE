package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductRepayment;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_47;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_47 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_47 decisionBR_47;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR47Pass() {
		dealDetails = new DealDetails();
		
		Deal deal = new Deal();		
		deal.setApprovalOverrideCreditDecision(false);
		deal.setPreviousFacilityExtensionApproval(true);
		dealDetails.setDeal(deal);			
		Product product= new Product();		
		product.setCurrentLimit(new BigDecimal(10000));
		ProductTerm currentTerm = new ProductTerm();
		currentTerm.setYears(1);
		product.setCurrentTerm(currentTerm);
		ProductTerm newTerm = new ProductTerm();
		newTerm.setYears(3);
		product.setProposedTerm(newTerm);
		ProductRepayment productRepayment=new ProductRepayment();
		productRepayment.setRepaymentAmount(new BigDecimal(10000));
		productRepayment.setRepaymentTypeId(3);
		product.setProductRepayment(productRepayment);
		List<Product> productList = new ArrayList<Product>();		
		productList.add(product);		
		dealDetails.setProducts(productList);
		dealDetails.setRolloverDeal(true);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_12");
		exec.setExecutingRuleId("decisionBR_47");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		decisionBR_47.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_47".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_1");
		populateRuleResultObject(ruleEngineResult, "decisionBR_2");
		populateRuleResultObject(ruleEngineResult, "decisionBR_4");
		populateRuleResultObject(ruleEngineResult, "decisionBR_6");
		populateRuleResultObject(ruleEngineResult, "decisionBR_13");		
		populateRuleResultObject(ruleEngineResult, "decisionBR_15");	
		populateRuleResultObject(ruleEngineResult, "DecisionBR_46");
	}
	
	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(true);
		ruleEngineResult.add(ruleResult);

	}

	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
