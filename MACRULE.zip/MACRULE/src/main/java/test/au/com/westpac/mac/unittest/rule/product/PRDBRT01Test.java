package au.com.westpac.mac.unittest.rule.product;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class PRDBRT01Test {
	
	@Autowired
	RuleEngine ruleEngine;
	
	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG33() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 33);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG35() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 35);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG37() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 37);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}
	
	@Test
	public void testBaseRateTypeForPRDRG39() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 39);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG41() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 41);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG44() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 44);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}
	
	@Test
	public void testBaseRateTypeForPRDRG31() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 31);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG30() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 30);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG32() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 32);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}
	
	@Test
	public void testBaseRateTypeForPRDRG24() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 24);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG22() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 22);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG27() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 27);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@Test
	public void testBaseRateTypeForPRDRG232() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 232);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG95() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 95);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG14() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 144);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(18), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}
	@Test
	public void testBaseRateTypeForPRDRG113() {
		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 113);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG145() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 145);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG98() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 98);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG150() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 150);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testBaseRateTypeForPRDRG115() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR  BA
		productCategroy.setProductTypeId((short) 115);		
		Product product = new Product();
		product.setProductCategroy(productCategroy);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Integer(44), product.getProductInterestRate()
				.getLolaBaseRateTypeId());
		
	}








}
