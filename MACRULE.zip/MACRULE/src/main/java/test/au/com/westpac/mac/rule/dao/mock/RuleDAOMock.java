package au.com.westpac.mac.rule.dao.mock;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.io.Resource;

import au.com.westpac.mac.dao.rule.mock.CheckListEntityStub;
import au.com.westpac.mac.dao.rule.mock.CheckListRuleGroupMapEntityStub;
import au.com.westpac.mac.dao.rule.mock.ProductRuleConfigEntityStub;
import au.com.westpac.mac.dao.rule.mock.RuleConfigEntityStub;
import au.com.westpac.mac.dao.rule.mock.RuleEntityStub;
import au.com.westpac.mac.dao.rule.mock.RuleGroupEntityStub;
import au.com.westpac.mac.dao.rule.mock.RuleGroupRuleMapEntityStub;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.dao.RuleDAO;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.entity.RuleConfigEntity;
import au.com.westpac.mac.rule.entity.RuleEntity;


public class RuleDAOMock implements RuleDAO{
	
	private Resource checkListEntityDataPath;
	private Resource ruleGroupDetailsDataPath;
	private Resource ruleEntityDataPath;
	private Resource checkListRuleGroupMapEntityDataPath;
	private Resource ruleGroupRuleMapEntityPath;
	private Resource ruleConfigEntityPath;
	private Resource productRuleConfigEntityPath;


	public Resource getCheckListEntityDataPath() {
		return checkListEntityDataPath;
	}

	public void setCheckListEntityDataPath(Resource checkListEntityDataPath) {
		this.checkListEntityDataPath = checkListEntityDataPath;
	}

	public Resource getRuleGroupDetailsDataPath() {
		return ruleGroupDetailsDataPath;
	}

	public void setRuleGroupDetailsDataPath(Resource ruleGroupDetailsDataPath) {
		this.ruleGroupDetailsDataPath = ruleGroupDetailsDataPath;
	}

	public Resource getRuleEntityDataPath() {
		return ruleEntityDataPath;
	}

	public void setRuleEntityDataPath(Resource ruleEntityDataPath) {
		this.ruleEntityDataPath = ruleEntityDataPath;
	}

	public Resource getCheckListRuleGroupMapEntityDataPath() {
		return checkListRuleGroupMapEntityDataPath;
	}

	public void setCheckListRuleGroupMapEntityDataPath(
			Resource checkListRuleGroupMapEntityDataPath) {
		this.checkListRuleGroupMapEntityDataPath = checkListRuleGroupMapEntityDataPath;
	}

	public Resource getRuleGroupRuleMapEntityPath() {
		return ruleGroupRuleMapEntityPath;
	}

	public void setRuleGroupRuleMapEntityPath(Resource ruleGroupRuleMapEntityPath) {
		this.ruleGroupRuleMapEntityPath = ruleGroupRuleMapEntityPath;
	}

	public Resource getRuleConfigEntityPath() {
		return ruleConfigEntityPath;
	}

	public void setRuleConfigEntityPath(Resource ruleConfigEntityPath) {
		this.ruleConfigEntityPath = ruleConfigEntityPath;
	}

	public Resource getProductRuleConfigEntityPath() {
		return productRuleConfigEntityPath;
	}

	public void setProductRuleConfigEntityPath(Resource productRuleConfigEntityPath) {
		this.productRuleConfigEntityPath = productRuleConfigEntityPath;
	}

	@Override
	public List<List<?>> loadCheckListGroupsAndRuleData() {

		List<List<?>> ruleEngineDataDetailsList = new ArrayList<List<?>>();
	
		CheckListEntityStub checkListEntityTest = null;
		RuleGroupEntityStub ruleGroupEntityTest = null;
		RuleEntityStub ruleEntityTest = null;
		CheckListRuleGroupMapEntityStub checkListRuleGroupMapEntityTest = null;
		RuleGroupRuleMapEntityStub ruleGroupRuleMapEntityTest = null;
		RuleConfigEntityStub ruleConfigEntityTest = null;
		ProductRuleConfigEntityStub productRuleConfigEntityTest =null;	
		
		
		
		try{
			System.out.println(" In loadCheckListGroupsAndRuleData------"+checkListEntityDataPath.getFile());
		checkListEntityTest = JsonUtil.unmarshalPayLoad(
				checkListEntityDataPath.getFile(), CheckListEntityStub.class);
		ruleGroupEntityTest = JsonUtil.unmarshalPayLoad(
				ruleGroupDetailsDataPath.getFile(), RuleGroupEntityStub.class);
		ruleEntityTest = JsonUtil.unmarshalPayLoad(
				ruleEntityDataPath.getFile(), RuleEntityStub.class);
		checkListRuleGroupMapEntityTest = JsonUtil.unmarshalPayLoad(
				checkListRuleGroupMapEntityDataPath.getFile(), CheckListRuleGroupMapEntityStub.class);
		ruleGroupRuleMapEntityTest = JsonUtil.unmarshalPayLoad(
				ruleGroupRuleMapEntityPath.getFile(), RuleGroupRuleMapEntityStub.class);
		ruleConfigEntityTest = JsonUtil.unmarshalPayLoad(
				ruleConfigEntityPath.getFile(), RuleConfigEntityStub.class);
		productRuleConfigEntityTest = JsonUtil.unmarshalPayLoad(
				productRuleConfigEntityPath.getFile(), ProductRuleConfigEntityStub.class);
		} catch(Exception e){
			System.out.println("Exception--------"+e);
		}
		ruleEngineDataDetailsList.add(0,checkListEntityTest.getCheckListEntity());
		ruleEngineDataDetailsList.add(1,ruleGroupEntityTest.getRuleGroupEntity());
		ruleEngineDataDetailsList.add(2,ruleEntityTest.getRuleEntity());
		ruleEngineDataDetailsList.add(3,checkListRuleGroupMapEntityTest.getCheckListRuleGroupMapEntity());
		ruleEngineDataDetailsList.add(4,ruleGroupRuleMapEntityTest.getRuleGroupRuleMapEntity());
		ruleEngineDataDetailsList.add(5,ruleConfigEntityTest.getRuleConfigEntity());
		ruleEngineDataDetailsList.add(6,productRuleConfigEntityTest.getProductRuleConfigEntity());

		return ruleEngineDataDetailsList;
		
		
	}

	@Override
	public void saveRuleResult(long dealId, long userId, boolean canDelete, RuleResult ruleResult) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<RuleResult> getRuleResultsForDeal(long dealId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RuleEntity> getDecisionRules(String rulePattern) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveDecisionRuleDetails(String rulesLitXmlString) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRuleConfigDetails(RuleConfigEntity entity) {
		// TODO Auto-generated method stub
		
	}
	
}

