package au.com.westpac.mac.unittest.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_21;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_21 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_21 decisionBR_21;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR9Pass() {
		dealDetails = new DealDetails();
		User user = new User();
		user.setId(3);
		user.setCalLevel(5);
		dealDetails.setLoggedInUser(user);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_21");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setClearCreditBureau(true);
		deal.isCustomerTradedProfitablyForMinYears();
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
				
		decisionBR_21.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_21".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
