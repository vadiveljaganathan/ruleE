package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.CheckListEntity;

public class CheckListEntityStub {
	private List<CheckListEntity> checkListEntity;

	public List<CheckListEntity> getCheckListEntity() {
		return checkListEntity;
	}

	public void setCheckListEntity(List<CheckListEntity> checkListEntity) {
		this.checkListEntity = checkListEntity;
	}
	
}
