package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.RuleEntity;


public class RuleEntityStub {
	private List<RuleEntity> ruleEntity;

	public List<RuleEntity> getRuleEntity() {
		return ruleEntity;
	}

	public void setRuleEntity(List<RuleEntity> ruleEntity) {
		this.ruleEntity = ruleEntity;
	}
	

}
