package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.Individual;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_25;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_25 {

	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_25 decisionBR_25;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR25Pass() {
		dealDetails= new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_25");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		
		List<Customer> customerList = new ArrayList<Customer>();
		Customer customer= new Customer();
		customer.setTimeWithBank((long) 13);
		customer.setId(111L);
		customerList.add(customer);
		dealDetails.setCustomer(customerList);
		
		Product product= new Product();
		product.setId(12345);
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setModifiedInDeal(true);
		product.setProposedLimit(new BigDecimal(1000000));
		product.setCurrentLimit(new BigDecimal(1000000));
		product.setAllocatedAssets(new ArrayList<Asset>());
		Borrower borrower = new Borrower();
		borrower.setId(1234);
		product.setBorrower(borrower);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		List<AccountOwnerCustomer> aocList = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer accOwnerCustomer = new AccountOwnerCustomer();
		accOwnerCustomer.setCustomerId(111L);
		accOwnerCustomer.setAccountOwnerId(1234);
		aocList.add(accOwnerCustomer);
		dealDetails.setAccountOwnerCustomer(aocList);
		
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setIndividualCustomers(new ArrayList<Individual>());
		
		Deal deal = new Deal();
		deal.setApprovalOverrideCreditDecision(false);
		dealDetails.setDeal(deal);
		decisionBR_25.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_25".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	@Test
	public void testDecisionBR25Negative() {
		dealDetails= new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_25");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		
		List<Customer> customerList = new ArrayList<Customer>();
		Customer customer= new Customer();
		customer.setTimeWithBank((long) 12);
		customer.setId(111L);
		customerList.add(customer);
		dealDetails.setCustomer(customerList);
		
		List<AccountOwnerCustomer> aocList = new ArrayList<AccountOwnerCustomer>();
		AccountOwnerCustomer accOwnerCustomer = new AccountOwnerCustomer();
		accOwnerCustomer.setAccountOwnerId(1234);
		accOwnerCustomer.setCustomerId(111L);
		aocList.add(accOwnerCustomer);
		dealDetails.setAccountOwnerCustomer(aocList);
		
		Product product= new Product();
		product.setId(12345);
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setModifiedInDeal(true);
		product.setProposedLimit(new BigDecimal(1000000));
		product.setCurrentLimit(new BigDecimal(1000000));
		product.setAllocatedAssets(new ArrayList<Asset>());
		Borrower borrower = new Borrower();
		borrower.setId(1234);
		product.setBorrower(borrower);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		dealDetails.setNonIndividualCustomers(new ArrayList<NonIndividual>());
		dealDetails.setIndividualCustomers(new ArrayList<Individual>());
		
		Deal deal = new Deal();
		deal.setApprovalOverrideCreditDecision(false);
		dealDetails.setDeal(deal);
		decisionBR_25.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_25".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_11", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_12", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_13", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_14", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_15", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_1", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_2", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_3", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_4", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_5", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_6", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_7", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_17", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_18", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_19", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_20", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_21", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_22", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_23", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_24", true);

	}

	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName, boolean ruleResultIndicator) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(ruleResultIndicator);
		ruleEngineResult.add(ruleResult);

	}

	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
