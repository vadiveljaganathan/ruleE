package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.asset.Guarantor;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroupConditionalLimit;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDEC_RG_2 {
	
	@Autowired
	RuleEngine ruleEngine;
	
	
	@Test
	public void testDecisionBR8CustomerInGoodStandingPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjGxGuaranteesPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_8".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR8CustomerInGoodStandingNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjGxGuaranteesNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_8".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR9CustomerInGoodStandingPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCustomerTradedProfitablyForMinYearsPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_9".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR9CustomerInGoodStandingNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCustomerTradedProfitablyForMinYearsNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_9".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR10CustomerInGoodStandingPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjTradedProfitablyPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_10".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR10CustomerInGoodStandingNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjTradedProfitablyNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_10".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	private DealDetails dealObjGxGuaranteesPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
		
		
	}
	private DealDetails dealObjGxGuaranteesNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}
	private DealDetails dealObjCustomerTradedProfitablyForMinYearsPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
		
		
	}
	private DealDetails dealObjCustomerTradedProfitablyForMinYearsNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}
	private DealDetails dealObjTradedProfitablyPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)20);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
		
		
	}
	private DealDetails dealObjTradedProfitablyNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)26);
		dealDetails.setNonIndividualCustomers(nonIndividualList);

		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(BigDecimal.ZERO);
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}
}
