package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR004;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR004 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR004 lvr004;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR004Pass() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(100);		
		lvrDetails.setStandardLVRFlag(true);
		lvrDetails.setSystemLVR(50);
			
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR004");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr004.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR004".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	

}
