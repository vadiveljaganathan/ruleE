package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR013;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR013 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR013 lvr013;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR013PassForAssetValue() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(76);
		lvrDetails.setAssetValue(new BigDecimal(2051000));
		lvrDetails.setPostCode("8992");
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR013");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr013.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR013".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	@Test
	public void testLVR013PassForPostcode() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(76);
		lvrDetails.setAssetValue(new BigDecimal(20));
		lvrDetails.setPostCode("8992");
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR013");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr013.execute(lvrDetails, ruleEngineResult, exec);
		Assert.assertNotNull(exec);		
	}
	

}
