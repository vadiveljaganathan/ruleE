package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.asset.Guarantor;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customer.NonIndividual;
import au.com.westpac.mac.domain.business.customer.Trust;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroupConditionalLimit;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDEC_RG_3 {

	@Autowired
	RuleEngine ruleEngine;

	@Test
	public void testDecisionBR11BusinessStructureIDPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForRuleGroup3Positive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_11".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR11BusinessStructureIDNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForRuleGroup3Negative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_11".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertFalse(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR12SectorpolicyApplicablePositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForRuleGroup3Positive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_12".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR12SectorpolicyApplicableNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjSectorPolicyNotApplicableNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_12".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR13ForTrustPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForTrustPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_13".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR13ForTrustNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForTrustNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_13".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR14LoanPurposePositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForTrustPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_14".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR14LoanPurposeNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjForTrustNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_14".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR15LLVRFacilityPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjLLVRFacilityPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_15".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR15LLVRFacilityNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjLLVRFacilityNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_15".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	private DealDetails dealObjForRuleGroup3Positive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)2);
		List<Customer> customerList = new ArrayList<Customer>();
		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(false);
		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);

		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)20);
		nonIndividual.setBusinessStructureId((long)5);
		dealDetails.setNonIndividualCustomers(nonIndividualList);

		return dealDetails;


	}
	private DealDetails dealObjForRuleGroup3Negative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)1);
		List<Customer> customerList = new ArrayList<Customer>();

		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)26);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(new BigDecimal(0));
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}

	private DealDetails dealObjSectorPolicyNotApplicableNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)2);
		List<Customer> customerList = new ArrayList<Customer>();

		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(true);

		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)26);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(new BigDecimal(0));
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}

	private DealDetails dealObjForTrustPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		product.setLoanPurposeId(5);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)3);
		List<Customer> customerList = new ArrayList<Customer>();

		Trust trust = new Trust();
		trust.setTrustTypeId((short)3);
		List<Trust> trustList = new ArrayList<Trust>();	
		dealDetails.setTrusts(trustList);

		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(false);
		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);

		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)20);
		nonIndividual.setBusinessStructureId((long)5);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(new BigDecimal(0));
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;

	}
	private DealDetails dealObjForTrustNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		product.setLoanPurposeId(1);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
	//	product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)2);
		List<Customer> customerList = new ArrayList<Customer>();

		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(true);

		Trust trust = new Trust();
		trust.setTrustTypeId((short)4);
		List<Trust> trustList = new ArrayList<Trust>();

		dealDetails.setTrusts(trustList);
		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)26);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(new BigDecimal(0));
		dealDetails.setCustomerGroupConditionalLimit(limits);
		return dealDetails;
	}

	private DealDetails dealObjLLVRFacilityPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);*/
		productCategory.setProductTypeId(26);
		//productCategory.setProductSubType("42");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		product.setLoanPurposeId(5);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(90000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)3);
		List<Customer> customerList = new ArrayList<Customer>();

		Trust trust = new Trust();
		trust.setTrustTypeId((short)3);
		List<Trust> trustList = new ArrayList<Trust>();	
		dealDetails.setTrusts(trustList);

		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(false);
		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);

		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)20);
		nonIndividual.setBusinessStructureId((long)5);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		CustomerGroupConditionalLimit limits = new CustomerGroupConditionalLimit();
		limits.setBtlTotalAvail(new BigDecimal(0));
		dealDetails.setCustomerGroupConditionalLimit(limits);

		return dealDetails;

	}
	private DealDetails dealObjLLVRFacilityNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);*/
		productCategory.setProductTypeId(26);
		//productCategory.setProductSubType("42");
		productCategory.setProductFamilyId(5);
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setLlvr(90.0);
		product.setLlvrResidential(90.0);
		product.setLlvrCommercial(90.0);
		product.setLoanPurposeId(1);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		BigDecimal resultantAmount =new BigDecimal(1000000);
		product.setRequestedAmount(resultantAmount);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
				dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(2);
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);

		Customer customer =new Customer();
		customer.setCustomerTypeId((short)2);
		List<Customer> customerList = new ArrayList<Customer>();

		Deal deal = new Deal();
		deal.setSectorPolicyApplicable(true);

		Trust trust = new Trust();
		trust.setTrustTypeId((short)4);
		List<Trust> trustList = new ArrayList<Trust>();

		dealDetails.setTrusts(trustList);
		dealDetails.setDeal(deal);
		dealDetails.setCustomer(customerList);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		dealDetails.getDeal().setCustomerTradedProfitablyForMinYears(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//dealDetails.setGuarantors(guarantorList);
		List<NonIndividual> nonIndividualList = new ArrayList<NonIndividual>();
		NonIndividual nonIndividual = new NonIndividual();
		nonIndividual.setTimeInCoreBusiness((long)26);
		dealDetails.setNonIndividualCustomers(nonIndividualList);
		return dealDetails;
	}
}
