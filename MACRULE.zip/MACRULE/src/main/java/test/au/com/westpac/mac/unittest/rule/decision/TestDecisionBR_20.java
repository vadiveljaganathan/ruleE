package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroupLendingAuthority;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.domain.user.User;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_20;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_20 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_20 decisionBR_20;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR20Pass() {
		dealDetails= new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_5");
		exec.setExecutingRuleId("decisionBR_20");
		User user = new User();
		user.setCalLevel(4);
		dealDetails.setLoggedInUser(user);
		Deal deal = new Deal();	
		deal.setCustomerTradedProfitablyForMinYears(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(35);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		Borrower borrower = new Borrower();
		borrower.setId(1111L);
		product.setBorrower(borrower);
		product.setProposedTerm(productTerm);
		product.setAllocatedAssets(new ArrayList<Asset>());
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		CustomerGroupLendingAuthority authority = new CustomerGroupLendingAuthority();
		authority.setGeneralCALAvail(new BigDecimal(250000));
		dealDetails.setCustomerGroupLendingAuthority(authority);
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();
		populateRuleEngineResult(ruleEngineResult);
		decisionBR_20.execute(dealDetails, ruleEngineResult, exec);
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_20".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}

	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_11", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_12", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_13", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_14", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_15", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_1", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_2", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_3", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_4", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_5", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_6", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_7", true);
		populateRuleResultObject(ruleEngineResult, "decisionBR_9", true);

	}

	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName, boolean ruleResultIndicator) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(ruleResultIndicator);
		ruleEngineResult.add(ruleResult);

	}

	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC20_RG_4.json",
				DealDetails.class);

	}

}
