package au.com.westpac.mac.unittest.rule.product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.domain.business.product.ProductValidation;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.product.PRDT04;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class PRDA05Test {
	@Autowired
	RuleEngine ruleEngine;
	
	@SuppressWarnings("deprecation")
	@Test
	public void testTotalFinanceAmountMax() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - VR - CP
		productCategroy.setProductTypeId((short) 29);		
		Product product = new Product();
		product.setIsRevolvingLineOfCredit(false);
		product.setProductCategroy(productCategroy);
		ProductValidation validation = new ProductValidation();
		product.setProductValidation(validation);
		
		List<ProductFee> produtFeeList = new ArrayList<ProductFee>();
		ProductFee productFee = new ProductFee();
		productFee.setFeeTypeId(80);
		produtFeeList.add(productFee);
		product.setProductFeeList(produtFeeList);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Double(1000000), product.getProductValidation().getTotalFinanceAmountMax());
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testPRDTUF01() {
		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - VR - CP
		productCategroy.setProductTypeId((short) 29);		
		Product product = new Product();
		product.setIsRevolvingLineOfCredit(false);
		product.setProductCategroy(productCategroy);
		ProductValidation validation = new ProductValidation();
		product.setProductValidation(validation);
		
		List<ProductFee> produtFeeList = new ArrayList<ProductFee>();
		ProductFee productFee = new ProductFee();
		productFee.setFeeTypeId(80);
		produtFeeList.add(productFee);
		product.setProductFeeList(produtFeeList);
		ruleEngine.processRequest(product);
		Assert.assertEquals(new Double(410), product.getProductFeeList().get(0).getFeeAmount());
		
	}

}
