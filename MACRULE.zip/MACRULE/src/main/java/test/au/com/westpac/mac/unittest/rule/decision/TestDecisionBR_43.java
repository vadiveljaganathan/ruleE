package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductRepayment;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_43;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_43 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_43 decisionBR_43;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR43Pass() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_12");
		exec.setExecutingRuleId("decisionBR_43");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();		
		deal.setApprovalOverrideCreditDecision(false);
		deal.setPreviousFacilityExtensionApproval(true);
		dealDetails.setDeal(deal);			
		Product product= new Product();		
		product.setCurrentLimit(new BigDecimal(10000));
		ProductTerm currentTerm = new ProductTerm();
		currentTerm.setYears(1);
		product.setCurrentTerm(currentTerm);
		ProductTerm newTerm = new ProductTerm();
		newTerm.setYears(1);
		product.setProposedTerm(newTerm);
		ProductRepayment productRepayment=new ProductRepayment();
		productRepayment.setRepaymentAmount(new BigDecimal(10000));
		productRepayment.setRepaymentTypeId(3);
		product.setProductRepayment(productRepayment);		
		List<ProductRepayment> repaymentList = new ArrayList<ProductRepayment>();
		repaymentList.add(productRepayment);
		product.setRepaymentList(repaymentList);
		List<Product> productList = new ArrayList<Product>();		
		productList.add(product);		
		dealDetails.setProducts(productList);
		dealDetails.setRolloverDeal(true);
		
		populateRuleEngineResult(ruleEngineResult);
		decisionBR_43.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_43".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	private void populateRuleEngineResult(List<RuleResult> ruleEngineResult) {
		populateRuleResultObject(ruleEngineResult, "decisionBR_1");
		populateRuleResultObject(ruleEngineResult, "decisionBR_2");
		populateRuleResultObject(ruleEngineResult, "decisionBR_4");
		populateRuleResultObject(ruleEngineResult, "decisionBR_6");	
		populateRuleResultObject(ruleEngineResult, "decisionBR_13");		
		populateRuleResultObject(ruleEngineResult, "DecisionBR_42");			
	}

	private void populateRuleResultObject(List<RuleResult> ruleEngineResult,
			String ruleName) {
		RuleResult ruleResult = new RuleResult();
		ruleResult.setRuleId(ruleName);
		ruleResult.setRulePassed(true);
		ruleEngineResult.add(ruleResult);

	}
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
