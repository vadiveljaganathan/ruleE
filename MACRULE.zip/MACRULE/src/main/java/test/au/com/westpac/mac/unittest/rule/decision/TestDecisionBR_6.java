package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_6;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_6 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_6 decisionBR_6;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR6Pass() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_1");
		exec.setExecutingRuleId("decisionBR_6");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		product.setId(12345);
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(28);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setModifiedInDeal(true);
		product.setProposedLimit(new BigDecimal(1000000));
		product.setCurrentLimit(new BigDecimal(1000000));
		Borrower borrower = new Borrower();
		borrower.setId(1234);
		product.setBorrower(borrower);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		asset.setAssetId(Long.valueOf(1234));
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		List<AssetAllocations> assetAllocations = new ArrayList<AssetAllocations>();
		AssetAllocations allocation = new AssetAllocations();
		allocation.setAssetId(1234);
		allocation.setProductId(12345);
		allocation.setAllocationAmount(new BigDecimal(1200000));
		dealDetails.setAssetAllocations(assetAllocations);
		
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		decisionBR_6.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_6".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	@Test
	public void testDecisionBR6Negative() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_1");
		exec.setExecutingRuleId("decisionBR_6");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(29);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(31);
		product.setProposedTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetTypeId(1);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		
		dealDetails.setAsset(assetList);
		dealDetails.setProducts(productList);
		
		decisionBR_6.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_6".equals(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
