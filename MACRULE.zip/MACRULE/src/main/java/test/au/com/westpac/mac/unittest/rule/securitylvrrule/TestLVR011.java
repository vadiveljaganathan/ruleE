package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR011;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR011 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR011 lvr011;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR011PassForAssetValue() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(76);
		lvrDetails.setAssetValue(new BigDecimal(202300));
		lvrDetails.setPostCode("2000");
		lvrDetails.setStandardLVRFlag(false);
		lvrDetails.setSystemLVR(80);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR011");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr011.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR011".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	@Test
	public void testLVR011PassForPostCode1() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(76);
		lvrDetails.setPostCode("8992");
		lvrDetails.setStandardLVRFlag(false);
		lvrDetails.setSystemLVR(80);
		lvrDetails.setAssetValue(null);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR011");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr011.execute(lvrDetails, ruleEngineResult, exec);
		
		Assert.assertNotNull(exec);
	}
	

}
