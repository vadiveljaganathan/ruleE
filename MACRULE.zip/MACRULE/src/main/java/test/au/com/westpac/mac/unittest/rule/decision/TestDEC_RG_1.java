package au.com.westpac.mac.unittest.rule.decision;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.asset.AssetValuation;
import au.com.westpac.mac.domain.business.asset.Guarantor;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AllocationGuarantors;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDEC_RG_1 {

	@Autowired
	RuleEngine ruleEngine;


	@Test
	public void testDecisionBR0() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		List<Product> productList = new ArrayList<Product>();
		Product product= new Product();
		product.setId(new Long(1111));
		product.setIsExtendedInDeal(false);
		productList.add(product);
		dealDetailObj.setProducts(productList);
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_0".equalsIgnoreCase(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR0Negative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		List<Product> productList = new ArrayList<Product>();
		Product product= new Product();
		product.setId(new Long(11112));
		product.setIsExtendedInDeal(false);
		productList.add(product);
		dealDetailObj.setProducts(productList);
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSNegative(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_0".equalsIgnoreCase(ruleResult.getRuleId())) {
				Assert.assertFalse(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR1CustomerInGoodStandingPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_1".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR1CustomerInGoodStandingNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_1".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR2StatutoryPaymentPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjStatutoryPaymentPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_2".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR2StatutoryPaymentNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjStatutoryPaymentNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_2".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR3CreditBureauPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCreditBureauPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_3".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR3CreditBureauNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCreditBureauNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_3".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR4CurrentarrearsPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCurrentArrearPositive(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);
		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_4".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR4CurrentarrearsNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCurrentArrearNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_4".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR5LegalAdviceWaivePositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjLegalAdviceWaivePositive(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);
		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_5".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR5LegalAdviceWaiveNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjLegalAdviceWaiveNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_5".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR6LegalAdviceWaivePositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjTermPositive(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);
		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_6".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR6LegalAdviceWaiveNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjTermNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_6".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	@Test
	public void testDecisionBR7AssetFamilyPropertyPositive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjAssetFamilyPropertyPositive(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);
		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_7".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR7AssetFamilyPropertyNegative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjAssetFamilyPropertyNegative(dealDetailObj);
		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_7".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(!ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	/*@Test
	public void testDecisionBR2PassForModifiedFacility() {

		createDecisionBR33PassForModifiedFacility();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}

	@Test
	public void testDecisionBR3PassForCondition3() {

		createDecisionBR33PassForCondition3();

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_33".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}*/

	private DealDetails dealObjCIGSPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		product.setId(new Long(1111));
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamily("1");
		asset.setAssetCategory(assetCategory);
		
		List<AssetAllocations> allocatedAssets = new ArrayList<AssetAllocations>();
		AssetAllocations assetAllocations = new AssetAllocations();
		assetAllocations.setProductId(new Long(1111));
		assetAllocations.setAssetId(new Long(2222));
		assetAllocations.setAllocationAmount(new BigDecimal(1230));
		assetAllocations.setAllocatedToTypeId(1);
		allocatedAssets.add(assetAllocations);
		dealDetails.setAssetAllocations(allocatedAssets);
		
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		
		
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		dealDetails.setGuarantors(new ArrayList<AllocationGuarantors>());
		return dealDetails;
	}

	private DealDetails dealObjCIGSNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("N");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//
		List<AssetAllocations> allocatedAssets = new ArrayList<AssetAllocations>();
		AssetAllocations assetAllocations = new AssetAllocations();
		assetAllocations.setProductId(new Long(1111));
		assetAllocations.setAssetId(new Long(2222));
		assetAllocations.setAllocationAmount(new BigDecimal(1230));
		assetAllocations.setAllocatedToTypeId(1);
		allocatedAssets.add(assetAllocations);
		dealDetails.setAssetAllocations(allocatedAssets);
		return dealDetails;
	}

	private DealDetails dealObjStatutoryPaymentPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamily("1");
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//
		return dealDetails;
	}

	private DealDetails dealObjStatutoryPaymentNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(false);
		dealDetails.getDeal().setClearCreditBureau(false);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}
	private DealDetails dealObjCreditBureauPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamily("1");
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjCreditBureauNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(false);
		dealDetails.getDeal().setClearCreditBureau(false);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjCurrentArrearPositive(DealDetails dealDetails) {
		dealDetails.setAsset(new ArrayList<Asset>());
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjCurrentArrearNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(false);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjLegalAdviceWaivePositive(DealDetails dealDetails) {
		dealDetails.setAsset(new ArrayList<Asset>());
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjLegalAdviceWaiveNegative(DealDetails dealDetails) {
		dealDetails.setAsset(new ArrayList<Asset>());
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(false);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjTermPositive(DealDetails dealDetails) {
		dealDetails.setAsset(new ArrayList<Asset>());
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(28);
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

	private DealDetails dealObjTermNegative(DealDetails dealDetails) {
		dealDetails.setAsset(new ArrayList<Asset>());
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(false);
		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}
	private DealDetails dealObjAssetFamilyPropertyPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(28);
		productCategory.setProductType("1");
		productCategory.setProductFamily("7");
		Product product = new Product();
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		product.setProposedTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(true);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(7);
		asset.setAssetCategory(assetCategory);
		AssetValuation assetValuation = new AssetValuation();
		assetValuation.setAssetValue(new BigDecimal(150000));
		asset.setAssetValuation(assetValuation);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(false);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		dealDetails.getDeal().setPropertyValuationWithinPolicy(true);
		return dealDetails;
	}

	private DealDetails dealObjAssetFamilyPropertyNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);

		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCurrentArrearswithinLimit(false);
		dealDetails.setCustomerGroup(customerGroup);
		
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamily("1");
		asset.setAssetCategory(assetCategory);
		List<Asset> assetList = new ArrayList<Asset>();
		assetList.add(asset);
		dealDetails.setAsset(assetList);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		
		return dealDetails;
	}

}
