package au.com.westpac.mac.dao.rule.mock;

import java.util.List;

import au.com.westpac.mac.rule.entity.CheckListRuleGroupMapEntity;

public class CheckListRuleGroupMapEntityStub {
	private List<CheckListRuleGroupMapEntity> checkListRuleGroupMapEntity;

	public List<CheckListRuleGroupMapEntity> getCheckListRuleGroupMapEntity() {
		return checkListRuleGroupMapEntity;
	}

	public void setCheckListRuleGroupMapEntity(
			List<CheckListRuleGroupMapEntity> checkListRuleGroupMapEntity) {
		this.checkListRuleGroupMapEntity = checkListRuleGroupMapEntity;
	}
	

}
