package au.com.westpac.mac.unittest.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.AssetCategory;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.json.util.JsonUtil;
import au.com.westpac.mac.rule.decision.DecisionBR_15;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_15 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	DecisionBR_15 decisionBR_15;

	DealDetails dealDetails;

	@Test
	public void testDecisionBR15Pass() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_3");
		exec.setExecutingRuleId("decisionBR_15");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setPropertyValuationWithinPolicy(true);
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(20);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setLlvr(new Double(50));
		product.setLlvrCommercial(new Double(50));
		List<Product> productList = new ArrayList<Product>();
		
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(7);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		product.setAllocatedAssets(assetList);
		productList.add(product);
		dealDetails.setProducts(productList);
		
		decisionBR_15.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_15".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRuleApplicable());
				Assert.assertTrue(ruleResult.isRulePassed());
			}
		}
	}
	
	@Test
	public void testDecisionBR15Negative() {
		dealDetails = new DealDetails();
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("DEC_RG_3");
		exec.setExecutingRuleId("decisionBR_15");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		Deal deal = new Deal();
		deal.setPropertyValuationWithinPolicy(true);
		deal.setClearCreditBureau(true);
		dealDetails.setDeal(deal);
		Product product= new Product();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductTypeId(20);
		product.setProductCategroy(productCategory);
		ProductTerm productTerm = new ProductTerm();
		productTerm.setYears(15);
		product.setProposedTerm(productTerm);
		product.setLlvr(new Double(102));
		product.setLlvrCommercial(new Double(50));
		List<Product> productList = new ArrayList<Product>();
		
		List<Asset> assetList= new ArrayList<Asset>();
		Asset asset = new Asset();
		AssetCategory assetCategory = new AssetCategory();
		assetCategory.setAssetFamilyId(7);
		asset.setAssetCategory(assetCategory);
		assetList.add(asset);
		product.setAllocatedAssets(assetList);
		productList.add(product);
		dealDetails.setProducts(productList);
		
		decisionBR_15.execute(dealDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("DecisionBR_15".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRuleApplicable());
				Assert.assertFalse(ruleResult.isRulePassed());
			}
		}
	}
	@Before
	public void setup() {

		dealDetails = JsonUtil.unmarshalPayLoad("dealDetailsTestDEC_RG_4.json",
				DealDetails.class);

	}

}
