package au.com.westpac.mac.unittest.rule.product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductFee;
import au.com.westpac.mac.domain.business.product.ProductValidation;
import au.com.westpac.mac.rule.constants.RuleConstant;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class PRDTUF02Test {

	@Autowired
	RuleEngine ruleEngine;
	Product product;

	@Test
	public void testTopUpFeeForPRDRG33() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 33);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(100000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(410.0), productFee.getFeeAmount());
			}
		}
	}
	
	@Test
	public void testTopUpFeeGreaterThan100000ForPRDRG33() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		// Business Loan - FR - RP
		productCategroy.setProductTypeId((short) 33);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(200000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(600.0), productFee.getFeeAmount());
			}
		}
	}

	@Test
	public void testTopUpFeeForPRDRG35() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 35);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(100000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(410.0), productFee.getFeeAmount());
			}
		}
	}
	
	@Test
	public void testTopUpFeeGreaterThan100000ForPRDRG35() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		//Business Loan - FR - CP
		productCategroy.setProductTypeId((short) 35);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(200000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(600.0), productFee.getFeeAmount());
			}
		}
	}

	@Test
	public void testTopUpFeeForPRDRG37() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		//Business Loan  FR BA  
		productCategroy.setProductTypeId((short) 37);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(100000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(410.0), productFee.getFeeAmount());
			}
		}
	}
	
	@Test
	public void testTopUpFeeGreaterThan100000ForPRDRG37() {
		product = new Product();
		List<ProductFee> productFeeList = new ArrayList<ProductFee>();

		ProductCategory productCategroy = new ProductCategory();
		// Business Loan  FR  BA  
		productCategroy.setProductTypeId((short) 37);
		product.setProductCategroy(productCategroy);
		ProductValidation productValidation = new ProductValidation();
		product.setProductValidation(productValidation);
		product.getProductValidation().setResultantAmount(
				new BigDecimal(200000));
		populateProductFee(productFeeList, RuleConstant.TOP_UP_FEE_TYPE_ID,
				"TopUp Fee", 0);

		product.setProductFeeList(productFeeList);
		ruleEngine.processRequest(product);
		for (ProductFee productFee : product.getProductFeeList()) {
			if (productFee.getFeeTypeId() == RuleConstant.TOP_UP_FEE_TYPE_ID) {
				Assert.assertEquals(new Double(600.0), productFee.getFeeAmount());
			}
		}
	}

	private void populateProductFee(List<ProductFee> productFeeList,
			int feeTypeId, String feeTypeName, int index) {
		ProductFee productFee = new ProductFee();
		productFee.setFeeTypeId(feeTypeId);
		productFee.setFeeType(feeTypeName);
		productFeeList.add(index, productFee);

	}
}
