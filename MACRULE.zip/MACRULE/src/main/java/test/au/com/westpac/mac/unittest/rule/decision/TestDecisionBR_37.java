package au.com.westpac.mac.unittest.rule.decision;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.Asset;
import au.com.westpac.mac.domain.business.asset.Guarantor;
import au.com.westpac.mac.domain.business.customer.Customer;
import au.com.westpac.mac.domain.business.customergroup.CustomerGroup;
import au.com.westpac.mac.domain.business.deal.Deal;
import au.com.westpac.mac.domain.business.engine.AccountOwnerCustomer;
import au.com.westpac.mac.domain.business.engine.AssetAllocations;
import au.com.westpac.mac.domain.business.engine.DealDetails;
import au.com.westpac.mac.domain.business.product.Borrower;
import au.com.westpac.mac.domain.business.product.Product;
import au.com.westpac.mac.domain.business.product.ProductCategory;
import au.com.westpac.mac.domain.business.product.ProductTerm;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestDecisionBR_37 {
	@Autowired
	RuleEngine ruleEngine;


	@Test
	public void testDecisionBR37Positive() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSPositive(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_37".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	@Test
	public void testDecisionBR37Negative() {
		DealDetails dealDetailObj = new DealDetails();
		dealDetailObj.setDeal(new Deal());
		dealDetailObj.setAssetAllocations(new ArrayList<AssetAllocations>());
		dealDetailObj.setCustomer(new ArrayList<Customer>());
		dealDetailObj.setAccountOwnerCustomer(new ArrayList<AccountOwnerCustomer>());
		DealDetails dealDetails=dealObjCIGSNegative(dealDetailObj);

		List<RuleResult> ruleResults = ruleEngine.processRequest(dealDetails);

		for (RuleResult ruleResult : ruleResults) {
			if ("DecisionBR_37".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}		 
	}
	
	private DealDetails dealObjCIGSPositive(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		dealDetails.setAsset(new ArrayList<Asset>());
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		//customerGroup.setCustGrpCappedStatus(false);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCustomerGroupCapped(false);

		dealDetails.setCustomerGroup(customerGroup);

		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//
		return dealDetails;
	}
	
	private DealDetails dealObjCIGSNegative(DealDetails dealDetails) {
		ProductCategory productCategory = new ProductCategory();
		/*productCategory.setProductFamilyId(5);
		productCategory.setProductTypeId(19);*/
		productCategory.setProductType("1");
		productCategory.setProductFamily("2");
		Product product = new Product();
		product.setAllocatedAssets(new ArrayList<Asset>());
		product.setProductCategroy(productCategory);
		Borrower borrower = new Borrower();
		borrower.setId(10111);
		product.setBorrower(borrower);
		ProductTerm productTerm=new ProductTerm();
		productTerm.setYears(20);
		//product.setProductTerm(productTerm);
		List<Product> productList = new ArrayList<Product>();
		productList.add(product);
		dealDetails.setProducts(productList);
		dealDetails.setAllProducts(productList);
		CustomerGroup customerGroup = new CustomerGroup();
		customerGroup.setIsCustomerGroupInGoodStanding("Y");
		//customerGroup.setCustGrpCappedStatus(false);
		dealDetails.getDeal().setStatutoryPaymentFlag(true);
		dealDetails.getDeal().setClearCreditBureau(true);
		dealDetails.getDeal().setCustomerGroupCapped(true);

		dealDetails.setCustomerGroup(customerGroup);
		dealDetails.setAsset(new ArrayList<Asset>());
		Guarantor guarantor = new Guarantor();
		guarantor.setGuarantorStatusId(2);
		//guarantor.setWaiveLegalAdvice(true);
		List<Guarantor> guarantorList = new ArrayList<Guarantor>();
		guarantorList.add(guarantor);
		//
		return dealDetails;
	}

}
