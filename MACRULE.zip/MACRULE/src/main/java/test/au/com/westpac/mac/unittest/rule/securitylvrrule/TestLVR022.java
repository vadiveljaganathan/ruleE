package au.com.westpac.mac.unittest.rule.securitylvrrule;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import au.com.westpac.mac.domain.business.asset.LVRDetails;
import au.com.westpac.mac.rule.domain.RuleResult;
import au.com.westpac.mac.rule.engine.RuleEngine;
import au.com.westpac.mac.rule.engine.RuleEngineExecutionContext;
import au.com.westpac.mac.rule.securitylvrrule.LVR022;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:test-context-rule.xml" })
public class TestLVR022 {
	@Autowired
	RuleEngine ruleEngine;

	@Autowired
	LVR022 lvr022;
	
	LVRDetails lvrDetails;
	
	@Test
	public void testLVR022PassForCondition1() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(86);
		lvrDetails.setInternalArea(39.0);
		lvrDetails.setStandardLVRFlag(true);
		lvrDetails.setSystemLVR(60);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR022");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr022.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR022".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
	
	@Test
	public void testLVR022PassForCondition2() {
		lvrDetails = new LVRDetails();
		lvrDetails.setAssetType(86);
		lvrDetails.setLandArea(49.0);
		lvrDetails.setStandardLVRFlag(true);
		lvrDetails.setSystemLVR(60);
		
		RuleEngineExecutionContext exec = new RuleEngineExecutionContext();
		exec.setExecutingRuleGroupId("LVRRG");
		exec.setExecutingRuleId("LVR022");
		List<RuleResult> ruleEngineResult = new ArrayList<RuleResult>();

		
		lvr022.execute(lvrDetails, ruleEngineResult, exec);
		
		for (RuleResult ruleResult : ruleEngineResult) {
			if ("LVR022".equals(ruleResult.getRuleId())) {
				Assert.assertTrue(ruleResult.isRulePassed());
				Assert.assertTrue(ruleResult.isRuleApplicable());
			}
		}
	}
}
